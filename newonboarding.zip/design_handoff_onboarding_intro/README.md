# Handoff: Onboarding intro, 4 new info screens

## ⚠️ Scope: only screens 2, 3, 4 and 5 are new
The prototype `Onboarding Intro.html` has 6 screens so you can see the flow. **Only screens 2–5 need to be built.**

| # | Screen | Status |
|---|---|---|
| 1 | Welcome (logo + "Get started") | **Already exists** in `app/onboarding.tsx`. Leave it as is. |
| **2** | **Every aircraft** (cyan) | **NEW. Build this.** |
| **3** | **Paper logbook** (gold) | **NEW. Build this.** |
| **4** | **Security** (green) | **NEW. Build this.** |
| **5** | **Airport globe** (cyan) | **NEW. Build this.** |
| 6 | Role ("What do you do?") | **Already exists.** Shown only for context. Leave it as is. |

Each `<section>` in the HTML has a `data-screen-label` ("02 About · Modes", "03 About · Logbook", "04 About · Security", "05 About · Map"). Tap through the prototype to see the flow.

## About the design files
This is an HTML design reference, not production code. Rebuild it in React Native / Expo inside the existing `app/onboarding.tsx`, reusing `PrimaryButton`, the dots/back header, `s.*` styles and `C = NavyColors`. The iPhone frame is only there for presentation.

In the HTML, **ignore** the leftover code for the paper spread (`#book`, `.book`, `.br`, `.bt`, `.pg`, `.csv`, `.more`, `.mode`, `.secure`). It belongs to earlier versions and is no longer shown.

## Fidelity
**High-fidelity.** Final copy, colors, type and motion.

## Integration in `app/onboarding.tsx`
1. Extend the `Step` type: `'intro1' | 'intro2' | 'intro3' | 'intro4'`.
2. `buildSteps()`: add the intro steps after `'welcome'`, and only for first-time users (not `returning`):
   ```ts
   return [...(returning ? [] : ['welcome','intro1','intro2','intro3','intro4'] as Step[]), 'role', 'subrole', ...mid, 'profile', 'hours'];
   ```
3. Welcome "Get started" goes to `'intro1'`.
4. Screens 2–4: **Continue** goes to the next step. **Skip intro** calls `setStep('role')`.
5. Screen 5: the only button is **"Set up my logbook"**, which calls `setStep('role')`. This screen has no Skip link.
6. The dots and Back already work from `steps`/`stepIdx`.

## Shared layout for all four screens
Everything is centered, and the message sits in the middle of the screen.

- **Container**: `flex:1`, `alignItems:'center'`, `justifyContent:'center'`, `textAlign:'center'`. Buttons are pinned at the bottom as in the other steps.
- **Text block** (maxWidth 300, centered, drawn above the rings):
  - Eyebrow: Menlo 10pt, weight 700, letterSpacing 1.6, uppercase, in the screen's accent color.
  - Headline: 40pt (36 on screen 5), weight 800, letterSpacing −1.2, lineHeight 1.02. Two lines: line 1 is white, line 2 is in the accent color.
  - Line: 15pt, `#7FA8C8`, lineHeight 21, maxWidth 270, marginTop 16.
- **Radar rings**: the key motion, which the owner wants kept. Four concentric circles, all centered behind the text:
  - Outer: Ø420, border 1, accent at 6% opacity.
  - Middle: Ø340, border 1, accent at 10%.
  - Inner: Ø250, border 1, accent at 16%.
  - **Sweep**: Ø340, border 1.5, transparent except the top edge in the full accent color, with a soft conic trail (accent 10% fading to transparent over about 80°). It rotates 360° continuously and linearly: 6 s on screen 2, 7 s on screen 3, 8 s on screen 4, 6 s on screen 5.
  - RN: `react-native-svg` circles. Drive the sweep with Reanimated `withRepeat(withTiming(360,{duration, easing: Easing.linear}), -1)` on a rotate transform. The trail can be an SVG arc with a linear-gradient stroke, or it can be left out if that is simpler.
- **Buttons**: `PrimaryButton` (cyan `#00C8E8`, text `#0A1628`, arrow icon). Below it, "Skip intro" as a text button: 13.5pt, weight 600, `#7FA8C8`, height 30, gap 10.
- Background `#000000`, as in the rest of the onboarding.

## Screen 2: Every aircraft (accent cyan `#00C8E8`)
- Eyebrow: **"Every type of pilot"**
- Headline: **"One logbook."** / **"Every aircraft."**
- Line: **"Your all-in-one securely encrypted logbook for easy and intuitive use."** (owner's copy, verbatim)

## Screen 3: Paper logbook (accent gold `#FFB830`)
- Eyebrow: **"Your paper logbook"**
- Headline: **"Log it here."** / **"Copy it there."**
- Line: **"Page for page and row for row, with every total carried forward."**
- FREE tag, marginTop 22: a badge **FREE** (Menlo 10, weight 800, letterSpacing 1, bg `#00E8A0`, text `#0A1628`, padding 4/7, radius 5), then gap 10, then **"Import any CSV, from any app"** (13.5pt, weight 600, white).

## Screen 4: Security (accent green `#00E8A0`)
- Eyebrow: **"Security"**
- Headline: **"No account."** / **"Only you."**
- Line: **"Your flights live on your phone in an AES-256 encrypted database. We never see them."**
- Facts, marginTop 22, gap 6, wrapping, centered. Each is a pill with Menlo 10.5, weight 700, letterSpacing 0.8, color `#00E8A0`, border 1 `rgba(0,232,160,.35)`, fully rounded, padding 5/10.
  - **"AES-256"** · **"No sign-up"** · **"No servers"**

## Screen 5: Airport globe (accent cyan)
- Layout is a column, centered, gap 30: the globe stage on top, then the text block.
- **Globe stage** 220×220. Rings are centered on the globe: Ø330 (6%), Ø262 (10%), and the sweep at Ø262.
- **Globe** 220×220, drawn above the rings.
  - Orthographic projection with real land outlines (d3-geo plus world-atlas `land-110m` in the prototype). It auto-rotates slowly and the user can drag to spin it.
  - Colors: sphere gradient `#13294A`→`#0A1628`, graticule `rgba(127,168,200,.08)`, land `#152338` with stroke `#1F4468`, rim `rgba(0,200,232,.35)`.
  - Cyan airport dots fade toward the edge. **Use the app's real airport database**; the prototype samples dots on land.
  - Gold pulsing dots mark the user's flown airports. This will be empty on first run.
  - RN: `react-native-svg` plus d3-geo `geoPath`, or reuse an existing globe/map component.
- Eyebrow: **"Your world"**
- Headline (36pt): **"Every airport."** / **"One map."**
- Line: **"Quicklog, photo logging, weather and much more, all in one app."**
- Button: **"Set up my logbook"**, which goes to `'role'`.

## Copy notes
- The security claims come from the owner's Privacy Policy: AES-256 via SQLCipher, stored on the device, no account.
- "No servers" is true for flight data. The AI features do send images and text through the Cloudflare proxy, but nothing is stored. The owner may change the pill to "Nothing stored on servers".
- The CSV import is described as free. Check that AI column mapping does not charge Blade-coins during onboarding.
- Swedish strings: follow the file's `sv ? … : …` pattern.

## Assets
None needed for screens 2–5. Everything is drawn with text, SVG rings and the globe. `img/` holds only the images used by the existing screens 1 and 6 in the prototype.
