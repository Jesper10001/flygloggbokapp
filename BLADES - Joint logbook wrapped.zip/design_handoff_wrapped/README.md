# Handoff: BLADES Wrapped (logbook recap) — redesign

## Overview

**Wrapped** is the Spotify-Wrapped-style recap shown after a pilot imports/scans
their logbook for the first time (and re-runnable from Settings). It's both an
*entry point* into the app and a *sales pitch* for what BLADES delivers. This
package is a **full redesign** of the existing feature — a bolder, editorial,
auto-advancing story with richer chapters, a world map, a globe "distance flown"
visual, and an adaptive licence-progress slide.

**Scope: pilot-manned only** (helicopter & fixed-wing). Do not show it in drone
mode.

### What exists today (to be replaced)
- Route: `app/wrapped.tsx` → renders `components/wrapped/WrappedStories.tsx`.
- Opened via `store/wrappedStore.ts` (`maybeOpenAfterImport()`) after CSV / scan
  / manual import, and from Settings.
- The current `WrappedStories` is a simpler tap-through deck. **Keep the route
  and the store trigger; rebuild `WrappedStories` (and its kit) to match this
  design.** `WrappedHost.tsx` / `WrappedKit.tsx` can be reused or replaced.

## About the design files

The files in `source/` are a **design reference built in HTML/React+Babel** — a
prototype showing the intended look, motion, and behavior. They are **not
production code to ship**. Recreate this in the app's existing **React Native /
Expo** environment, reusing its components, `Colors` tokens, fonts, and data
layer (everything below maps to real `db/flights.ts` functions and
`FlightStats`). The HTML uses `<div>`/SVG/CSS; translate to RN
`View`/`Text`/`react-native-svg`/`Animated` equivalents.

Prototype-only scaffolding (do **not** port): `wrapped/ios-frame.jsx` (fake
device bezel), `wrapped/tweaks-panel.jsx` (the Tweaks panel + the "Experience"
demo control), `wrapped/app.jsx` (mount harness). The real screen mounts inside
the actual app, full-screen.

## Fidelity

**High-fidelity.** Final colors, typography, spacing, motion. Recreate
pixel-faithfully on a ~393×812 portrait screen. Sizes below are in CSS px at that
width — scale to the device.

---

## The story engine (`WrappedStories`)

A full-screen vertical story on `Colors.background` (`#0A1628`), one chapter
mounted at a time.

- **Progress bars**: a row of thin segments at the very top (one per chapter).
  Past = filled accent; current = fills left→right over the chapter's duration;
  future = empty (`rgba(255,255,255,0.18)` track).
- **Header row** (below the bars): the **BLADES Joint Logbook lockup logo**
  top-left (height ~26 px), and a close (✕) button top-right. The word "WRAPPED"
  / "PAUSED" can sit before the ✕ in mono micro-caps (optional).
- **Auto-advance**: each chapter has its own duration (see table). When it
  elapses, advance. A driver (rAF/`Animated`) fills the active progress bar.
- **Navigation**: tap right 70% = next, tap left 30% = previous. **Press-and-hold
  pauses** (resume on release). Auto-advance is **toggleable** (a real user
  setting is fine; in the prototype it's a tweak).
- **End card**: after the last chapter — large BLADES **B mark** (~180 px) with a
  soft accent glow, the line *"That's your logbook."*, and a "↺ Watch again"
  button that restarts at chapter 0.
- Each chapter animates its content in on mount (the design gates reveals on an
  `active` flag): titles/labels rise + fade, numbers **count up** from 0, bars
  and chart elements grow/draw in, the route/orbit lines stroke-draw.

### Source files (the real logic to port)
| File | Contents |
|---|---|
| `wrapped/story.jsx` | Engine: progress bars, auto-advance timer, tap zones, hold-to-pause, end card, **aircraft-chapter gating**. |
| `wrapped/chapters.jsx` | The 14 chapter components + the chapter list with per-chapter durations. |
| `wrapped/shared.jsx` | Palette, demo data, **EASA licence tables + profiles**, motion hooks (`useReveal`, `useCountUp`), primitives (`Eyebrow`, `HeroNum`, `ChapterTitle`, `StatTrio`, `ChapterBG`). |
| `wrapped/charts.jsx` | Data visuals: monthly bars, role split, day/night + IFR meters, type breakdown, route map, week bars, currency ring, **adaptive EASA bars**. |
| `wrapped/map.jsx` | World network map (stand-in), top-10 + bottom-5 airport lists, **globe + orbit** distance visual. |
| `wrapped/CLAUDE_CODE_MAP_PROMPT.md` | Separate spec for swapping the stand-in map for the **native Apple map**. |

---

## Chapters (in order)

Each chapter has an **editorial kicker** at the top — a thin accent rule + a
**Fraunces italic** label in the accent color (e.g. *— Total time aloft*). NOT
the old mono/uppercase/glowing-dot style. Content is **vertically centered**.

Durations below are the design values; the engine **adds +5 s to each** (slides
linger). Tune to taste.

| # | Key | Kicker | Headline / hero | Data source |
|---|---|---|---|---|
| 1 | cover | *Logbook Wrapped* | "Every hour you've flown, {firstName}." + "{flights} flights. {airports} airports. Your whole logbook, read back to you." | `firstName` (setting `profile_first_name`), `total_flights`, visited-airport count |
| 2 | totals | *Total time aloft* | **{total_time} HOURS** + "{days} full days in command" + trio (YTD / 12 mo / flights) + **globe** (see below) | `FlightStats.total_time`, `year_to_date`, `last_12_months`, `total_flights` |
| 3 | monthly | *Over the last 12 months* | "You flew most in {bestMonth}." + animated month bars, peak highlighted | `getMonthlyHours()` |
| 4 | map | *Your network* | full-bleed **map** + "{N} airports" + "Across {C} countries — every one flown from {home}" | `getVisitedAirportIcaos()` + coords; see map prompt |
| 5 | airports | *Most-visited airports* | "Your top ten." ranked bars **+ "Least visited" bottom-five** | top/bottom of the visited-airport visit counts |
| 6 | reach | *How far it reaches* | "{C} countries, corner to corner." + N/S/E/W extreme airports + span km | visited-airport coordinates (min/max lat/lon, great-circle) |
| 7 | aircraft | *What you flew* | "{types} types. {tails} tails." + most-flown type + per-type hours bars | per-flight `aircraft_type` / `registration`; `getAllAircraftTypes()`. **GATED — see below** |
| 8 | roles | *In which seat* | "{picPct}% of it as pilot in command." + stacked PIC/Co-pilot/Dual | `total_pic`, `total_co_pilot`, `total_dual` |
| 9 | daynight | *Light & rules* | "{night_h} hours flown after dark." + Day/Night & IFR/VFR meters + landings trio | `total_night`, day = `total_time-total_night`, `total_ifr`, `total_vfr`, `total_landings_day/night` |
| 10 | longest | *Your longest flight* | **{nm} NM** + route line "{dep} → {arr} · {dur} · {date}" + animated route map | `longest_xc_*` fields + `getXCLegsForDate()` |
| 11 | bestweek | *Your busiest week* | **{hoursLabel}** + "{week} · {sectors} sectors · {airports} airports" + day bars | `getTopWeeks(1)` / `best_week_*` + `getFlightsForWeek()` |
| 12 | currency | *Your current rhythm* | animated ring "{index}% {zone}" + "The last 14 days against your own baseline." | `getStressHours()` (recent14 / yearAvg14) — same math as dashboard |
| 13 | easa | *The road to your licence* | **Adaptive** — met state OR progress to closest licence (see below) | hour totals vs EASA minimums |
| 14 | outro | *This is just the beginning* | "Every flight you log sharpens the picture." + 4 feature bullets + "Enter BLADES ›" | static copy (the sales pitch) |

**Chapter inclusion is conditional** (mirror the prototype): a chapter only
appears when its data exists — e.g. monthly only if there are monthly hours,
bestweek only if `best_week_start`, longest only if `longest_xc_date`, currency
only if recent activity (`recent14 > 0`), map/airports only if visited airports
exist. The current `WrappedStories` already does this gating — preserve it.

---

## Special behaviors (the three things just added)

### A. Globe "distance around the Earth" (chapter 2, below the stats)
- A stylized **globe** (sphere with lat/long graticule) wrapped by a dashed
  **orbit ring** and a small glowing dot circling it. The ring must read as 3D:
  its **back half is drawn behind the globe, its front half in front** (in the
  prototype, `ringBack` is drawn before the sphere, `ringFront` + dot after).
- Below it: **"{laps}× times around the Earth"** (big Fraunces), with a small
  line **"≈ {km} km flown · cruise × time"**.
- **Distance** = Σ over all flights of `total_time × cruise_speed_kts` for that
  flight's aircraft type → nautical miles → km. Cruise speed per type is in
  `aircraft_registry.cruise_speed_kts` (`getAircraftCruiseSpeed(type)`); time is
  `flights.total_time`. **Laps** = distance_km ÷ 40 075 km (Earth circumference).
- If laps ≥ 1 → "{round(laps)}× · times around the Earth". If laps < 1 →
  "{round(laps×100)}% · of one lap around the Earth".
- Only count real flight types with a known cruise speed; skip sim/FFS rows
  (same exclusion as `getFlightStats`).

### B. Top-10 + Bottom-5 airports (chapter 5)
- **Top ten**: the 10 most-visited airports — rank, ICAO, a bar (width ∝ visits,
  #1 filled accent), city, and "{visits}×". #1 gets a small "HOME" tag.
- **Bottom five**: below a "Least visited" sub-label — the 5 **least**-visited
  airports (ascending), compact rows: ICAO · city · "{visits}×".
- Both come from the same visit-count aggregation already used for the milestone
  ("Visited airports") — order desc for top, asc for bottom. Exclude temporary
  places without coordinates if you like (matches the map).

### C. Adaptive EASA slide (chapter 13)
- Define EASA **hour minimums** per licence (see `W_LICENCES` in `shared.jsx`):
  - **PPL(A)**: total 45, PIC 10, cross-country 5.
  - **CPL(A)**: total 200, PIC 100, XC 20, night 5, instrument 10.
  - **ATPL(A)**: total 1500, PIC 250, XC 200, night 100, instrument 75, multi-pilot 500.
  (These are the hour-threshold subset — the app may already track more in
  `EASAProgressChart`; reuse those thresholds if they're authoritative.)
- The pilot's "have" values come from `FlightStats`: total=`total_time`,
  pic=`total_pic`, night=`total_night`, ifr/instrument=`total_ifr`,
  multi-pilot=`total_multi_pilot`, cross-country = sum of XC time (the app's
  existing XC measure).
- **Logic**: a licence is *met* when every one of its bars is satisfied. The
  slide targets the **lowest licence not yet fully met** (PPL → CPL → ATPL):
  - If **ATPL is fully met** → celebratory state: *"Every ATPL(A) hour
    requirement — met."* with all bars green + ✓.
  - Otherwise → **progress state** for that closest licence: *"On your way to
    {CODE}."*, a line *"{progress}% there · {metCount}/{n} requirements met"*,
    and bars where met = green + ✓ and in-progress = accent (no ✓). `progress` =
    average of `min(have/need, 1)` across the licence's bars.
- The prototype exposes an **Experience** tweak (Student / CPL / ATPL) only to
  preview the three states — **not** for production; the real slide derives state
  from `FlightStats`.

### Aircraft chapter gating (chapter 7)
- **Only show chapter 7 if the pilot has 2+ aircraft registered** (≥2 distinct
  registrations/tails). If they've only ever flown one aircraft, omit it.
  (Prototype: `story.jsx` filters the chapter list on
  `W_DATA.registrations >= 2`.)

---

## Motion & timing
- **Reveals** fire when a chapter becomes active: kicker/title/sub rise 16 px +
  fade (≈0.7 s, cubic-bezier(.2,.7,.2,1), small stagger).
- **Count-ups**: hero numbers and the currency % ease from 0 → target over
  ~1.3–1.6 s (ease-out cubic). Must reach the real value (never stick at 0).
- **Bars/meters**: width/height grow from 0 with ~0.9–1 s cubic-bezier and a
  small per-item stagger.
- **Route line / orbit ring**: stroke-dash draw-in (~1.1–1.4 s).
- Respect reduced-motion: render final state without animating.

## Design tokens (Navy theme — `constants/colors.ts`)
| Token | Value | Use |
|---|---|---|
| `background` | `#0A1628` | screen |
| (deep) | `#06101E` | map/end-card backdrop, scrims |
| `surface` / `card` | `#0F1E3A` | panels |
| `surface2` | `#132845` | globe sphere highlight |
| `cardBorder` | `#1A3A5A` | hairlines, graticule |
| `separator` | `#122030` | bar tracks |
| **accent / primary** | **`#00C8E8`** (cyan) | kicker, hero accents, bars, route, orbit, CTA. **Tweakable** (cyan / gold `#FFB830` / mint `#00E8A0` / violet `#9B8CFF`) |
| `success` | `#00E8A0` | met EASA bars / ✓ |
| `textPrimary` | `#FFFFFF` | hero text |
| `textSecondary` | `#7FA8C8` (proto `#A8BFD6`) | body |
| `textMuted` | `#5A7FA0` | labels / meta |
| ink-on-accent | `#04101F` | text on accent buttons |

**Type**: Fraunces (serif display — kickers in italic, hero numerals, titles,
end-card line), JetBrains Mono (data — values, ICAO, labels, meta), Inter / SF
(body). The app already loads Fraunces + JetBrainsMono.

**Default look for export**: editorial style + cyan accent (the prototype's
default). A "cinematic" variant (larger numerals, stronger color fields) exists
as a tweak — optional.

## Assets (in `source/wrapped/`)
- `blades-lockup.png` — horizontal "BLADES Joint Logbook" lockup, **recolored
  light** so it reads on the dark header (blue mark + cream text). Used top-left
  (~26 px tall). Prefer the app's real logo asset if one exists in a light
  variant; otherwise use this.
- `blades-mark.png` — the blue **B mark**, used large (~180 px) on the end card.
- No other bundled imagery. Icons are inline SVG (checkmarks, plane glyph).

## Data-source cheat-sheet
Everything is computed from data the app already has — **invent nothing new**:
`getFlightStats()` (all totals + best-week + longest-xc), `getMonthlyHours()`,
`getVisitedAirportIcaos()` / `getVisitedAirportDates()` + `db/icao` coords,
`getTopWeeks()` / `getFlightsForWeek()`, `getXCLegsForDate()`, `getStressHours()`,
`getAircraftCruiseSpeed()` / `getAllAircraftTypes()`, `getSetting('profile_first_name')`.
Reuse existing components where they fit: `FlightChart`, `ClassBreakdown`,
`EASAProgressChart` (thresholds), `GlobalAirportMap` (the map — see its prompt),
`BWDayBars` / `MiniRouteMap`.

## Files in this bundle
- `source/Wrapped.html` — open in a browser to view the full interactive
  prototype (tap to advance; Tweaks toolbar for accent / auto-advance / style /
  Experience).
- `source/wrapped/*.jsx` — the prototype source (see the table above). `shared`,
  `map`, `charts`, `chapters`, `story` are the real reference; `app`,
  `ios-frame`, `tweaks-panel` are prototype-only scaffolding.
- `source/wrapped/CLAUDE_CODE_MAP_PROMPT.md` — the native Apple-map task for the
  World map chapter.
