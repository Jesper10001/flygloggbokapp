// Wrapped story engine — progress-bar header, auto-advance timer, tap zones,
// hold-to-pause. One chapter mounted at a time so entrance animations fire.

function WrappedStory({ accent, variant, autoAdvance, experience }) {
  const W = window.W_C;
  const chapters = React.useMemo(() => window.W_CHAPTERS.filter((c) =>
    // The aircraft chapter only appears when 2+ aircraft (tails) are registered.
    c.key !== 'aircraft' || window.W_DATA.registrations >= 2
  ), []);
  const [index, setIndex] = React.useState(0);
  const [progress, setProgress] = React.useState(0); // 0..1 for active bar
  const [paused, setPaused] = React.useState(false);
  const [done, setDone] = React.useState(false);

  const safe = Math.min(index, chapters.length - 1);
  const chapter = chapters[safe];
  const dur = chapter.dur + 5000; // each slide shown ~5s longer

  const next = React.useCallback(() => {
    setIndex((i) => {
      if (i >= chapters.length - 1) { setDone(true); return i; }
      return i + 1;
    });
    setProgress(0);
  }, [chapters.length]);

  const prev = React.useCallback(() => {
    setIndex((i) => Math.max(0, i - 1));
    setProgress(0);
    setDone(false);
  }, []);

  // restart progress whenever the slide changes
  React.useEffect(() => { setProgress(0); }, [safe]);

  // auto-advance driver
  React.useEffect(() => {
    if (!autoAdvance || paused || done) return;
    let raf, start = null, acc = progress * dur;
    const tick = (now) => {
      if (start === null) start = now;
      const elapsed = acc + (now - start);
      const p = Math.min(1, elapsed / dur);
      setProgress(p);
      if (p >= 1) { next(); return; }
      raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [safe, autoAdvance, paused, done]);

  // hold-to-pause + tap-to-navigate
  const holdRef = React.useRef({ t: 0, held: false });
  const onDown = () => {
    holdRef.current.held = false;
    holdRef.current.t = setTimeout(() => { holdRef.current.held = true; setPaused(true); }, 220);
  };
  const onUp = (dir) => {
    clearTimeout(holdRef.current.t);
    if (holdRef.current.held) { setPaused(false); return; }
    if (dir === 'prev') prev(); else next();
  };

  const restart = () => { setIndex(0); setProgress(0); setDone(false); };

  return (
    <div style={{ position: 'absolute', inset: 0, background: W.bgDeep, overflow: 'hidden',
                  fontFamily: window.W_FONT }}>
      {/* chapter */}
      {!done && (
        <chapter.Comp key={chapter.key} active={!paused || true} accent={accent} variant={variant} experience={experience} />
      )}

      {/* end card */}
      {done && <WEndCard accent={accent} variant={variant} onRestart={restart} />}

      {/* top scrim for legibility of bars */}
      <div style={{ position: 'absolute', top: 0, left: 0, right: 0, height: 100, pointerEvents: 'none',
                    zIndex: 4, background: `linear-gradient(180deg, ${W.bgDeep}, ${W.bgDeep}cc 50%, transparent)` }}/>

      {/* progress bars */}
      {!done && (
        <div style={{ position: 'absolute', top: 54, left: 14, right: 14, zIndex: 6,
                      display: 'flex', gap: 4 }}>
          {chapters.map((c, i) => (
            <div key={c.key} style={{ flex: 1, height: 3, borderRadius: 2,
                                      background: 'rgba(255,255,255,0.18)', overflow: 'hidden' }}>
              <div style={{ height: '100%', borderRadius: 2, background: accent,
                            width: i < safe ? '100%' : i === safe ? `${progress * 100}%` : '0%',
                            transition: i === safe ? 'none' : 'width .2s linear' }}/>
            </div>
          ))}
        </div>
      )}

      {/* header row: brand + close */}
      {!done && (
        <div style={{ position: 'absolute', top: 66, left: 16, right: 16, zIndex: 6,
                      display: 'flex', alignItems: 'center', justifyContent: 'space-between',
                      pointerEvents: 'none' }}>
          <img src="wrapped/blades-lockup.png" alt="BLADES Joint Logbook"
               style={{ height: 26, width: 'auto', display: 'block' }} />
          <div style={{ display: 'flex', alignItems: 'center', gap: 10, pointerEvents: 'auto' }}>
            {autoAdvance && (
              <span style={{ fontFamily: window.W_MONO, fontSize: 9, fontWeight: 700,
                             letterSpacing: '0.14em', color: paused ? accent : W.muted }}>
                {paused ? 'PAUSED' : 'WRAPPED'}
              </span>
            )}
            <div style={{ width: 26, height: 26, borderRadius: '50%',
                          background: 'rgba(255,255,255,0.12)', display: 'grid', placeItems: 'center' }}>
              <svg width="11" height="11" viewBox="0 0 12 12"><path d="M2 2l8 8M10 2l-8 8" stroke={W.text2} strokeWidth="1.6" strokeLinecap="round"/></svg>
            </div>
          </div>
        </div>
      )}

      {/* tap zones */}
      {!done && (
        <>
          <div data-nav="prev" onPointerDown={onDown} onPointerUp={() => onUp('prev')}
               style={{ position: 'absolute', top: 92, bottom: 0, left: 0, width: '30%', zIndex: 5 }} />
          <div data-nav="next" onPointerDown={onDown} onPointerUp={() => onUp('next')}
               style={{ position: 'absolute', top: 92, bottom: 0, right: 0, width: '70%', zIndex: 5 }} />
        </>
      )}
    </div>
  );
}

function WEndCard({ accent, variant, onRestart }) {
  const W = window.W_C;
  return (
    <div style={{ position: 'absolute', inset: 0, overflow: 'hidden' }}>
      <window.ChapterBG accent={accent} variant={variant} />
      <div style={{ position: 'absolute', inset: 0, display: 'flex', flexDirection: 'column',
                    alignItems: 'center', justifyContent: 'center', gap: 22, padding: 28, textAlign: 'center' }}>
        <window.Rise show={true} delay={100}>
          <img src="wrapped/blades-mark.png" alt="BLADES" width="180" height="189"
               style={{ display: 'block', filter: `drop-shadow(0 12px 40px ${accent}66)` }} />
        </window.Rise>
        <window.Rise show={true} delay={250}>
          <window.ChapterTitle variant={variant}>That's your logbook.</window.ChapterTitle>
        </window.Rise>
        <window.Rise show={true} delay={420}>
          <button onClick={onRestart} style={{
            padding: '13px 22px', borderRadius: 999, border: `1px solid ${W.border}`,
            background: 'transparent', color: W.text2, fontFamily: window.W_FONT,
            fontSize: 14, fontWeight: 600, cursor: 'pointer',
          }}>↺ Watch again</button>
        </window.Rise>
      </div>
    </div>
  );
}

Object.assign(window, { WrappedStory });
