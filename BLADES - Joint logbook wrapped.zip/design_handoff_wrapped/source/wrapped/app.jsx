// Wrapped prototype — mounts the story inside an iOS frame + Tweaks panel.

const W_TWEAK_DEFAULTS = /*EDITMODE-BEGIN*/{
  "accent": "#00C8E8",
  "autoAdvance": true,
  "style": "editorial",
  "experience": "ATPL"
}/*EDITMODE-END*/;

const W_ACCENT_OPTIONS = ['#00C8E8', '#FFB830', '#00E8A0', '#9B8CFF'];

function WrappedApp() {
  const [tw, setTweak] = window.useTweaks(W_TWEAK_DEFAULTS);
  const accent = tw.accent || W_ACCENT_OPTIONS[0];
  const variant = tw.style || 'editorial';
  const autoAdvance = tw.autoAdvance !== false;
  const experience = tw.experience || 'ATPL';

  return (
    <>
      <div style={{
        position: 'fixed', inset: 0, display: 'grid', placeItems: 'center',
        background: 'radial-gradient(1100px 700px at 50% -200px, #0E1E33 0%, transparent 70%), #05080F',
        backgroundColor: '#05080F',
        padding: 20, boxSizing: 'border-box',
      }}>
        <window.IOSDevice width={393} height={812} dark={true}>
          {/* remount the whole story when variant/autoAdvance change so timers reset cleanly */}
          <window.WrappedStory
            key={`${variant}-${autoAdvance}`}
            accent={accent}
            variant={variant}
            autoAdvance={autoAdvance}
            experience={experience}
          />
        </window.IOSDevice>
      </div>

      <window.TweaksPanel title="Tweaks">
        <window.TweakSection label="Look" />
        <window.TweakRadio
          label="Style"
          value={variant}
          options={['editorial', 'cinematic']}
          onChange={(v) => setTweak('style', v)}
        />
        <window.TweakColor
          label="Accent"
          value={accent}
          options={W_ACCENT_OPTIONS}
          onChange={(v) => setTweak('accent', v)}
        />
        <window.TweakSection label="Playback" />
        <window.TweakToggle
          label="Auto-advance"
          value={autoAdvance}
          onChange={(v) => setTweak('autoAdvance', v)}
        />
        <window.TweakSection label="Licence slide (demo)" />
        <window.TweakRadio
          label="Experience"
          value={experience}
          options={['Student', 'CPL', 'ATPL']}
          onChange={(v) => setTweak('experience', v)}
        />
      </window.TweaksPanel>
    </>
  );
}

ReactDOM.createRoot(document.getElementById('root')).render(<WrappedApp />);
