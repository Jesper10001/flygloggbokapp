# Claude Code task — Wrapped "World map" chapter (native Apple map)

## Context
The Wrapped story (post-import recap, **pilot-manned only**) has a full-screen
**World map** chapter. In the HTML design prototype this chapter is a *stylized
stand-in* (`wrapped/map.jsx` → `W_WorldMap`): an equirectangular graticule with
glowing pins and animated arcs from the home base. It uses real airport
coordinates but is **not** a real map.

In the app, this chapter must render the **real native map** instead — the same
one already used under **Settings → Manage airports → global map**.

## What to build
Replace the stand-in with the existing **`components/GlobalAirportMap.tsx`**
(Apple Maps via `react-native-maps`, level-of-detail clustering: country flags →
blue dots → ICAO labels). It already takes `airports: SeedRow[]`
(`[icao, name, country, region, lat, lon]`).

Wire it into a new Wrapped slide that matches the other chapters' look:

1. **Map fills the slide full-bleed** (top ~60–65% of the screen), with a
   bottom gradient scrim fading into `Colors.background` so the overlay text is
   legible — mirror the prototype's `WMap` chapter layout
   (`wrapped/chapters.jsx`).
2. Feed it **only the pilot's visited airports**, not the whole 34k seed DB:
   - `const icaos = await getVisitedAirportIcaos();`  (db/flights.ts)
   - resolve coordinates via `getAirportCoordinates(icaos)` /
     `getSeedAirports()` filtered to those ICAOs (db/icao.ts) to build
     `SeedRow[]`.
   - Exclude temporary/unlocated places (`temporary` flag), same as
     `AirportMapWidget`.
3. **Auto-frame** the camera to the bounds of the visited airports on mount
   (compute min/max lat/lon → region with padding) instead of the world view,
   so the recap opens already centered on the pilot's network. A slow
   ease-in/zoom as the slide becomes active would match the Wrapped motion.
4. **Overlay**, bottom-left, over the scrim (use `Eyebrow` + hero number from
   `WrappedKit`):
   - eyebrow: `YOUR NETWORK`
   - hero: visited-airport **count** (`icaos.length`) + the word "airports"
   - sub: `Across {N} countries — every one flown from {homeBase}`. Country
     count = distinct `country` over the visited rows; home base = the
     most-visited airport (already computed for the Top-10 chapter).
5. **Disable map gesture interaction inside the auto-advancing story**
   (`scrollEnabled={false}`, `zoomEnabled={false}`, `pitchEnabled={false}`,
   `rotateEnabled={false}`) so a swipe advances the story rather than panning
   the map — except optionally allow a tap-and-hold "explore" affordance that
   pauses auto-advance and unlocks the map (nice-to-have).
6. Keep it on the **Navy** theme (`userInterfaceStyle="dark"`), accent =
   the Wrapped accent prop.

## Accent / tokens
Use `Colors` (constants/colors.ts). Accent default cyan `#00C8E8`; the rest of
the Wrapped story already threads an `accent` prop — pass the same one to the
pins/overlay so the chapter re-themes with the others.

## Data rules
**Do not introduce any data the app doesn't already compute.** Everything here
comes from `getVisitedAirportIcaos`, `getAirportCoordinates`/`getSeedAirports`,
and the existing Top-10 aggregation. No new tables, no external lookups.

## Acceptance
- Opens framed on the pilot's own airports (not the whole globe).
- Country-flag clusters when zoomed out; dots + ICAO labels when the camera is
  tight (inherits `GlobalAirportMap` LOD behavior).
- Overlay count/countries/home-base match the Top-10 chapter and the
  `FlightStats`-derived values.
- Swiping advances the story; the map doesn't hijack the gesture.
- Renders only for `profile.mainRole === 'pilot-manned'`.
