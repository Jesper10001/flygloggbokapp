// World map + top-10 airports for Wrapped.
//
// NOTE: in the app this chapter renders the native Apple map
// (components/GlobalAirportMap.tsx, react-native-maps) which can't run in an
// HTML prototype. This is a styled stand-in: real airport coordinates, an
// equirectangular graticule, glowing pins and animated great-circle-ish arcs
// from the home base. See wrapped/CLAUDE_CODE_MAP_PROMPT.md for the native swap.

const W_AIRPORT_COORDS = {
  ESSA: [59.65, 17.93], EDDF: [50.03, 8.57], EKCH: [55.62, 12.65], EGLL: [51.47, -0.46],
  LFPG: [49.0, 2.55], LOWW: [48.11, 16.57], LEBL: [41.30, 2.08], LSZH: [47.46, 8.55],
  EDDM: [48.35, 11.79], EHAM: [52.31, 4.76],
  ENBO: [67.28, 14.36], GCLP: [27.93, -15.39], BIKF: [63.99, -22.61], LCLK: [34.88, 33.63],
};

// equirectangular window over Europe + reach extremes
const W_MAP_WIN = { lonMin: -30, lonMax: 40, latMin: 24, latMax: 70 };

function wProject(lat, lon, w, h) {
  const { lonMin, lonMax, latMin, latMax } = W_MAP_WIN;
  return {
    x: ((lon - lonMin) / (lonMax - lonMin)) * w,
    y: ((latMax - lat) / (latMax - latMin)) * h,
  };
}

function W_WorldMap({ accent, active, height = 460, labels = true }) {
  const W = window.W_C;
  const w = 393, h = height;
  const home = wProject(...W_AIRPORT_COORDS.ESSA, w, h);

  // all pins (top airports + extremes), de-duped
  const pins = React.useMemo(() => {
    const set = {};
    window.W_DATA.topAirports.forEach((a, i) => {
      if (W_AIRPORT_COORDS[a.icao]) set[a.icao] = { ...a, big: true, rank: i };
    });
    ['ENBO', 'GCLP', 'BIKF', 'LCLK'].forEach((ic) => { if (!set[ic]) set[ic] = { icao: ic, big: false, rank: 99 }; });
    return Object.keys(set).map((ic) => {
      const p = wProject(...W_AIRPORT_COORDS[ic], w, h);
      return { ...set[ic], ...p };
    });
  }, [w, h]);

  // graticule lines
  const grat = [];
  for (let lon = -30; lon <= 40; lon += 10) {
    const a = wProject(W_MAP_WIN.latMin, lon, w, h);
    const b = wProject(W_MAP_WIN.latMax, lon, w, h);
    grat.push(<line key={`v${lon}`} x1={a.x} y1={a.y} x2={b.x} y2={b.y} />);
  }
  for (let lat = 30; lat <= 70; lat += 10) {
    const a = wProject(lat, W_MAP_WIN.lonMin, w, h);
    const b = wProject(lat, W_MAP_WIN.lonMax, w, h);
    grat.push(<line key={`h${lat}`} x1={a.x} y1={a.y} x2={b.x} y2={b.y} />);
  }

  // arcs from home to the big airports (bow north)
  const arcs = pins.filter((p) => p.big && p.icao !== 'ESSA').map((p) => {
    const mx = (home.x + p.x) / 2, my = (home.y + p.y) / 2;
    const dist = Math.hypot(p.x - home.x, p.y - home.y);
    const cy = my - dist * 0.22;
    return { icao: p.icao, d: `M ${home.x} ${home.y} Q ${mx} ${cy} ${p.x} ${p.y}` };
  });

  return (
    <svg width="100%" height={h} viewBox={`0 0 ${w} ${h}`} preserveAspectRatio="xMidYMid slice"
         style={{ display: 'block' }}>
      <defs>
        <radialGradient id="w-map-glow" cx="50%" cy="38%" r="62%">
          <stop offset="0%"  stopColor={accent} stopOpacity="0.16" />
          <stop offset="100%" stopColor={W.bgDeep} stopOpacity="0" />
        </radialGradient>
      </defs>
      <rect x="0" y="0" width={w} height={h} fill={W.bgDeep} />
      <rect x="0" y="0" width={w} height={h} fill="url(#w-map-glow)" />

      {/* graticule */}
      <g stroke={W.border} strokeWidth="0.6" opacity={active ? 0.55 : 0}
         style={{ transition: 'opacity 1s ease 0.1s' }}>{grat}</g>

      {/* arcs */}
      <g fill="none" stroke={accent} strokeWidth="1.4" strokeLinecap="round">
        {arcs.map((a, i) => (
          <path key={a.icao} d={a.d}
            strokeDasharray="900" strokeDashoffset={active ? 0 : 900}
            opacity={active ? 0.85 : 0}
            style={{ transition: `stroke-dashoffset 1.1s cubic-bezier(.4,.8,.3,1) ${300 + i * 110}ms, opacity .6s ease ${300 + i * 110}ms` }} />
        ))}
      </g>

      {/* pins */}
      {pins.map((p, i) => {
        const r = p.big ? 4.2 : 2.8;
        const delay = 500 + i * 70;
        return (
          <g key={p.icao}
             style={{ opacity: active ? 1 : 0, transition: `opacity .5s ease ${delay}ms` }}>
            {p.big && (
              <circle cx={p.x} cy={p.y} r={r * 3.2} fill={accent} opacity="0.14">
                {active && <animate attributeName="r" values={`${r};${r * 4};${r}`} dur="2.6s" begin={`${i * 0.3}s`} repeatCount="indefinite" />}
              </circle>
            )}
            <circle cx={p.x} cy={p.y} r={r + 1.6} fill={W.bgDeep} />
            <circle cx={p.x} cy={p.y} r={r} fill={p.icao === 'ESSA' ? W.text : accent} />
            {p.icao === 'ESSA' && <circle cx={p.x} cy={p.y} r={r - 1.6} fill={accent} />}
            {labels && p.big && p.rank < 5 && (
              <text x={p.x + 7} y={p.y - 6} fontFamily={window.W_MONO} fontSize="9"
                    fontWeight="700" fill={W.text} letterSpacing="0.05em"
                    style={{ opacity: active ? 0.9 : 0, transition: `opacity .5s ease ${delay + 120}ms` }}>
                {p.icao}
              </text>
            )}
          </g>
        );
      })}
    </svg>
  );
}

// Top-10 airports — animated ranked bars with count-up visits.
function W_TopAirports({ accent, active }) {
  const W = window.W_C;
  const rows = window.W_DATA.topAirports;
  const max = rows[0].visits;
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 7, alignSelf: 'stretch' }}>
      {rows.map((r, i) => {
        const show = active;
        const pct = (r.visits / max) * 100;
        return (
          <window.Rise key={r.icao} show={show} delay={i * 55}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
              <span style={{
                fontFamily: W_MONO, fontWeight: 700, fontSize: 11, width: 18,
                color: i === 0 ? accent : W.muted,
              }}>{String(i + 1).padStart(2, '0')}</span>
              <span style={{
                fontFamily: W_MONO, fontWeight: 700, fontSize: 13, width: 46,
                color: W.text, letterSpacing: '0.04em',
              }}>{r.icao}</span>
              {r.home && (
                <span style={{
                  fontFamily: W_MONO, fontSize: 8, fontWeight: 700, letterSpacing: '0.12em',
                  color: accent, background: accent + '1F', border: `1px solid ${accent}55`,
                  padding: '2px 6px', borderRadius: 5, textTransform: 'uppercase', whiteSpace: 'nowrap',
                }}>Home</span>
              )}
              <div style={{ flex: 1, position: 'relative', height: 22, display: 'flex', alignItems: 'center' }}>
                <div style={{
                  position: 'absolute', left: 0, top: '50%', transform: 'translateY(-50%)',
                  height: 5, borderRadius: 99,
                  width: show ? `${pct}%` : '0%',
                  background: i === 0
                    ? `linear-gradient(90deg, ${accent}, ${accent}aa)`
                    : W.border,
                  boxShadow: i === 0 ? `0 0 12px ${accent}66` : 'none',
                  transition: `width 1s cubic-bezier(.3,.8,.3,1) ${i * 55 + 120}ms`,
                }}/>
              </div>
              <span style={{
                fontFamily: W_FONT, fontSize: 11, color: W.text3, width: 78,
                whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis',
              }}>{r.city}</span>
              <span style={{
                fontFamily: W_MONO, fontWeight: 700, fontSize: 12, width: 42, textAlign: 'right',
                color: i === 0 ? accent : W.text2, fontVariantNumeric: 'tabular-nums',
              }}>{r.visits}×</span>
            </div>
          </window.Rise>
        );
      })}
    </div>
  );
}

// Least-visited airports — compact list for the lower half of the Top-10 slide.
function W_BottomFive({ accent, active }) {
  const W = window.W_C;
  const rows = window.W_DATA.bottomAirports;
  return (
    <div style={{ alignSelf: 'stretch', display: 'flex', flexDirection: 'column', gap: 7 }}>
      {rows.map((r, i) => (
        <window.Rise key={r.icao} show={active} delay={i * 50}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
            <span style={{ fontFamily: W_MONO, fontWeight: 700, fontSize: 12, width: 46,
                           color: W.text2, letterSpacing: '0.04em' }}>{r.icao}</span>
            <span style={{ flex: 1, fontFamily: W_FONT, fontSize: 11, color: W.text3,
                           whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{r.city}</span>
            <span style={{ fontFamily: W_MONO, fontWeight: 700, fontSize: 11, color: W.muted,
                           fontVariantNumeric: 'tabular-nums' }}>{r.visits}×</span>
          </div>
        </window.Rise>
      ))}
    </div>
  );
}

// Globe + orbit ring — how far around the Earth the pilot has flown.
function W_GlobeOrbit({ accent, active, laps, km }) {
  const W = window.W_C;
  const cx = 100, cy = 100, R = 60;
  const ringFull  = `M ${cx - 90} ${cy} A 90 30 0 1 1 ${cx + 90} ${cy} A 90 30 0 1 1 ${cx - 90} ${cy}`;
  const ringBack  = `M ${cx - 90} ${cy} A 90 30 0 0 0 ${cx + 90} ${cy}`; // top arc (behind globe)
  const ringFront = `M ${cx - 90} ${cy} A 90 30 0 0 1 ${cx + 90} ${cy}`; // bottom arc (in front)
  const whole = laps >= 1;
  const big = whole ? `${Math.round(laps)}×` : `${Math.round(laps * 100)}%`;
  const lbl = whole ? 'times around the Earth' : 'of one lap around the Earth';
  const parallels = [-0.55, 0, 0.55].map((o) => ({ o, rx: R * Math.sqrt(Math.max(0, 1 - o * o)) }));
  return (
    <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 14, alignSelf: 'stretch' }}>
      <svg width={200} height={200} viewBox="0 0 200 200" style={{ display: 'block' }}>
        <defs>
          <radialGradient id="w-globe" cx="38%" cy="30%" r="78%">
            <stop offset="0%" stopColor={W.surface2} />
            <stop offset="68%" stopColor={W.bgDeep} />
            <stop offset="100%" stopColor="#02080F" />
          </radialGradient>
          <clipPath id="w-globe-clip"><circle cx={cx} cy={cy} r={R} /></clipPath>
        </defs>
        {/* orbit ring — back half, behind the globe */}
        <g transform={`rotate(-18 ${cx} ${cy})`}>
          <path d={ringBack} fill="none" stroke={accent} strokeWidth="1.3" strokeDasharray="5 7"
                opacity={active ? 0.45 : 0} style={{ transition: 'opacity .9s ease .2s' }} />
        </g>
        {/* globe body */}
        <circle cx={cx} cy={cy} r={R} fill="url(#w-globe)" stroke={accent} strokeOpacity="0.5" strokeWidth="1" />
        <g clipPath="url(#w-globe-clip)" stroke={accent} strokeWidth="0.7" fill="none"
           opacity={active ? 0.42 : 0} style={{ transition: 'opacity 1s ease .35s' }}>
          {[0.32, 0.64].map((k, i) => (<ellipse key={'m' + i} cx={cx} cy={cy} rx={R * k} ry={R} />))}
          <line x1={cx} y1={cy - R} x2={cx} y2={cy + R} />
          {parallels.map((p, i) => (<ellipse key={'p' + i} cx={cx} cy={cy + R * p.o} rx={p.rx} ry={6} />))}
        </g>
        {/* orbit ring — front half (over the globe) + travelling dot on the full ring */}
        <g transform={`rotate(-18 ${cx} ${cy})`}>
          <path d={ringFront} fill="none" stroke={accent} strokeWidth="1.7" strokeDasharray="5 7"
                opacity={active ? 0.9 : 0} style={{ transition: 'opacity .9s ease .2s' }} />
          <circle r="9" fill={accent} opacity={active ? 0.22 : 0}>
            <animateMotion dur="7s" repeatCount="indefinite" path={ringFull} />
          </circle>
          <circle r="4.5" fill={accent} opacity={active ? 1 : 0}>
            <animateMotion dur="7s" repeatCount="indefinite" path={ringFull} />
          </circle>
        </g>
      </svg>
      <div style={{ textAlign: 'center' }}>
        <div style={{ display: 'flex', alignItems: 'baseline', gap: 9, justifyContent: 'center', flexWrap: 'wrap' }}>
          <span style={{ fontFamily: W_SERIF, fontSize: 42, fontWeight: 600, color: W.text, lineHeight: 1 }}>{big}</span>
          <span style={{ fontFamily: W_MONO, fontSize: 11, fontWeight: 700, letterSpacing: '0.1em',
                         color: accent, textTransform: 'uppercase' }}>{lbl}</span>
        </div>
        <div style={{ fontFamily: W_MONO, fontSize: 10, color: W.muted, marginTop: 7, letterSpacing: '0.05em' }}>
          ≈ {window.fmtInt(km)} km flown · cruise × time
        </div>
      </div>
    </div>
  );
}

Object.assign(window, { W_WorldMap, W_TopAirports, W_BottomFive, W_GlobeOrbit, W_AIRPORT_COORDS, wProject });
