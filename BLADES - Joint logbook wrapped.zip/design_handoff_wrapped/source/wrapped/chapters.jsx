// Wrapped chapters. Each is a component receiving { active, accent, variant }.
// `active` gates entrance/reveal animations; `variant` is 'editorial' | 'cinematic'.

const PAD = 28;
const TOP = 104; // clears status bar + progress bars + brand row

function WChapter({ accent, variant, children, justify = 'center', pad = PAD }) {
  return (
    <div style={{ position: 'absolute', inset: 0, overflow: 'hidden' }}>
      <window.ChapterBG accent={accent} variant={variant} />
      <div style={{
        position: 'absolute', inset: 0, display: 'flex', flexDirection: 'column',
        justifyContent: justify, gap: 18,
        padding: pad, paddingTop: TOP, paddingBottom: 40, boxSizing: 'border-box',
      }}>{children}</div>
    </div>
  );
}

const cap = (accent) => accent; // single tweaked accent throughout

// 1 ── Cover ──────────────────────────────────────────────────────────────────
function WCover({ active, accent, variant }) {
  const D = window.W_DATA;
  const r1 = window.useReveal(active, 150);
  const r2 = window.useReveal(active, 450);
  return (
    <WChapter accent={accent} variant={variant}>
      <window.Eyebrow accent={accent} show={active}>BLADES · Logbook Wrapped</window.Eyebrow>
      <window.Rise show={r1} delay={0}>
        <window.ChapterTitle variant={variant}>
          Every hour<br/>you've flown,<br/>
          <em style={{ fontStyle: 'italic', color: accent }}>{D.firstName}</em>.
        </window.ChapterTitle>
      </window.Rise>
      <window.Rise show={r2}>
        <window.ChapterSub>
          {window.fmtInt(D.totalFlights)} flights. {D.airportsCount} airports.
          Your whole logbook, read back to you.
        </window.ChapterSub>
      </window.Rise>
      <window.Rise show={window.useReveal(active, 900)} style={{ marginTop: 8 }}>
        <div style={{ fontFamily: window.W_MONO, fontSize: 11, letterSpacing: '0.14em',
                      color: window.W_C.muted }}>TAP TO BEGIN ›</div>
      </window.Rise>
    </WChapter>
  );
}

// 2 ── Total hours ──────────────────────────────────────────────────────────
function WTotals({ active, accent, variant }) {
  const D = window.W_DATA;
  const v = window.useCountUp(D.totalTime, active, { dur: 1600 });
  const r = window.useReveal(active, 300);
  return (
    <WChapter accent={accent} variant={variant}>
      <window.Eyebrow accent={accent} show={active}>Total time aloft</window.Eyebrow>
      <window.HeroNum value={window.fmtInt(v)} unit="HOURS" accent={accent} variant={variant} />
      <window.Rise show={r} delay={100}>
        <window.ChapterSub>
          That's {window.fmtInt(Math.round(D.totalTime / 24))} full days in command of an aircraft.
        </window.ChapterSub>
      </window.Rise>
      <window.StatTrio show={r} delay={350} accent={accent} items={[
        { value: D.yearToDate + ' h', label: 'This year' },
        { value: D.last12 + ' h', label: 'Last 12 mo' },
        { value: window.fmtInt(D.totalFlights), label: 'Flights' },
      ]} />
      <window.Rise show={window.useReveal(active, 700)} style={{ alignSelf: 'stretch', marginTop: 4 }}>
        <window.W_GlobeOrbit accent={accent} active={active} laps={D.aroundEarth.laps} km={D.aroundEarth.km} />
      </window.Rise>
    </WChapter>
  );
}

// 3 ── Hours over time ────────────────────────────────────────────────────────
function WMonthly({ active, accent, variant }) {
  const D = window.W_DATA;
  return (
    <WChapter accent={accent} variant={variant}>
      <window.Eyebrow accent={accent} show={active}>Over the last 12 months</window.Eyebrow>
      <window.Rise show={window.useReveal(active, 150)}>
        <window.ChapterTitle variant={variant}>
          You flew most in <em style={{ fontStyle: 'italic', color: accent }}>{D.bestMonth.label}</em>.
        </window.ChapterTitle>
      </window.Rise>
      <window.Rise show={window.useReveal(active, 350)}>
        <window.ChapterSub>{D.bestMonth.h} hours in a single month — your busiest stretch of the year.</window.ChapterSub>
      </window.Rise>
      <div style={{ marginTop: 10 }}>
        <window.W_MonthlyBars accent={accent} active={active} />
      </div>
    </WChapter>
  );
}

// 4 ── World map (full-bleed) ─────────────────────────────────────────────────
function WMap({ active, accent, variant }) {
  const W = window.W_C;
  const D = window.W_DATA;
  return (
    <div style={{ position: 'absolute', inset: 0, overflow: 'hidden', background: W.bgDeep }}>
      <div style={{ position: 'absolute', top: 0, left: 0, right: 0 }}>
        <window.W_WorldMap accent={accent} active={active} height={520} />
      </div>
      <div style={{
        position: 'absolute', left: 0, right: 0, bottom: 0, height: '52%',
        background: `linear-gradient(180deg, transparent, ${W.bgDeep} 62%)`, pointerEvents: 'none',
      }}/>
      <div style={{ position: 'absolute', left: 0, right: 0, bottom: 0,
                    padding: PAD, paddingBottom: 40, display: 'flex', flexDirection: 'column', gap: 14 }}>
        <window.Eyebrow accent={accent} show={active}>Your network</window.Eyebrow>
        <window.Rise show={window.useReveal(active, 200)}>
          <div style={{ display: 'flex', alignItems: 'baseline', gap: 14 }}>
            <window.HeroNum value={String(D.airportsCount)} accent={accent} variant={variant} />
            <span style={{ fontFamily: window.W_SERIF, fontSize: 22, color: W.text2 }}>airports</span>
          </div>
        </window.Rise>
        <window.Rise show={window.useReveal(active, 420)}>
          <window.ChapterSub>Across {D.countriesCount} countries — every one flown from {D.topAirports[0].city}.</window.ChapterSub>
        </window.Rise>
      </div>
    </div>
  );
}

// 5 ── Top 10 airports ────────────────────────────────────────────────────────
function WTopAirports({ active, accent, variant }) {
  return (
    <WChapter accent={accent} variant={variant}>
      <window.Eyebrow accent={accent} show={active}>Most-visited airports</window.Eyebrow>
      <window.Rise show={window.useReveal(active, 120)}>
        <window.ChapterTitle variant={variant}>Your top ten.</window.ChapterTitle>
      </window.Rise>
      <div style={{ marginTop: 6 }}>
        <window.W_TopAirports accent={accent} active={active} />
      </div>
      <div style={{ alignSelf: 'stretch' }}>
        <div style={{ fontFamily: W_MONO, fontSize: 9.5, fontWeight: 700, letterSpacing: '0.18em',
                      color: window.W_C.muted, textTransform: 'uppercase', marginBottom: 10 }}>Least visited</div>
        <window.W_BottomFive accent={accent} active={active} />
      </div>
    </WChapter>
  );
}

// 6 ── Countries & reach ──────────────────────────────────────────────────────
function WReach({ active, accent, variant }) {
  const W = window.W_C; const D = window.W_DATA; const re = D.reach;
  const r = window.useReveal(active, 300);
  const extremes = [
    { k: 'NORTHERNMOST', v: re.north.icao, c: re.north.city },
    { k: 'SOUTHERNMOST', v: re.south.icao, c: re.south.city },
    { k: 'WESTERNMOST', v: re.west.icao, c: re.west.city },
    { k: 'EASTERNMOST', v: re.east.icao, c: re.east.city },
  ];
  return (
    <WChapter accent={accent} variant={variant}>
      <window.Eyebrow accent={accent} show={active}>How far it reaches</window.Eyebrow>
      <window.Rise show={window.useReveal(active, 120)}>
        <window.ChapterTitle variant={variant}>
          {D.countriesCount} countries,<br/>corner to corner.
        </window.ChapterTitle>
      </window.Rise>
      <window.Rise show={r} delay={100}>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 14, marginTop: 8 }}>
          {extremes.map((e, i) => (
            <window.Rise key={e.k} show={r} delay={i * 90}>
              <div style={{ display: 'flex', flexDirection: 'column', gap: 4,
                            padding: '14px 0', borderTop: `1px solid ${W.border}` }}>
                <span style={{ fontFamily: window.W_MONO, fontSize: 9, fontWeight: 700,
                               letterSpacing: '0.16em', color: W.muted }}>{e.k}</span>
                <span style={{ fontFamily: window.W_MONO, fontSize: 20, fontWeight: 700, color: accent }}>{e.v}</span>
                <span style={{ fontFamily: window.W_FONT, fontSize: 12, color: W.text3 }}>{e.c}</span>
              </div>
            </window.Rise>
          ))}
        </div>
      </window.Rise>
      <window.Rise show={window.useReveal(active, 700)}>
        <span style={{ fontFamily: window.W_MONO, fontSize: 11, color: W.text3, letterSpacing: '0.06em' }}>
          {window.fmtInt(re.spanKm)} km between the two furthest fields you've touched.
        </span>
      </window.Rise>
    </WChapter>
  );
}

// 7 ── Aircraft types ─────────────────────────────────────────────────────────
function WAircraft({ active, accent, variant }) {
  const D = window.W_DATA;
  const r = window.useReveal(active, 250);
  return (
    <WChapter accent={accent} variant={variant}>
      <window.Eyebrow accent={accent} show={active}>What you flew</window.Eyebrow>
      <window.Rise show={window.useReveal(active, 120)}>
        <window.ChapterTitle variant={variant}>
          {D.aircraftTypes} types.{' '}
          <em style={{ fontStyle: 'italic', color: accent }}>{D.registrations}</em> tails.
        </window.ChapterTitle>
      </window.Rise>
      <window.Rise show={r}>
        <window.ChapterSub>
          But one machine defined the decade: the <strong style={{ color: window.W_C.text, fontWeight: 600 }}>{D.topType.label}</strong>, {D.topType.hours.toLocaleString()} hours of it.
        </window.ChapterSub>
      </window.Rise>
      <div style={{ marginTop: 8 }}>
        <window.W_TypeBreakdown accent={accent} active={active} />
      </div>
    </WChapter>
  );
}

// 8 ── Role split ─────────────────────────────────────────────────────────────
function WRoles({ active, accent, variant }) {
  const D = window.W_DATA;
  const picPct = Math.round((D.roles[0].h / D.roles.reduce((s, r) => s + r.h, 0)) * 100);
  return (
    <WChapter accent={accent} variant={variant}>
      <window.Eyebrow accent={accent} show={active}>In which seat</window.Eyebrow>
      <window.Rise show={window.useReveal(active, 120)}>
        <window.ChapterTitle variant={variant}>
          <em style={{ fontStyle: 'italic', color: accent }}>{picPct}%</em> of it as pilot in command.
        </window.ChapterTitle>
      </window.Rise>
      <div style={{ marginTop: 10 }}>
        <window.W_RoleSplit accent={accent} active={active} />
      </div>
    </WChapter>
  );
}

// 9 ── Day / Night + IFR / VFR ────────────────────────────────────────────────
function WDayNight({ active, accent, variant }) {
  const D = window.W_DATA;
  return (
    <WChapter accent={accent} variant={variant}>
      <window.Eyebrow accent={accent} show={active}>Light & rules</window.Eyebrow>
      <window.Rise show={window.useReveal(active, 120)}>
        <window.ChapterTitle variant={variant}>
          {D.nightH} hours flown <em style={{ fontStyle: 'italic', color: accent }}>after dark</em>.
        </window.ChapterTitle>
      </window.Rise>
      <div style={{ marginTop: 14, display: 'flex', flexDirection: 'column', gap: 22 }}>
        <window.W_SplitMeter accent={accent} active={active} label="Day vs Night"
          a={D.dayH} b={D.nightH} aLabel="Day" bLabel="Night" delay={150} />
        <window.W_SplitMeter accent={accent} active={active} label="IFR vs VFR"
          a={D.ifrH} b={D.vfrH} aLabel="IFR" bLabel="VFR" delay={350} />
      </div>
      <window.StatTrio show={window.useReveal(active, 600)} delay={0} accent={accent} items={[
        { value: window.fmtInt(D.landingsDay + D.landingsNight), label: 'Landings' },
        { value: window.fmtInt(D.landingsNight), label: 'At night' },
        { value: Math.round((D.ifrH / (D.ifrH + D.vfrH)) * 100) + '%', label: 'On instruments' },
      ]} />
    </WChapter>
  );
}

// 10 ── Longest flight (route) ────────────────────────────────────────────────
function WLongest({ active, accent, variant }) {
  const W = window.W_C; const L = window.W_DATA.longest;
  return (
    <WChapter accent={accent} variant={variant} justify="center">
      <window.Eyebrow accent={accent} show={active}>Your longest flight</window.Eyebrow>
      <window.Rise show={window.useReveal(active, 120)}>
        <div style={{ display: 'flex', alignItems: 'baseline', gap: 10 }}>
          <window.HeroNum value={window.fmtInt(L.nm)} unit="NM" accent={accent} variant={variant} />
        </div>
      </window.Rise>
      <window.Rise show={window.useReveal(active, 280)}>
        <span style={{ fontFamily: W_MONO, fontSize: 12, fontWeight: 700, color: W.text3, letterSpacing: '0.08em' }}>
          {L.legs[0].icao} → {L.legs[L.legs.length - 1].icao} · {L.duration} · {L.date.toUpperCase()}
        </span>
      </window.Rise>
      <div style={{ marginTop: 12, alignSelf: 'stretch' }}>
        <window.W_RouteMap accent={accent} active={active} height={210} />
      </div>
    </WChapter>
  );
}

// 11 ── Best week ─────────────────────────────────────────────────────────────
function WBestWeek({ active, accent, variant }) {
  const W = window.W_C; const bw = window.W_DATA.bestWeek;
  return (
    <WChapter accent={accent} variant={variant}>
      <window.Eyebrow accent={accent} show={active}>Your busiest week</window.Eyebrow>
      <window.Rise show={window.useReveal(active, 120)}>
        <div style={{ display: 'flex', alignItems: 'baseline', gap: 10 }}>
          <window.HeroNum value={bw.hoursLabel} accent={accent} variant={variant} />
        </div>
      </window.Rise>
      <window.Rise show={window.useReveal(active, 280)}>
        <span style={{ fontFamily: W_MONO, fontSize: 12, fontWeight: 700, color: W.text3, letterSpacing: '0.08em' }}>
          {bw.week} · {bw.sectors} SECTORS · {bw.airports} AIRPORTS
        </span>
      </window.Rise>
      <div style={{ marginTop: 14 }}>
        <window.W_WeekBars accent={accent} active={active} />
      </div>
    </WChapter>
  );
}

// 12 ── Currency / rhythm ─────────────────────────────────────────────────────
function WCurrency({ active, accent, variant }) {
  const D = window.W_DATA;
  return (
    <WChapter accent={accent} variant={variant}>
      <window.Eyebrow accent={accent} show={active}>Your current rhythm</window.Eyebrow>
      <window.Rise show={window.useReveal(active, 150)} style={{ alignSelf: 'center' }}>
        <window.W_CurrencyRing accent={accent} active={active} />
      </window.Rise>
      <window.Rise show={window.useReveal(active, 500)} style={{ textAlign: 'center', alignSelf: 'center' }}>
        <window.ChapterSub>
          The last 14 days against your own baseline. You're flying right on pace.
        </window.ChapterSub>
      </window.Rise>
    </WChapter>
  );
}

// 13 ── EASA progress (adaptive: shows the licence you're closest to) ─────────
function WEasa({ active, accent, variant, experience }) {
  const W = window.W_C;
  const key = (experience || 'ATPL').toLowerCase();
  const prof = window.W_EASA_PROFILES[key] || window.W_EASA_PROFILES.atpl;
  const lics = window.W_LICENCES;
  const isMet = (lic) => lic.bars.every((b) => prof[b.key] >= b.need);
  const target = lics.find((l) => !isMet(l));     // lowest licence not yet met
  const allMet = !target;
  const lic = allMet ? lics[lics.length - 1] : target;
  const bars = lic.bars.map((b) => ({ label: b.label, have: prof[b.key], need: b.need }));
  const metCount = bars.filter((b) => b.have >= b.need).length;
  const progress = Math.round(
    bars.reduce((s, b) => s + Math.min(b.have / b.need, 1), 0) / bars.length * 100
  );
  return (
    <WChapter accent={accent} variant={variant}>
      <window.Eyebrow accent={accent} show={active}>The road to your licence</window.Eyebrow>
      <window.Rise show={window.useReveal(active, 120)}>
        <window.ChapterTitle variant={variant}>
          {allMet ? (
            <>Every <em style={{ fontStyle: 'italic', color: accent }}>{lic.code}</em> hour requirement — met.</>
          ) : (
            <>On your way to <em style={{ fontStyle: 'italic', color: accent }}>{lic.code}</em>.</>
          )}
        </window.ChapterTitle>
      </window.Rise>
      {!allMet && (
        <window.Rise show={window.useReveal(active, 300)}>
          <span style={{ fontFamily: W_MONO, fontSize: 12, fontWeight: 700, color: W.text3,
                         letterSpacing: '0.08em' }}>
            {progress}% THERE · {metCount}/{bars.length} REQUIREMENTS MET
          </span>
        </window.Rise>
      )}
      <div style={{ marginTop: 12 }}>
        <window.W_EasaBars accent={accent} active={active} bars={bars} />
      </div>
    </WChapter>
  );
}

// 14 ── Outro + what the app does ─────────────────────────────────────────────
function WOutro({ active, accent, variant }) {
  const W = window.W_C;
  const r = window.useReveal(active, 300);
  const features = [
    'Currency & flight-load, always live',
    'EASA-ready PDF & CSV export',
    'Scan paper logs — OCR does the typing',
    'Best week, longest XC, milestones — automatic',
  ];
  return (
    <WChapter accent={accent} variant={variant}>
      <window.Eyebrow accent={accent} show={active}>This is just the beginning</window.Eyebrow>
      <window.Rise show={window.useReveal(active, 120)}>
        <window.ChapterTitle variant={variant}>
          Every flight you log<br/>sharpens the <em style={{ fontStyle: 'italic', color: accent }}>picture</em>.
        </window.ChapterTitle>
      </window.Rise>
      <window.Rise show={r}>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 11, marginTop: 6 }}>
          {features.map((f, i) => (
            <window.Rise key={i} show={r} delay={i * 90}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                <span style={{ width: 18, height: 18, borderRadius: '50%', flexShrink: 0,
                               background: accent + '22', border: `1px solid ${accent}`,
                               display: 'grid', placeItems: 'center' }}>
                  <svg width="9" height="9" viewBox="0 0 10 10"><path d="M1.5 5l2.5 2.5L8.5 2.5" stroke={accent} strokeWidth="1.6" fill="none" strokeLinecap="round" strokeLinejoin="round"/></svg>
                </span>
                <span style={{ fontFamily: window.W_FONT, fontSize: 14, color: W.text2 }}>{f}</span>
              </div>
            </window.Rise>
          ))}
        </div>
      </window.Rise>
      <window.Rise show={window.useReveal(active, 850)} style={{ marginTop: 10 }}>
        <button style={{
          alignSelf: 'flex-start', padding: '14px 24px', borderRadius: 999, border: 'none',
          background: accent, color: W.ink, fontFamily: window.W_FONT, fontSize: 15, fontWeight: 700,
          cursor: 'pointer', boxShadow: `0 14px 30px -14px ${accent}`,
        }}>Enter BLADES ›</button>
      </window.Rise>
    </WChapter>
  );
}

const W_CHAPTERS = [
  { key: 'cover',    dur: 4500, Comp: WCover },
  { key: 'totals',   dur: 5200, Comp: WTotals },
  { key: 'monthly',  dur: 5500, Comp: WMonthly },
  { key: 'map',      dur: 6800, Comp: WMap },
  { key: 'airports', dur: 6200, Comp: WTopAirports },
  { key: 'reach',    dur: 5500, Comp: WReach },
  { key: 'aircraft', dur: 5800, Comp: WAircraft },
  { key: 'roles',    dur: 5200, Comp: WRoles },
  { key: 'daynight', dur: 5800, Comp: WDayNight },
  { key: 'longest',  dur: 6000, Comp: WLongest },
  { key: 'bestweek', dur: 5500, Comp: WBestWeek },
  { key: 'currency', dur: 5200, Comp: WCurrency },
  { key: 'easa',     dur: 6000, Comp: WEasa },
  { key: 'outro',    dur: 7000, Comp: WOutro },
];

Object.assign(window, { W_CHAPTERS });
