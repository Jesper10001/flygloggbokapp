// Data visualisations for Wrapped chapters. All animate in when `active`.

// ── Monthly hours — animated bars, best month highlighted ────────────────────
function W_MonthlyBars({ accent, active }) {
  const W = window.W_C;
  const data = window.W_DATA.monthly;
  const max = Math.max(...data.map((d) => d.h));
  const best = Math.max(...data.map((d) => d.h));
  return (
    <div style={{ alignSelf: 'stretch', display: 'flex', alignItems: 'flex-end',
                  gap: 6, height: 200 }}>
      {data.map((d, i) => {
        const isBest = d.h === best;
        const pct = (d.h / max) * 100;
        return (
          <div key={i} style={{ flex: 1, display: 'flex', flexDirection: 'column',
                                 alignItems: 'center', gap: 8, height: '100%', justifyContent: 'flex-end' }}>
            <span style={{
              fontFamily: W_MONO, fontSize: 9, fontWeight: 700,
              color: isBest ? accent : W.muted,
              opacity: active ? 1 : 0, transition: `opacity .5s ease ${i * 45 + 400}ms`,
            }}>{d.h}</span>
            <div style={{
              width: '100%', borderRadius: 5, alignSelf: 'stretch',
              height: active ? `${pct}%` : '0%',
              background: isBest
                ? `linear-gradient(180deg, ${accent}, ${accent}88)`
                : W.border,
              boxShadow: isBest ? `0 0 16px ${accent}66` : 'none',
              transition: `height .9s cubic-bezier(.3,.8,.3,1) ${i * 45}ms`,
            }}/>
            <span style={{
              fontFamily: W_MONO, fontSize: 9, fontWeight: 700,
              color: isBest ? W.text : W.faint, letterSpacing: '0.04em',
            }}>{d.label[0]}</span>
          </div>
        );
      })}
    </div>
  );
}

// ── Role split — stacked horizontal bar + legend ─────────────────────────────
function W_RoleSplit({ accent, active }) {
  const W = window.W_C;
  const roles = window.W_DATA.roles;
  const total = roles.reduce((s, r) => s + r.h, 0);
  const cols = [accent, W.text3, W.muted];
  return (
    <div style={{ alignSelf: 'stretch', display: 'flex', flexDirection: 'column', gap: 16 }}>
      <div style={{ display: 'flex', height: 16, borderRadius: 8, overflow: 'hidden',
                    background: W.separator }}>
        {roles.map((r, i) => (
          <div key={r.label} style={{
            width: active ? `${(r.h / total) * 100}%` : '0%',
            background: cols[i],
            transition: `width 1s cubic-bezier(.3,.8,.3,1) ${i * 140}ms`,
          }}/>
        ))}
      </div>
      <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
        {roles.map((r, i) => (
          <window.Rise key={r.label} show={active} delay={i * 90 + 200}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
              <span style={{ width: 9, height: 9, borderRadius: 2, background: cols[i] }}/>
              <span style={{ flex: 1, fontFamily: W_MONO, fontSize: 12, fontWeight: 700,
                             letterSpacing: '0.1em', color: W.text2, whiteSpace: 'nowrap' }}>{r.label}</span>
              <span style={{ fontFamily: W_MONO, fontSize: 13, fontWeight: 700, color: i === 0 ? accent : W.text,
                             fontVariantNumeric: 'tabular-nums', whiteSpace: 'nowrap' }}>{window.fmtInt(r.h)} h</span>
              <span style={{ fontFamily: W_MONO, fontSize: 10, color: W.muted, width: 34, textAlign: 'right' }}>
                {Math.round((r.h / total) * 100)}%
              </span>
            </div>
          </window.Rise>
        ))}
      </div>
    </div>
  );
}

// ── Day vs Night + IFR vs VFR — two split meters ─────────────────────────────
function W_SplitMeter({ accent, active, label, a, b, aLabel, bLabel, delay = 0 }) {
  const W = window.W_C;
  const pct = (a / (a + b)) * 100;
  return (
    <window.Rise show={active} delay={delay} style={{ alignSelf: 'stretch' }}>
      <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline' }}>
          <span style={{ fontFamily: W_MONO, fontSize: 10, fontWeight: 700, letterSpacing: '0.16em',
                         color: W.muted, textTransform: 'uppercase', whiteSpace: 'nowrap' }}>{label}</span>
          <span style={{ fontFamily: W_MONO, fontSize: 12, fontWeight: 700, color: accent, whiteSpace: 'nowrap' }}>
            {window.fmtInt(a)} h <span style={{ color: W.muted }}>· {Math.round(pct)}%</span>
          </span>
        </div>
        <div style={{ height: 10, borderRadius: 6, overflow: 'hidden', background: W.separator, display: 'flex' }}>
          <div style={{ width: active ? `${pct}%` : '0%', background: accent,
                        transition: `width 1s cubic-bezier(.3,.8,.3,1) ${delay + 100}ms` }}/>
        </div>
        <div style={{ display: 'flex', justifyContent: 'space-between', fontFamily: W_MONO,
                      fontSize: 10, color: W.text3, whiteSpace: 'nowrap' }}>
          <span>{aLabel}</span>
          <span>{bLabel} · {window.fmtInt(b)} h</span>
        </div>
      </div>
    </window.Rise>
  );
}

// ── Aircraft type breakdown — list with bars ─────────────────────────────────
function W_TypeBreakdown({ accent, active }) {
  const W = window.W_C;
  const rows = window.W_DATA.typeBreakdown;
  const max = rows[0].hours;
  return (
    <div style={{ alignSelf: 'stretch', display: 'flex', flexDirection: 'column', gap: 8 }}>
      {rows.map((r, i) => (
        <window.Rise key={r.type} show={active} delay={i * 60}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
            <span style={{ fontFamily: W_MONO, fontSize: 12, fontWeight: 700, width: 52,
                           color: i === 0 ? accent : W.text }}>{r.type}</span>
            <div style={{ flex: 1, height: 6, borderRadius: 4, background: W.separator, overflow: 'hidden' }}>
              <div style={{ height: '100%', borderRadius: 4,
                            width: active ? `${(r.hours / max) * 100}%` : '0%',
                            background: i === 0 ? accent : W.border,
                            boxShadow: i === 0 ? `0 0 10px ${accent}55` : 'none',
                            transition: `width .9s cubic-bezier(.3,.8,.3,1) ${i * 60 + 100}ms` }}/>
            </div>
            <span style={{ fontFamily: W_MONO, fontSize: 11, fontWeight: 700, width: 56, textAlign: 'right',
                           color: W.text2, fontVariantNumeric: 'tabular-nums', whiteSpace: 'nowrap' }}>{window.fmtInt(r.hours)}h</span>
          </div>
        </window.Rise>
      ))}
    </div>
  );
}

// ── Longest XC route map (reused projection from map.jsx) ────────────────────
function W_RouteMap({ accent, active, height = 220 }) {
  const W = window.W_C;
  const legs = window.W_DATA.longest.legs;
  const w = 345, h = height;
  // local projection fit to legs
  const lons = legs.map((l) => l.lon), lats = legs.map((l) => l.lat);
  const pad = 0.18;
  const lonMin = Math.min(...lons), lonMax = Math.max(...lons);
  const latMin = Math.min(...lats), latMax = Math.max(...lats);
  const spanLon = (lonMax - lonMin) || 1, spanLat = (latMax - latMin) || 1;
  const proj = (lat, lon) => ({
    x: ((lon - lonMin + spanLon * pad) / (spanLon * (1 + 2 * pad))) * w,
    y: ((latMax - lat + spanLat * pad) / (spanLat * (1 + 2 * pad))) * h,
  });
  const pts = legs.map((l) => ({ ...l, ...proj(l.lat, l.lon) }));
  let d = `M ${pts[0].x} ${pts[0].y}`;
  for (let i = 1; i < pts.length; i++) {
    const a = pts[i - 1], b = pts[i];
    const mx = (a.x + b.x) / 2, my = (a.y + b.y) / 2;
    const dist = Math.hypot(b.x - a.x, b.y - a.y);
    d += ` Q ${mx} ${my - dist * 0.18} ${b.x} ${b.y}`;
  }
  return (
    <svg width="100%" height={h} viewBox={`0 0 ${w} ${h}`} style={{ display: 'block' }}>
      <path d={d} fill="none" stroke={accent} strokeWidth="2.4" strokeLinecap="round"
            strokeDasharray="700" strokeDashoffset={active ? 0 : 700}
            style={{ transition: 'stroke-dashoffset 1.4s cubic-bezier(.4,.8,.3,1) .2s' }}/>
      {pts.map((p, i) => {
        const end = p.role !== 'via';
        return (
          <g key={p.icao} style={{ opacity: active ? 1 : 0, transition: `opacity .5s ease ${i * 250 + 300}ms` }}>
            <circle cx={p.x} cy={p.y} r={end ? 6 : 4} fill={W.bgDeep} />
            <circle cx={p.x} cy={p.y} r={end ? 4.5 : 3} fill={accent} />
            <text x={p.x} y={p.y - 12} textAnchor="middle" fontFamily={window.W_MONO}
                  fontSize="11" fontWeight="700" fill={W.text}>{p.icao}</text>
            <text x={p.x} y={p.y + 18} textAnchor="middle" fontFamily={window.W_FONT}
                  fontSize="9" fill={W.text3}>{p.city}</text>
          </g>
        );
      })}
    </svg>
  );
}

// ── Best week day bars ───────────────────────────────────────────────────────
function W_WeekBars({ accent, active }) {
  const W = window.W_C;
  const bw = window.W_DATA.bestWeek;
  const max = Math.max(...bw.days);
  return (
    <div style={{ alignSelf: 'stretch', display: 'flex', alignItems: 'flex-end', gap: 8, height: 130 }}>
      {bw.days.map((hrs, i) => {
        const peak = hrs === max;
        const pct = max ? (hrs / max) * 100 : 0;
        return (
          <div key={i} style={{ flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center',
                                 gap: 6, height: '100%', justifyContent: 'flex-end' }}>
            <div style={{
              width: '100%', borderRadius: 5, alignSelf: 'stretch',
              height: active ? `${Math.max(pct, hrs > 0 ? 6 : 0)}%` : '0%',
              minHeight: hrs > 0 ? 4 : 0,
              background: peak ? `linear-gradient(180deg, ${accent}, ${accent}88)`
                               : hrs > 0 ? W.border : 'transparent',
              boxShadow: peak ? `0 0 14px ${accent}66` : 'none',
              border: hrs === 0 ? `1px dashed ${W.border}` : 'none',
              transition: `height .8s cubic-bezier(.3,.8,.3,1) ${i * 60}ms`,
            }}/>
            <span style={{ fontFamily: W_MONO, fontSize: 10, fontWeight: 700,
                           color: peak ? accent : W.faint }}>{bw.dayLabels[i]}</span>
          </div>
        );
      })}
    </div>
  );
}

// ── Currency ring ────────────────────────────────────────────────────────────
function W_CurrencyRing({ accent, active, size = 190 }) {
  const W = window.W_C;
  const cur = window.W_DATA.currency;
  const r = (size - 18) / 2;
  const circ = 2 * Math.PI * r;
  const target = Math.min(cur.index, 240) / 240;
  const v = window.useCountUp(cur.index, active, { dur: 1400, delay: 200 });
  const pct = Math.min(v, 240) / 240;
  return (
    <div style={{ position: 'relative', width: size, height: size, alignSelf: 'center' }}>
      <svg width={size} height={size} style={{ position: 'absolute', transform: 'rotate(-90deg)' }}>
        <circle cx={size / 2} cy={size / 2} r={r} stroke={W.separator} strokeWidth="10" fill="none" />
        <circle cx={size / 2} cy={size / 2} r={r} stroke={accent} strokeWidth="10" fill="none"
                strokeLinecap="round"
                strokeDasharray={`${circ * pct} ${circ * (1 - pct)}`} />
      </svg>
      <div style={{ position: 'absolute', inset: 0, display: 'flex', flexDirection: 'column',
                    alignItems: 'center', justifyContent: 'center' }}>
        <span style={{ fontFamily: W_SERIF, fontSize: 46, fontWeight: 600, color: W.text,
                       lineHeight: 1 }}>{Math.round(v)}%</span>
        <span style={{ fontFamily: W_MONO, fontSize: 10, fontWeight: 700, letterSpacing: '0.18em',
                       color: accent, marginTop: 6 }}>{cur.zone}</span>
      </div>
    </div>
  );
}

// ── EASA progress bars ───────────────────────────────────────────────────────
function W_EasaBars({ accent, active, bars }) {
  const W = window.W_C;
  const list = bars || window.W_DATA.easa.bars;
  return (
    <div style={{ alignSelf: 'stretch', display: 'flex', flexDirection: 'column', gap: 12 }}>
      {list.map((b, i) => {
        const ratio = Math.min(b.have / b.need, 1);
        const met = b.have >= b.need;
        return (
          <window.Rise key={b.label} show={active} delay={i * 70}>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 5 }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline' }}>
                <span style={{ fontFamily: W_MONO, fontSize: 10, fontWeight: 700, letterSpacing: '0.14em',
                               color: W.text2, whiteSpace: 'nowrap' }}>{b.label}</span>
                <span style={{ fontFamily: W_MONO, fontSize: 10, fontWeight: 700, whiteSpace: 'nowrap',
                               color: met ? W.success : accent }}>
                  {window.fmtInt(b.have)} / {window.fmtInt(b.need)} h {met ? '✓' : ''}
                </span>
              </div>
              <div style={{ height: 7, borderRadius: 4, background: W.separator, overflow: 'hidden' }}>
                <div style={{ height: '100%', borderRadius: 4,
                              width: active ? `${ratio * 100}%` : '0%',
                              background: met ? W.success : accent,
                              boxShadow: `0 0 10px ${(met ? W.success : accent)}55`,
                              transition: `width .9s cubic-bezier(.3,.8,.3,1) ${i * 70 + 120}ms` }}/>
              </div>
            </div>
          </window.Rise>
        );
      })}
    </div>
  );
}

Object.assign(window, {
  W_MonthlyBars, W_RoleSplit, W_SplitMeter, W_TypeBreakdown,
  W_RouteMap, W_WeekBars, W_CurrencyRing, W_EasaBars,
});
