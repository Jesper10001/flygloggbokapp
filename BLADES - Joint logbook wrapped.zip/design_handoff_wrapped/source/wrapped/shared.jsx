// BLADES Wrapped — shared foundation.
// Palette mirrors the app's Navy theme (constants/colors.ts).
// All demo data below maps 1:1 to fields the app already computes
// (FlightStats + getMonthlyHours / getVisitedAirportIcaos / getTopWeeks /
// per-flight rows). Nothing here is invented beyond plausible values.

const W_C = {
  bg:        '#0A1628',
  bgDeep:    '#06101E',
  surface:   '#0F1E3A',
  surface2:  '#132845',
  elevated:  '#152338',
  border:    '#1A3A5A',
  borderSoft:'#16314E',
  separator: '#122030',

  primary:   '#00C8E8',   // cyan
  gold:      '#FFB830',
  success:   '#00E8A0',
  warning:   '#FFB830',
  danger:    '#FF4D6A',
  violet:    '#9B8CFF',

  text:      '#FFFFFF',
  text2:     '#A8BFD6',
  text3:     '#7FA8C8',
  muted:     '#5A7FA0',
  faint:     '#3A5A7A',
  ink:       '#04101F',
};

const W_FONT  = '-apple-system, "SF Pro Display", "Inter", system-ui, sans-serif';
const W_SERIF = '"Fraunces", "Georgia", serif';
const W_MONO  = '"JetBrains Mono", "SF Mono", ui-monospace, monospace';

// Per-chapter accent rotation (kept inside the brand family).
const W_ACCENTS = [W_C.primary, W_C.gold, W_C.success, W_C.violet, W_C.warning];

// ─────────────────────────────────────────────────────────────
// DEMO DATA — A320 commercial pilot, ~5,520 h over ~10 years.
// (Matches services/testUserSeed.ts → seedMannedPilot1.)
// ─────────────────────────────────────────────────────────────
const W_DATA = {
  firstName: 'Erik',
  year: 2026,

  // FlightStats core
  totalFlights: 2914,
  totalTime: 5522,            // hours
  yearToDate: 642,
  last12: 711,
  last90: 184,

  // monthly hours — last 12 months (getMonthlyHours)
  monthly: [
    { m: 'J', label: 'Jun', h: 48 },
    { m: 'J', label: 'Jul', h: 78 },
    { m: 'A', label: 'Aug', h: 71 },
    { m: 'S', label: 'Sep', h: 58 },
    { m: 'O', label: 'Oct', h: 44 },
    { m: 'N', label: 'Nov', h: 39 },
    { m: 'D', label: 'Dec', h: 31 },
    { m: 'J', label: 'Jan', h: 36 },
    { m: 'F', label: 'Feb', h: 41 },
    { m: 'M', label: 'Mar', h: 55 },
    { m: 'A', label: 'Apr', h: 62 },
    { m: 'M', label: 'May', h: 68 },
  ],
  bestMonth: { label: 'July', h: 78 },

  // visited airports (getVisitedAirportIcaos + coords)
  airportsCount: 58,
  countriesCount: 19,
  topAirports: [
    { icao: 'ESSA', city: 'Stockholm',  country: 'SE', visits: 612, home: true },
    { icao: 'EDDF', city: 'Frankfurt',  country: 'DE', visits: 188 },
    { icao: 'EKCH', city: 'Copenhagen', country: 'DK', visits: 142 },
    { icao: 'EGLL', city: 'London',     country: 'GB', visits: 98 },
    { icao: 'LFPG', city: 'Paris',      country: 'FR', visits: 76 },
    { icao: 'LOWW', city: 'Vienna',     country: 'AT', visits: 64 },
    { icao: 'LEBL', city: 'Barcelona',  country: 'ES', visits: 52 },
    { icao: 'LSZH', city: 'Zürich',     country: 'CH', visits: 44 },
    { icao: 'EDDM', city: 'Munich',     country: 'DE', visits: 38 },
    { icao: 'EHAM', city: 'Amsterdam',  country: 'NL', visits: 31 },
  ],
  // least-visited airports (same query as topAirports, ascending)
  bottomAirports: [
    { icao: 'LCLK', city: 'Larnaca',     visits: 1 },
    { icao: 'GCLP', city: 'Gran Canaria', visits: 1 },
    { icao: 'BIKF', city: 'Keflavík',    visits: 1 },
    { icao: 'ENBO', city: 'Bodø',        visits: 2 },
    { icao: 'LIRF', city: 'Rome',        visits: 2 },
  ],

  // distance flown = Σ (flight time × aircraft cruise speed) over all flights
  // (cruise_speed_kts per type lives in aircraft_registry; time per flight).
  // 4 510 846 km ÷ 40 075 km (Earth circumference) ≈ 112.5 laps.
  aroundEarth: { km: 4510846, nm: 2435662, laps: 112.5 },

  // reach extremes (derived from visited-airport coordinates)
  reach: {
    north: { icao: 'ENBO', city: 'Bodø',        lat: 67.3 },
    south: { icao: 'GCLP', city: 'Gran Canaria', lat: 27.9 },
    west:  { icao: 'BIKF', city: 'Keflavík',    lon: -22.6 },
    east:  { icao: 'LCLK', city: 'Larnaca',     lon: 33.6 },
    spanKm: 6480,
  },

  // aircraft (per-flight rows → types + registrations)
  aircraftTypes: 6,
  registrations: 34,
  topType: { type: 'A320', hours: 4980, label: 'Airbus A320' },
  typeBreakdown: [
    { type: 'A320', hours: 4980 },
    { type: 'A321', hours: 286 },
    { type: 'A319', hours: 151 },
    { type: 'DA40', hours: 58 },
    { type: 'C172', hours: 31 },
    { type: 'PA28', hours: 16 },
  ],

  // role split (FlightStats)
  roles: [
    { label: 'PIC',       h: 2890 },
    { label: 'CO-PILOT',  h: 2527 },
    { label: 'DUAL',      h: 105 },
  ],

  // day/night + ifr/vfr (FlightStats)
  dayH: 5102,
  nightH: 420,
  ifrH: 5380,
  vfrH: 142,
  landingsDay: 2210,
  landingsNight: 704,

  // longest XC (FlightStats longest_xc_*)
  longest: {
    nm: 1280, km: 2371, duration: '6h 42m', date: '12 Jun 2024',
    legs: [
      { icao: 'ESSA', city: 'Stockholm', lat: 59.65, lon: 17.93, role: 'dep' },
      { icao: 'EDDF', city: 'Frankfurt', lat: 50.03, lon: 8.57,  role: 'via' },
      { icao: 'EGLL', city: 'London',    lat: 51.47, lon: -0.46, role: 'arr' },
    ],
  },

  // best week (getTopWeeks #1)
  bestWeek: {
    hoursLabel: '24:30', week: 'v.15 · 2026', sectors: 6, airports: 4,
    days: [6.7, 5.8, 6.42, 0, 5.58, 0, 0], // Mon..Sun
    dayLabels: ['M', 'T', 'W', 'T', 'F', 'S', 'S'],
  },

  // currency / rhythm (getStressHours)
  currency: { index: 112, zone: 'NORMAL', recent14: 28, baseline14: 25 },

  // EASA progress (EASAProgressChart inputs — hour thresholds)
  easa: {
    licence: 'ATPL(A)',
    bars: [
      { label: 'TOTAL TIME',   have: 5522, need: 1500 },
      { label: 'PIC',          have: 2890, need: 250 },
      { label: 'NIGHT',        have: 420,  need: 100 },
      { label: 'IFR / INSTR',  have: 5380, need: 75 },
      { label: 'CROSS-CTRY',   have: 1920, need: 200 },
    ],
  },
};

// ─────────────────────────────────────────────────────────────
// EASA LICENCE REQUIREMENTS (hour minimums) + sample experience profiles
// ─────────────────────────────────────────────────────────────
// Hour thresholds per licence; `key` maps to a value in an experience profile.
const W_LICENCES = [
  { code: 'PPL(A)', bars: [
    { label: 'TOTAL TIME', key: 'total', need: 45 },
    { label: 'PIC',        key: 'pic',   need: 10 },
    { label: 'CROSS-CTRY', key: 'xc',    need: 5 },
  ] },
  { code: 'CPL(A)', bars: [
    { label: 'TOTAL TIME', key: 'total', need: 200 },
    { label: 'PIC',        key: 'pic',   need: 100 },
    { label: 'CROSS-CTRY', key: 'xc',    need: 20 },
    { label: 'NIGHT',      key: 'night', need: 5 },
    { label: 'INSTRUMENT', key: 'ifr',   need: 10 },
  ] },
  { code: 'ATPL(A)', bars: [
    { label: 'TOTAL TIME',  key: 'total', need: 1500 },
    { label: 'PIC',         key: 'pic',   need: 250 },
    { label: 'CROSS-CTRY',  key: 'xc',    need: 200 },
    { label: 'NIGHT',       key: 'night', need: 100 },
    { label: 'INSTRUMENT',  key: 'ifr',   need: 75 },
    { label: 'MULTI-PILOT', key: 'mp',    need: 500 },
  ] },
];

// In the app these `have` values come straight from FlightStats. Here three
// sample profiles let the slide demonstrate its adaptive states.
const W_EASA_PROFILES = {
  atpl:    { total: 5522, pic: 2890, xc: 1920, night: 420, ifr: 5380, mp: 4900 },
  cpl:     { total: 212,  pic: 95,   xc: 24,   night: 7,   ifr: 14,   mp: 0 },
  student: { total: 38,   pic: 7,    xc: 3,    night: 1,   ifr: 2,    mp: 0 },
};

// ─────────────────────────────────────────────────────────────
// MOTION HOOKS
// ─────────────────────────────────────────────────────────────

// True a beat after `active` flips true → drives entrance transitions.
function useReveal(active, delay = 0) {
  const [on, setOn] = React.useState(false);
  React.useEffect(() => {
    if (!active) { setOn(false); return; }
    const t = setTimeout(() => setOn(true), delay);
    return () => clearTimeout(t);
  }, [active, delay]);
  return on;
}

// Count up to `target` whenever `active` becomes true.
function useCountUp(target, active, { dur = 1300, delay = 250 } = {}) {
  const [v, setV] = React.useState(0);
  React.useEffect(() => {
    if (!active) { setV(0); return; }
    let raf;
    const t0 = performance.now() + delay;
    const tick = (now) => {
      const p = Math.min(1, Math.max(0, (now - t0) / dur));
      const e = 1 - Math.pow(1 - p, 3);
      setV(target * e);
      if (p < 1) raf = requestAnimationFrame(tick);
      else setV(target);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [active, target, dur, delay]);
  return v;
}

const fmtInt = (n) => Math.round(n).toLocaleString('sv-SE'); // space-grouped, matches EU look

// Entrance wrapper — fades + lifts children when `show` is true.
function Rise({ show, delay = 0, y = 16, children, style }) {
  return (
    <div style={{
      opacity: show ? 1 : 0,
      transform: show ? 'translateY(0)' : `translateY(${y}px)`,
      transition: `opacity .7s cubic-bezier(.2,.7,.2,1) ${delay}ms, transform .7s cubic-bezier(.2,.7,.2,1) ${delay}ms`,
      ...style,
    }}>{children}</div>
  );
}

// ─────────────────────────────────────────────────────────────
// PRIMITIVES
// ─────────────────────────────────────────────────────────────

function Eyebrow({ accent, children, show = true, delay = 0 }) {
  // Editorial kicker — a thin rule + italic serif label, in place of the old
  // digital mono/uppercase/glowing-dot treatment.
  return (
    <Rise show={show} delay={delay}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 11 }}>
        <span style={{ width: 22, height: 1, background: accent, opacity: 0.65, flexShrink: 0 }} />
        <span style={{
          fontFamily: W_SERIF, fontStyle: 'italic', fontWeight: 400,
          fontSize: 16, letterSpacing: '0.01em', color: accent, whiteSpace: 'nowrap',
        }}>{children}</span>
      </div>
    </Rise>
  );
}

// Big serif hero number with optional unit.
function HeroNum({ value, unit, accent, variant = 'editorial' }) {
  const big = variant === 'cinematic';
  return (
    <div style={{ display: 'flex', alignItems: 'baseline', gap: big ? 12 : 9, flexWrap: 'wrap' }}>
      <span style={{
        fontFamily: W_SERIF, fontWeight: 500,
        fontSize: big ? 116 : 96, lineHeight: 0.82, letterSpacing: '-0.04em',
        color: W_C.text, fontVariantNumeric: 'tabular-nums',
        textShadow: big ? `0 8px 60px ${accent}55` : 'none',
      }}>{value}</span>
      {unit && (
        <span style={{
          fontFamily: W_MONO, fontWeight: 700, fontSize: big ? 20 : 16,
          color: accent, letterSpacing: '0.14em',
        }}>{unit}</span>
      )}
    </div>
  );
}

function ChapterTitle({ children, variant = 'editorial' }) {
  const big = variant === 'cinematic';
  return (
    <h1 style={{
      margin: 0,
      fontFamily: W_SERIF, fontWeight: 400,
      fontSize: big ? 44 : 38, lineHeight: 1.04, letterSpacing: '-0.02em',
      color: W_C.text, textWrap: 'balance',
    }}>{children}</h1>
  );
}

function ChapterSub({ children }) {
  return (
    <p style={{
      margin: 0, fontFamily: W_FONT, fontSize: 16, lineHeight: 1.5,
      color: W_C.text2, textWrap: 'pretty', maxWidth: 320,
    }}>{children}</p>
  );
}

// Small stat trio under a hero.
function StatTrio({ items, accent, show, delay = 0 }) {
  return (
    <Rise show={show} delay={delay} style={{ alignSelf: 'stretch' }}>
      <div style={{ display: 'flex', gap: 14 }}>
        {items.map((it, i) => (
          <div key={i} style={{ flex: 1, display: 'flex', flexDirection: 'column', gap: 4 }}>
            <span style={{
              fontFamily: W_MONO, fontWeight: 700, fontSize: 18,
              color: i === 0 ? accent : W_C.text, letterSpacing: '0.02em',
              fontVariantNumeric: 'tabular-nums',
            }}>{it.value}</span>
            <span style={{
              fontFamily: W_MONO, fontWeight: 700, fontSize: 9,
              letterSpacing: '0.16em', color: W_C.muted, textTransform: 'uppercase',
            }}>{it.label}</span>
          </div>
        ))}
      </div>
    </Rise>
  );
}

// Background field for a chapter — subtle (editorial) or saturated (cinematic).
function ChapterBG({ accent, variant }) {
  if (variant === 'cinematic') {
    return (
      <div style={{ position: 'absolute', inset: 0, pointerEvents: 'none' }}>
        <div style={{
          position: 'absolute', inset: 0,
          background: `radial-gradient(120% 80% at 50% -10%, ${accent}3A 0%, transparent 55%), linear-gradient(180deg, ${W_C.bg} 0%, ${W_C.bgDeep} 100%)`,
        }}/>
        <div style={{
          position: 'absolute', bottom: -120, left: '50%', transform: 'translateX(-50%)',
          width: 460, height: 460, borderRadius: '50%',
          background: `radial-gradient(circle, ${accent}22, transparent 65%)`,
        }}/>
      </div>
    );
  }
  return (
    <div style={{ position: 'absolute', inset: 0, pointerEvents: 'none' }}>
      <div style={{
        position: 'absolute', inset: 0,
        background: `radial-gradient(100% 60% at 50% -20%, ${accent}1C 0%, transparent 60%), ${W_C.bg}`,
      }}/>
    </div>
  );
}

Object.assign(window, {
  W_C, W_FONT, W_SERIF, W_MONO, W_ACCENTS, W_DATA, W_LICENCES, W_EASA_PROFILES,
  useReveal, useCountUp, fmtInt, Rise,
  Eyebrow, HeroNum, ChapterTitle, ChapterSub, StatTrio, ChapterBG,
});
