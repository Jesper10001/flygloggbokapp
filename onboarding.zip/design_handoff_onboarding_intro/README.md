# Handoff: Onboarding intro, 3 new info screens

## ⚠️ Scope: only screens 2, 3 and 4 are new
The prototype `Onboarding Intro.html` has 5 screens so you can see the flow. **Only screens 2–4 need to be built.**

| # | Screen | Status |
|---|---|---|
| 1 | Welcome (logo + "Get started") | **Already exists** in `app/onboarding.tsx`. Leave it as is. |
| **2** | **About · Safe logbook / modes** | **NEW. Build this.** |
| **3** | **About · Physical logbook + CSV import** | **NEW. Build this.** |
| **4** | **About · Airport globe + "And much more"** | **NEW. Build this.** |
| 5 | Role ("What do you do?") | **Already exists.** Shown only as the next step for context. Leave it as is. |

To view a screen in the prototype, open the HTML and tap through. Each `<section>` has a `data-screen-label` ("02 About · Modes", "03 About · Logbook", "04 About · Map").

## About the design files
This is an HTML design reference, not production code. Rebuild it in React Native / Expo inside the existing `app/onboarding.tsx`, reusing that file's `StepHeader`, `PrimaryButton`, `SecondaryButton`, styles `s.*` and `C = NavyColors`. The iPhone frame is only there for presentation.

## Fidelity
**High-fidelity.** Colors, type, spacing and copy are final.

## Integration in `app/onboarding.tsx`
1. Extend the `Step` type: `'intro1' | 'intro2' | 'intro3'`.
2. `buildSteps()`: insert the three intro steps after `'welcome'`, and only for first-time users (not `returning`):
   ```ts
   return [...(returning ? [] : ['welcome','intro1','intro2','intro3'] as Step[]), 'role', 'subrole', ...mid, 'profile', 'hours'];
   ```
3. Welcome "Get started" goes to `'intro1'` (currently `'role'`).
4. The dots and the Back row already work from `steps`/`stepIdx`. No change needed.
5. The "Skip intro" link on screens 2 and 3 calls `setStep('role')`.
6. Screen 4's primary button is labeled **"Set up my logbook"** and calls `setStep('role')`.
7. Wrap each step in the same `Animated.View key={step} entering={FadeIn.duration(220)}` as the others.

## Shared styling (already in the app)
- Background `#000000`, horizontal padding 22.
- Eyebrow: Menlo 10pt, weight 700, letterSpacing 1.6, uppercase, color `C.primary` `#00C8E8`.
- Title: 23pt, weight 800, letterSpacing −0.4. Subtitle: 13.5pt, `C.textSecondary` `#7FA8C8`, lineHeight 19. Header marginBottom 18.
- Cards: `C.card` `#0F1E3A`, border 1.5 `C.gold` `#FFB830`, radius 18 (image rows 16), shadow as `s.card`.
- Primary button: `C.primary`, radius 14, paddingVertical 16, 16pt weight 800, `C.textInverse`, arrow icon.
- "Skip intro": plain text button, 13.5pt, weight 600, `#7FA8C8`, height 30, below the primary button with gap 10.
- Elevated panels: `C.elevated` `#152338`, border 1 `C.cardBorder` `#1A3A5A`, radius 14.

## Screen 2: About · Safe logbook / modes
- **StepHeader**
  - eyebrow "What is BLADES"
  - title **"A safe logbook for every pilot"**
  - subtitle **"Your all-in-one securely encrypted logbook for easy and intuitive use."** (owner's copy, verbatim)
- **Mode cards** (2, gap 10): the same pattern as `ImageRow`, but 84 tall with padding 6. Image square, `contain`, scale 1.1, radius 10. Text column:
  - Tag (Menlo 9.5, weight 700, letterSpacing 1.4, uppercase, cyan). Title 17/800. Description 12.5, `#7FA8C8`, lineHeight 17.
  - Card 1: image `assets/Pilot-helicopter.PNG` · tag "Pilot mode" · title "Manned aircraft" · description "Helicopter and airplane. PIC, dual, IFR, night and NVG."
  - Card 2: image `assets/Drone-hobby.PNG` · tag "Drone mode" · title "Unmanned aircraft" · description "Hobby, commercial and military missions."
  - These cards are information only. They are **not** tappable choices.
- **Security panel**: elevated panel, marginTop 12, padding 2/14/4.
  - Header row: shield icon 13pt plus "WHY IT'S SAFE TO LOG HERE" (Menlo 10, weight 700, letterSpacing 1.4, color `C.success` `#00E8A0`), padding 9/0/7.
  - 3 rows, each with a top border 1 `C.separator` `#122030`, padding 7/0, gap 11. Icon 17pt in `#00E8A0`, then title 13/700 and description 11.5 `#7FA8C8`, lineHeight 15.
    - `lock-closed-outline` · **"AES-256 encryption"** · "Encrypted database (SQLCipher) on top of iOS device encryption."
    - `phone-portrait-outline` · **"Stays on your device"** · "No account, no copy on our servers."
    - `cloud-outline` · **"Backup in your own iCloud"** · "Optional encrypted sync to your Apple account."
- A `flex:1` spacer, then Continue and "Skip intro".

## Screen 3: About · Physical logbook + CSV import
- **StepHeader**
  - eyebrow "Your logbook"
  - title **"Your physical logbook, in the app"**
  - subtitle "Every flight lands on the right page and row, with totals carried forward. Copying it into your paper book takes a minute."
- **Paper spread** (illustration): radius 14, bg `#ECE3CC`, padding 12/12/14, two columns, a subtle spine shadow in the middle.
  - Left page columns: Date | From | To | Total. Right page columns: PIC | Night | Ldg | Remarks.
  - Header text: 6.8pt, weight 700, uppercase, `#6B5430`, bottom border 1.5 `#6B5430`.
  - Rows are 18 tall, with bottom border `#C9B98B` and column rules `#DCD1B7`. Cell text: Courier 9pt, `#3A2E1C`.
  - The last filled row is the "new" flight: bg `rgba(0,200,232,.10)`, text `#0A6E86` bold.
  - Then one empty row, then the totals rows "This page", "Brought fwd", "Total" (the last one with a 1.5 bottom border). Page numbers 38 / 39.
  - Rows are **example data**. The simplest build is a static image or a small `View` grid. It does not need live data.
- Caption row (marginTop 10, Menlo 10, `#7FA8C8`): a cyan swatch plus "New flight" on the left, and "Page 38–39" on the right.
- **CSV card**: `OptionCard` style, marginTop 16, not tappable.
  - Lead box: 50×50, radius 15, `rgba(255,255,255,.05)`, file icon (`file-delimited-outline`).
  - Title "Import any CSV" plus a **FREE** badge: Menlo 9.5, weight 800, letterSpacing 1, bg `#00E8A0`, text `#0A1628`, padding 3/6, radius 5.
  - Description: "Your own spreadsheet or an export from another app. Any format, at no cost."
  - Source chips: "Your own sheet", "ForeFlight", "LogTen Pro". Menlo 10, `#B5C8D8`, border 1 `#1A3A5A`, radius 6, padding 3/7, gap 6.
- A spacer, then Continue and "Skip intro".

## Screen 4: About · Airport globe + "And much more"
- **StepHeader**
  - eyebrow "Your world"
  - title **"Every airport on one map"**
  - subtitle "A global map with the world's airports. The ones you've flown to light up."
- **Globe**: 262×262, centered.
  - Orthographic projection with real land outlines. The prototype uses d3-geo and world-atlas `land-110m`.
  - It rotates slowly (about 0.12°/frame) and the user can drag to spin it.
  - Colors: sphere radial gradient `#13294A`→`#0A1628`, graticule `rgba(127,168,200,.08)`, land `#152338` with stroke `#1F4468`, rim `rgba(0,200,232,.35)`.
  - Airport dots: cyan, 2.6pt, opacity fades toward the limb. **In the app, use the real airport database** (the prototype's dots are sampled on land for density only).
  - Flown airports: gold `#FFB830` dots with a soft pulsing halo. Use the user's visited airports. The list will be empty on first run, so a few demo pins or none are both fine.
  - RN options: `react-native-svg` with d3-geo `geoPath` to an SVG path, or reuse the app's existing globe or map component if there is one.
  - Legend under the globe: left "● Airports" (cyan), right "● Flown" (gold). Menlo 10, `#7FA8C8`.
- **"AND MUCH MORE"** label: Menlo 10, weight 700, letterSpacing 1.6, `#B5C8D8`, margin 14/0/10.
- **2-column grid** of 6 tiles, gap 8. Each tile: `C.card`, border 1 `#1A3A5A`, radius 12, padding 10/11, icon 16pt cyan, label 12.5/600.
  - Quicklog in seconds · Log from a photo · CPL/ATPL progress · 14-day flight load · METAR & TAF · Flight share cards
  - These tiles are information only.
- A spacer, then the primary button **"Set up my logbook"**, which goes to `'role'`. This screen has no Skip link.

## Copy notes (checked against the repo)
- Every feature named on these screens exists in the app. "Your year in review" was removed on purpose.
- Security claims come from the owner's Privacy Policy §2 and §9: AES-256 via SQLCipher, on-device storage, optional iCloud sync to the user's own account.
- The CSV import is described as free at the owner's request. Check that the AI column-mapping path does not charge Blade-coins during onboarding. If it does, change the copy or exempt it.
- Swedish strings: follow the file's existing `sv ? … : …` pattern. The owner can supply the translations.

## Assets
Already in the repo: `assets/logo-splashscreen.png`, `assets/Pilot-helicopter.PNG`, `assets/Drone-hobby.PNG`. Copies are in `img/` here for the prototype only.
