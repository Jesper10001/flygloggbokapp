# Handoff: BLADES Premium screen (redesign)

## Overview
New version of the Premium paywall at `app/settings/premium.tsx` in `Jesper10001/flygloggbokapp` (FlightLogApp). It replaces the current screen, which has a 3-slide hero carousel, a Premium card at 49 kr, a MAX card at 149 kr and a "What you're missing on Free" card. The new screen has **one tier: BLADES Premium, 39 kr/month**, lists **two benefits**, and adds a short personal note from the creator.

## About the design files
`Premium Screen.html` is a **design reference built in HTML**. It is not production code. Rebuild it in the app's existing React Native / Expo setup: `View`/`Text`/`ScrollView`/`TouchableOpacity`, `Ionicons`, `useSafeAreaInsets`, `expo-router`. Reuse the `N` palette object that is already in `premium.tsx`. The iPhone frame in the HTML exists only for presentation. Do not build it.

## Fidelity
**High-fidelity.** Colors, type, spacing and copy are final.

## Screen: Premium (modal route `/settings/premium`)
Always dark (navy), as the current screen is.

### Layout (top → bottom)
1. **Top bar**: `paddingTop: insets.top + 8`, horizontal padding 18, bottom 6. Row with `space-between`.
   - Left: the BLADES horizontal lockup image, 20pt tall, width auto. The file is `blades-lockup-h.png`; add it to `assets/` if it is not there yet. This replaces the current gold "B" square and the "BLADES / Pilot Logbook" text.
   - Right: close button, 32×32, radius 16, bg `#152338`, `Ionicons close` 16pt in `#B5C8D8`. It calls `router.back()`.
2. **ScrollView** with padding 18 (bottom 28) and a gap of 22 between blocks. **No hero carousel. No MAX card. No Free comparison card.**
3. **Premium card**
   - bg `#0F1E3A`, border 1px `rgba(255,184,48,0.35)`, radius 18, padding 22 top / 20 sides / 20 bottom.
   - Title: "BLADES " in white plus "Premium" in gold `#FFB830`. Georgia, 21pt, weight 400, letterSpacing 0.3.
   - Price row: `alignItems: baseline`, gap 6, marginTop 14, marginBottom 20.
     - "39": Georgia 48pt, letterSpacing −1.5, lineHeight 48, white.
     - "kr / month": system 13pt, `#7FA8C8`.
   - **Benefit rows** (2). Each row: flexDirection row, gap 14, paddingVertical 16, top border 1px `#1A3A5A`. The last row also has a bottom border.
     - Icon tile: 36×36, radius 10, bg `rgba(255,184,48,0.10)`, border 1px `rgba(255,184,48,0.35)`, icon 18pt in gold.
     - Title: 15pt, weight 600, lineHeight 19.5, white.
     - Description: 12.5pt, `#7FA8C8`, lineHeight 18, marginTop 4.
     - Comparison chips: a row that wraps, gap 8, marginTop 8. Each chip has padding 4/8, radius 6, border 1px `#1A3A5A`, Menlo 11pt, `#7FA8C8`, `numberOfLines={1}`. The Premium chip has border `rgba(255,184,48,0.35)`, bg `rgba(255,184,48,0.10)`, text gold, weight 700.
     - Row 1: icon `logo-bitcoin` or a coin-style icon (the HTML draws its own coin glyph; any Ionicons coin/cash icon works).
       - Title: **"250 Blade-coins every month"**
       - Description: **"Used by the AI features: logbook scans, logging from a photo, aircraft lookups and CSV import. Refilled every month."**
       - Chips: **"Free · 100 once"** · **"Premium · 250 / month"**
     - Row 2: icon `infinite-outline`.
       - Title: **"Unlimited manual flights"**
       - Description: **"Log as many flights as you fly. No cap on your logbook."**
       - Chips: **"Free · 20 flights"** · **"Premium · unlimited"**
   - **CTA**: full width, height 52, radius 14, bg `#FFB830`, marginTop 22. Text **"Subscribe · 39 kr / month"**, 15.5pt, weight 800, letterSpacing 0.2, color `#0A1628`.
4. **Creator note**: paddingHorizontal 4, gap 10.
   - Body: **"I built BLADES for my own flying. Premium pays for the AI behind the scans and lookups, and keeps the app free of ads."** Georgia 16pt, lineHeight 24, `#B5C8D8`.
   - Signature: a 22×1 gold line, then **"CREATOR OF BLADES"** in Menlo 10.5pt, weight 700, letterSpacing 1.6, uppercase, gold. Gap 9 between line and text.
5. **Fine print**: centered, gap 8.
   - "Restore purchase": 13pt, weight 600, color `#00C8E8`.
   - "Billed monthly through your Apple ID. Renews automatically until you cancel in App Store settings." 10.5pt, `#5A7A9A`, lineHeight 17.
   - Links "Terms" and "Privacy" at 11pt in `#00C8E8`. They open `https://blades-app.com/terms.html` and `/privacy.html`.

## Interactions & behavior
- **Subscribe**: start the purchase flow. The existing code has a `TODO: Replace with RevenueCat`. While it runs, show a spinner in place of the label (18pt, navy on gold). On success, call `setTier('premium')`. The prototype then shows a green `#00E8A0` button reading "Premium active" and the toast "Welcome to Premium · 250 Blade-coins added". In the app, `router.back()` plus a toast is fine.
- **Restore purchase**: restore through the purchase SDK. If nothing is found, show the toast "No previous purchase found".
- **Close**: `router.back()`.
- **Press states**: the CTA scales to 0.985 when pressed (`activeOpacity` 0.85 is fine).

## State
- Uses the existing `useFlightStore().setTier`.
- Needs a local `purchasing: boolean` for the spinner.

## Code changes this implies (outside this screen)
- **Delete** `SlideFlightImport`, `SlideLogbookScan`, `SlideEASA`, `SlideShare`, `MaxCard`, `FreeMissCard` and the carousel from `premium.tsx`.
- **`components/PremiumModal.tsx`**:
  - Set `PREMIUM_PRICE_MONTHLY = 39` and remove the yearly price.
  - Update `PRIMARY_FEATURES` and the lead text. They still promise PDF export and EASA progress with forecast.
- **`constants/easa.ts`**: the owner says the Free limit is **20 flights**. The code has `FREE_TIER_LIMIT = 200`. Update it to 20.
- **Blade-coins**: Free gets 100 once and Premium gets 250 per month. Check that the token quota config (`store/tokenQuotaStore.ts` / `utils/tokenGate.ts`) matches.
- **MAX tier**: `SubscriptionTier` still includes `'max'`, and settings rows show "upgrade to MAX?". Remove the tier or hide it.

## Design tokens
- bg `#0A1628` · card `#0F1E3A` · elevated `#152338` · line `#1A3A5A`
- gold `#FFB830` · goldSoft `rgba(255,184,48,0.10)` · goldEdge `rgba(255,184,48,0.35)`
- cyan (links) `#00C8E8` · success `#00E8A0`
- text `#FFFFFF` · text2 `#B5C8D8` · text3 `#7FA8C8` · text4 `#5A7A9A`
- Fonts: Georgia (title, price, creator note), system (UI), Menlo (chips, signature)
- Radii: card 18 · CTA 14 · icon tile 10 · chips 6 · close 16

## Files
- `Premium Screen.html`: the prototype. Open it in a browser; the screen content lives inside `.screen`.
- `web-v3/blades-lockup-h.png`: the lockup used in the top bar.
