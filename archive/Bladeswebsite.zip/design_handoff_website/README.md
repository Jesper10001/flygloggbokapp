# Handoff: BLADES marketing website (v3) + Privacy / Terms

## Overview
Marketing site for **BLADES — Pilot Logbook** (iOS). One page with a Pilot ↔ Drone Pilot toggle that swaps accent color and copy, plus two legal pages. The page is built around the app's two strengths: **logging a flight in seconds** and **a physical-logbook view in the app that is easy to copy by hand**. It also says the app was built by a pilot for his own use.

Live domain referenced in the app: `https://blades-app.com` · Support: `support@blades-app.com`.

## About the design files
These files are **design references made in HTML** (React 18 via CDN + in-browser Babel). They show the intended look, copy and behavior. They are not production code. Rebuild them in the site's real stack (Next.js/Astro/plain static, whatever the site uses) following its own patterns. If no stack exists yet, a static build (Astro or Vite + React) is the simplest fit. The files do work as-is if dropped on a static host, but the in-browser Babel makes the page slow. Precompile before shipping.

`privacy.html` and `terms.html` are plain static HTML and can ship almost as they are. Only the logo path and the back link (`href="/"`) need checking.

## Fidelity
**High-fidelity.** Final colors, type, spacing, copy and interactions. Recreate pixel-accurately.

## Page structure (`Website v3.html` → `web-v3/app.jsx`)
Section order, top to bottom:

1. **Nav** (sticky, 64px, blurred): BLADES lockup · Pilot/Drone Pilot segmented toggle (sliding pill) · links Logbook / How it works / Features / Pricing · "Download" CTA. Burger menu on mobile.
2. **Hero**: eyebrow "BLADES · Pilot Logbook", H1 two lines (from `ROLE_DATA[role].heroA/heroB`), subline, App Store button + ghost button, 3 stats, phone mockup on the right (`Phone` component).
   - Pilot H1: "Log it in seconds." / "Copy it into your paper logbook."
   - Drone H1: "Every mission you fly," / "logged in seconds."
3. **Paper logbook** `#logbook`: heading "Open the page. *Copy it across.*" plus the `Spread` component, a two-page cream paper logbook (Date/From/To/Type/Reg/Total | PIC/Night/Ldg D/Ldg N/Remarks) with "Total this page / Brought forward / Total to date" rows and page numbers 38/39. It scrolls horizontally below 760px. The rows are **placeholder data**.
4. **Maker** `#maker`: eyebrow "Why it exists", heading "I built it *for myself*", two paragraphs in first person (serif, 18–22px), signature line "The pilot behind BLADES". The owner's name and photo still need to be added.
5. **Roles** `#roles`: three role-specific points plus a second phone mockup.
6. **How it works** `#how`: "Cockpit to logbook, *fast*." with 3 numbered steps.
7. **Features** `#features`: a 3-column grid of 6 cards, each with a small visual (`FeatViz`): Flight Load, Licence (CPL/ATPL), Quicklog, Insights, Logbook, Offline-first.
8. **World map** `#map`: a canvas globe you can drag to rotate (`Globe`). The stats and pins are **placeholder data**, and the hint "placeholder data" is visible.
9. **Pricing** `#pricing`: 2 cards, max-width 780px, centered.
   - **Free** · 0 · forever: Up to 200 manual flights · Logbook pages ready to copy by hand · Free Blade-coins to try AI import & lookup · Offline-first, no account
   - **Premium** · 39 kr / month (featured): Unlimited manual flights · Blade-coins refilled every month · Flight share cards · CPL/ATPL requirement tracking · Full ICAO airport database
10. **Closer / download** `#download`: lockup, "Your logbook, finally worth opening.", short copy, App Store CTA.
11. **Footer**: lockup · How it works / Features / Pricing / Privacy / Terms · "© 2026 BLADES · Built by a pilot, in Sweden".

### Copy rules (verified against the app repo `Jesper10001/flygloggbokapp`, 2026-09-24)
Do **not** add these back. They are not in the app:
- PDF export of any kind. It shows as "coming soon" in `app/(tabs)/settings.tsx`.
- Certificates and currency tracking. The screens can no longer be reached in manned mode.
- Battery-cycle counting for drones, and Operator-ID on exports (`services/droneExport.ts` has neither).
- MAX tier. Only Free + Premium 39 kr/month exist.
- Reviews and testimonials. They were removed because none exist.

Export that does exist: **CSV** (manned + drone).

## Interactions & behavior
- **Role toggle**: `role` state `'pilot' | 'drone'`. It sets CSS vars on `:root`: `--acc`, `--acc-soft`, `--acc-line` (pilot `#00C8E8`, drone `#FF8C42`). Everything that uses the accent transitions `color/background/border-color/box-shadow .5s`. The pill slides with `left` 3px ↔ 50%.
- **Reveal on scroll**: `.reveal` elements fade and slide up using IntersectionObserver (see `useReveal` in app.jsx). Stagger is 70ms per index via `transitionDelay`.
- **Globe**: drag rotates it (pointer events, momentum). When idle it spins slowly (`vY=.12`). Rotation around X is clamped to ±85°.
- **Buttons**: primary lifts 2px on hover, with a larger glow shadow. Ghost buttons get an accent border and soft fill on hover.
- **Responsive**: fluid type via `clamp()`. The nav collapses to a burger. Grids reflow to 1 column on mobile (see the media queries at the bottom of `styles.css`).

## Design tokens (`web-v3/styles.css :root`)
Colors:
- bg `#080F1C` · bg2 `#0A1628` · panel `#0F1E3A` · panel2 `#132845`
- rule `#1A3A5A` · rule2 `#25456A` · sep `#122030`
- ink `#F4F0E6` · ink2 `#B5C8D8` · ink3 `#7FA8C8` · ink4 `#5A7FA0`
- cyan (pilot accent) `#00C8E8` · amber (drone accent) `#FF8C42` · gold `#FFB830` · good `#00E8A0`
- acc-ink (text on accent) `#04101F`
- Paper spread: page `#ECE3CC`, ink `#3A2E1C`, lines `#C9B98B`, column rules `#D9CEB4`, headers `#6B5430`

Type:
- Display/headings: **Fraunces** 500 (italic 400 for `<em>`, colored with the accent). Section titles use `clamp(30px,4.6vw,50px)`, letter-spacing −.02em, line-height 1.04.
- UI/body: **Inter** 400–800, body line-height 1.55.
- Mono (eyebrows, stats, labels): **Geist Mono**. Eyebrows are 11px/700, letter-spacing .24em, uppercase.
- Spread handwriting feel: `'Courier New'`.

Layout: max width 1180px, gutter 26px, section padding `clamp(76px,11vw,128px)`, buttons are full pills (999px) with 14×22 padding.

## Assets
- `web-v3/blades-lockup-h.png`: the horizontal BLADES lockup (nav, closer, footer, legal pages).
- Fonts: Google Fonts (Fraunces, Inter, Geist Mono).
- No other images. The phone mockups, feature visuals, spread and globe are all drawn in code.

## Files
- `Website v3.html`: entry point (fonts, CDN React, loads the two files below)
- `web-v3/app.jsx`: all components, copy and data (`ROLE_DATA`, `HOW`, `FEATURES`, `PLANS`, `Spread`, `Globe`, `Phone`, `FeatViz`)
- `web-v3/styles.css`: all styles and tokens
- `privacy.html`, `terms.html`: legal pages (text from the owner, verbatim except "certificates" removed from Privacy §2)

## Open items for the owner
- Add your name and photo in the Maker section (currently "The pilot behind BLADES"). Confirm the line "I fly for a living".
- Replace the placeholder spread rows and globe stats with real data or screenshots.
- Point the App Store buttons to the real App Store URL (currently `#download`).
- In the app, `app/settings/premium.tsx` still says 49 kr, MAX 149 kr and "EASA-format PDF". Update it to match the site.
