# Handoff: Flight Performance Layer (share overlay)

## Overview

A **Strava-style photo-overlay** for sharing a single flight. The user picks a
photo of their flight; this layer floats **directly on top of it** — no card, no
panel, no background of its own. It shows three centered, stacked performance
stats, the BLADES B mark, and a fixed "logged in BLADES Joint Logbook" credit in
the bottom-right corner. It's one of several share layers in the app (alongside
the Postcard / Stamp variants); this one is the clean, minimal, performance-led
option.

## About the design file

`source/Flight performance layer.html` is a **design reference** (React + Babel,
runs in a browser). It is **not production code** — recreate it in the app's
React Native / Expo share-card pipeline, reusing the existing photo source,
`Colors` tokens, and fonts. The HTML renders the overlay TWICE side by side: once
on a **checkerboard** (proof the layer is fully transparent — nothing is drawn
behind the text) and once over the **example photo**. In production only the
overlay-over-user-photo composite matters.

## Fidelity

High-fidelity layout & type. The output is a portrait share image (the preview
uses a 3:4 card; match the app's existing share-image aspect, e.g. 1080×1350).
Everything is centered.

## The layer (exact spec)

A transparent, absolutely-positioned overlay filling the image, content centered
vertically and horizontally, `gap: 30`, `padding: 24`:

1. **Three stacked stats**, each = a small label above a big bold value:
   - label: Inter 700, 17px, white
   - value: Inter 800, 40px, white, letter-spacing −1; the unit is part of the
     value at the same weight, separated by a space.
   - The three stats, top → bottom:
     - **Distance** — `544 km`
     - **Pace** — `0:03 /km`
     - **Elev gained** — `2,743 m`
2. **BLADES B mark** (image), 54px tall, centered, `margin-top: 6`. Two assets
   provided: `blades-mark-gold.png` and `blades-mark-blue.png` — the current
   design uses the **blue** mark (swap the `mark` prop to use gold).
3. **Fixed corner credit**, bottom-right (`right: 18, bottom: 16`), baseline-
   aligned row: *logged in* (Inter italic 500, 12px, white 78%) · **BLADES**
   (Inter 800, 13px, letter-spacing 2, white) · Joint Logbook (Inter 600, 11px,
   white 78%). This is the same credit used on the app's other share layers and
   is **not movable / not hideable**.

All text uses a soft shadow for legibility on any photo:
`text-shadow: 0 1px 10px rgba(0,0,0,0.45)`.

## The three metrics — how they're derived

These come from data the app already has for the flight; **invent nothing new**:

| Stat | Unit | Source / formula |
|---|---|---|
| **Distance** | km | The app's generated great-circle/route distance. If stored in NM, convert: `km = NM × 1.852`. |
| **Pace** | m:ss **/km** | Block time ÷ distance, formatted minutes:seconds per km. Because aircraft are fast this is tiny — e.g. 600 kn ≈ 1,111 km/h → **0:03 /km**. Keep the `m:ss/km` format (seconds-level) regardless of how small. |
| **Elev gained** | m | Max altitude, converted from feet to the **nearest metre** (`m = round(ft × 0.3048)`). Reference used here: 9,000 ft → **2,743 m**. (Label is "Elev gained" to match Strava's wording even though the source is max altitude.) |

Pace was previously shown as Avg speed (knots) and Time — those were replaced.
The layer intentionally shows **Distance / Pace / Elev gained** (no time).

## Tokens & fonts
- Accent gold `#FFB830`; canvas navy `#0A1628` (only the demo page bg — the layer
  itself is transparent).
- Fonts: **Inter** (400–900) for everything here; JetBrains Mono is loaded for the
  demo chrome only. Use the app's existing Inter + the brand mark assets.

## Assets (in `source/share-assets/`)
- `blades-mark-blue.png` — blue B mark (current default for this layer)
- `blades-mark-gold.png` — gold B mark (alternate)
- `example-photo.jpeg` — sample flight photo for preview only; in production the
  user's own photo fills the frame.

## Acceptance
- Overlay is fully transparent (verify on the checkerboard panel — nothing but
  the text/mark/credit is painted).
- Distance/Pace/Elev gained centered & stacked, blue B mark below, fixed
  "logged in BLADES Joint Logbook" credit bottom-right.
- Values derive from the formulas above off real flight data.
