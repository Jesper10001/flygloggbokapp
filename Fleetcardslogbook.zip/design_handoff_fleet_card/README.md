# Handoff: Fleet card — "Ledger"

## Overview
A redesign of the **aircraft (fleet) card** in the BLADES Joint Logbook app —
the cards shown on the **Fleet** tab (the third toggle on the Logbook page,
next to List and the physical Book). Each card represents one **aircraft model**
the pilot has flown, with its performance specs (editable), type-rating validity,
total time on type, and its registrations.

The chosen direction is **"Ledger"** — a clean, editorial card with a photo
banner whose subject (the aircraft) is **lifted from its background and spills
over the card edge in 3D**. Build only this one design.

## About the design files
`source/Fleet Card Ledger.html` is a **React + Babel design reference** showing
the final look on **dark and light themes** side by side, plus two live sliders
(Text size / Number size) used only to dial in proportions — **default 1.15× for
both; bake that in and drop the sliders for production.** Recreate the card in the
app's existing **React Native / Expo** stack with the real `Colors` tokens, fonts,
and `aircraft_registry` data. Translate `<div>`/CSS → `View`/`Text`/`StyleSheet`.

## Fidelity
High-fidelity. Final colours, type, spacing, layout. The 1.15× slider state is
the intended size — every `t(px)`/`n(px)` value in the file is already the base
px; multiply by 1.15 (or just read the rendered sizes) and hard-code.

---

## Card anatomy (top → bottom)
1. **Photo banner** (height ~96, clipped to the card's top corners) — the aircraft
   photo, darkened toward the bottom with a `card`-colored vertical gradient so it
   fuses into the card surface.
2. **Subject pop-out** — the SAME photo with its background removed, layered at the
   SAME scale/position on top, allowed to **overflow downward** past the banner so
   the aircraft's lower body (skids/fuselage) spills onto the card body. A single
   downward drop-shadow (`drop-shadow(0 14px 9px <bgDeep>)`) sits **around/under**
   the silhouette only — never over the body. See *Subject lift* below for how to
   generate the cut-out natively.
3. **`NOW` badge** (top-left, accent) on the current aircraft; **edit (pencil)
   button** top-right toggles inline editing of the spec values.
4. **Header row** — model name (Fraunces serif, large), maker · class beneath;
   right side a **rating status pill** (color-coded valid/expiring/expired) +
   "Rating exp YYYY-MM-DD".
5. **Total on type** — label left, big serif `H:MM` value right, with an accent `h`.
6. **Spec groups** (3), each a mono label over a row of stat cells divided by hairlines:
   - **Performance** — VNE (kt), Cruise (kt), Ceiling (ft)
   - **Weights** — MTOW (kg), Empty (kg), Fuel (L)
   - **Range & endurance** — Range (NM), Endurance (h)
   All eight values are **editable** when the pencil is toggled (numeric inputs).
7. **Registrations** — count top-right; **top-3 always shown** (reg + hours on that
   reg, dotted leader between), with **"Show all N" / "Show less"** expanding the rest.
8. **Footer** — "Last flown {relative}".

## Fleet layout (from earlier work — keep)
- **Always one large full-width card per aircraft, stacked vertically** — the
  layout is identical whether the pilot has 1 aircraft or many. No 2-column grid.
- Cards ordered by most-recently-logged flight; the current aircraft first with the `NOW` badge + accent border.

## Design tokens
Navy theme = app's existing `Colors`. The file's `DARK`/`LIGHT` objects give both
palettes; key ones (dark): card `#102441`, border `#1A3A5A`, accent `#00C8E8`,
valid `#00E8A0`, expiring `#FFB830`, expired `#FF4D6A`, bgDeep `#06101E`.
Light variants are in the `LIGHT` object — use the app's real light-theme tokens.
Type: Fraunces (serif — model name, totals), JetBrains Mono (data/labels), Inter (body).

---

## ⭐ Subject lift (native iOS — the key feature)
The pop-out cut-out in the prototype is a **pre-baked PNG** (`aircraft-cutout.png`).
In the app, generate it **on device** with Apple's subject-lifting, the same tech
Photos uses for "lift subject from background":

1. **Fetch** the type photo: the `aircraft_registry` row already has an
   `image_url`. Download → `Data` → `UIImage`/`CGImage`. (Let users pick/replace
   the image per type; cache the original locally.)
2. **Generate the foreground mask** with Vision:
   - `VNGenerateForegroundInstanceMaskRequest` (iOS 17+). Run it on the `CGImage`
     via a `VNImageRequestHandler`; take the resulting instance mask and call
     `generateMaskedImage(ofInstances:from:croppedToInstancesExtent:)` to get the
     subject composited with a **transparent background** (a `CVPixelBuffer` →
     `CGImage` → `UIImage`).
   - Alternative high-level API: `ImageAnalysisInteraction` / `ImageAnalyzer` with
     `analysis.subjects` → `subject.image` gives the lifted subject directly (same
     engine as Photos). Either is fine.
3. **Composite two layers** in the card's banner:
   - Layer A: full original photo, clipped to the banner rect + bottom gradient.
   - Layer B: the masked cut-out, **same frame/scale as A**, with `overflow:
     visible` downward so the lower body extends past the banner onto the card.
     Apply one soft downward shadow to B (e.g. `shadowOffset {0, 6}`, blur ~9,
     `shadowColor` = card bgDeep) — shadow only reads **around** the silhouette.
4. **Cache** both the original and the generated cut-out PNG per aircraft type
   (Vision is expensive — never re-run every render). Key by type + image hash.
5. **Fallback**: if the device is < iOS 17, the request fails, or no subject is
   found → render Layer A only (plain banner, no pop-out). Graceful degradation;
   never block the card.
6. **Performance**: run the mask generation off the main thread, show the plain
   banner first, then swap in the cut-out when ready. Respect reduced-motion (no
   slide-in needed).

> RN note: this is native iOS (Swift/VisionKit) — expose it through a small native
> module / Expo config plugin that takes an image URL and returns a cached cut-out
> file URI, then render the two `<Image>` layers in the RN card. Android has no
> equivalent subject-lift → always use the plain-banner fallback there.

## Files in this bundle
| File | What it is |
|---|---|
| `source/Fleet Card Ledger.html` | The design reference — open in a browser; dark + light, size sliders (default 1.15×, bake in). |
| `source/share-assets/aircraft-example.jpeg` | Sample aircraft photo (AW139) used as the banner. |
| `source/share-assets/aircraft-cutout.png` | Pre-baked transparent cut-out used for the pop-out — **in the app, generate this with VisionKit instead** (see *Subject lift*). |
