# Handoff: BLADES — Log Flight (pilot-manned) redesign

## Overview

A redesign of the **Log Flight** screen for pilot-manned (helicopter & fixed-wing).
This is the most-used, most complex screen in the app — the user has invested
heavily in its existing logic. **Every existing function must be preserved
exactly; only the UX/visual layer changes.** The goal: fast, simple, professional
data entry for a flight.

The design is a **single-scroll form with a Quicklog ↔ Full toggle** plus a
**Real-flight ↔ Sim toggle**. Quicklog shows only essentials; Full reveals
everything. A sticky Save button is always visible.

## About the design files

`source/` is a **design reference built in HTML/React+Babel** — a clickable hi-fi
prototype of the intended look and interactions. It is **NOT production code**.
Rebuild it in the app's existing **React Native / Expo** stack, reusing the real
form state, validation, DB writes, `Colors` tokens and existing pickers. Wire
every control to the fields the current Log Flight screen already persists
(`app/flight/add.tsx` and its store) — do not invent new data.

**Prototype-only scaffolding — do NOT port:** `ios-frame.jsx` (device bezel),
`design-canvas.jsx`, `app.jsx` (mount harness), `fontpanel.jsx` (was a dev font
picker, already removed). The DSEG7 LED webfont + Google fonts are loaded in the
HTML `<head>` — in RN use the app's fonts (see Typography).

## Fidelity
High-fidelity. Final layout, spacing, colours, interactions. ~393pt wide screen.

---

## Modes (two toggles at the top)
- **Quicklog ↔ Full** — Quicklog = route, times, aircraft, role, auto take-off/
  landing, save. Full = adds conditions bars, take-off/approach/landing counters,
  crew, training approaches, remarks.
- **Real-flight ↔ Sim** — Sim swaps the route card for a **Simulator type**
  chooser and simplifies the rest (see Sim below).

---

## Card 1 — Route / times (the "above the fold" hero)
One card, two synced legs (**Departure** left, **Arrival** right), reaching full
card width. For each leg:
- **ICAO code** in a 14-seg LED-style display (`lf-led14`); airport **name**
  centered under the row once resolved. Free-text ICAO search + an **ICAO ⇄ ZZZZ**
  sliding toggle (ZZZZ = temporary/unlisted field). A cyan **Here** pin (tap →
  nearby-airports picker; not built in proto). 3 recent-airport quick-chips under
  each ICAO field.
- **Block time** under the ICAO in a 7-seg LED display (`lf-led`, DSEG7 webfont)
  with a faint "ghost-8" backdrop. A per-field **Z ⇄ local timezone** toggle
  (matches git's UTC/local presentation).
- A downward **aircraft glyph** travels the dashed connector between the legs —
  uses the real onboarding art: `plane-cyan.png` (fixed-wing) or `heli-cyan.png`
  (helicopter), chosen by `LF_isHeli(aircraftType)`. Small country flags sit at
  the top (dep) and bottom (arr) of the connector.

Below the legs, a centered block:
- **Total flight time** (auto from block times) — large LED display, cyan border,
  label under. **Distance** (NM) to its left in the ICAO LED font (white, no glow).
  A **VFR · Y/Z · IFR** sliding segmented toggle (Quicklog: VFR/IFR only).
- A **globe** to the right showing Day/Night flight (digital cyan/navy grid
  globe). **Tap → Sun-route modal** (see below). "Night flight"/"Day flight"
  label above it.
- A collapsible **Stops/App** trigger (bottom-left) → the stops/via builder
  (intermediate touch-&-go / via airports), reactive to VFR/IFR/Y·Z.

## Card 2 — Conditions (Full only)
Floating drag-bars (no card chrome), in order **VFR · IFR · NVG**, plus a
read-only **Night** bar:
- **VFR & IFR are linked** — you must fly one or the other; dragging one adjusts
  the other (can't be both at once). Snaps in **5-min steps**, with detents at
  50% and 100% of total.
- **Night bar** is read-only, auto-filled from the twilight calc (dawn/day/dusk/
  night) — shown only when the flight actually crosses night. The night **time**
  is centered above the night portion.
- **NVG bar** glows outward from the middle of the night period as you increase it
  (matching night minutes); exceeding the dawn→dusk window turns the excess
  **red** (warning). Detents at 50%/100% of the night period. NVG only shown when
  the flight touches the dawn→dusk window.

## Card 3 — Take-offs / Approaches / Landings (Full only)
Compact +/- counters: **Take-offs** (day/night), **Landings** (day/night),
**Approaches** split **2D / 3D**. 2D/3D approaches only show for IFR or Y/Z (not
VFR). In **Quicklog** this card is hidden — the app auto-sets 1 take-off + 1
landing, day/night decided by the flight's twilight.

## Card 4 — Aircraft & crew (Full)
Aircraft **type** + **registration** fields (no quick-chips). Second pilot + role,
and an **Add crew member** button for additional crew + roles (matches git's
multi-crew model: PIC/CO-PILOT/INSTRUCTOR/DUAL/PICUS etc).

## Card 5 — Approach & notes (Full)
Training-approach flow + **Remarks** textarea. The training-approach builder is a
chained flow per route ICAO: pick 2D/3D → approach type (ILS/RNP/VOR…) → runway,
appended into Remarks as e.g. "ESSA ILS 27R". (Departure airport excluded.)

---

## Sim mode
When **Sim** is selected:
- A **Simulator type** chooser appears above the route card: **FFS · FTD ·
  FNPT/II · FNPT/I · BITD · CPT/PPT · CBT** (from `sim_category` in git). CPT/PPT
  and CBT show a "does not count toward licence/rating credit" warning.
- The day/dusk/dawn/night twilight bar and the globe + distance are **hidden**.
- A plain **Night** bar appears above the NVG bar; in sim the **NVG bar is NOT
  tied to real twilight** (no red warning, no white detent lines).
- Stops/App is hidden; only a (smaller) **Remarks** textarea remains at the bottom.

---

## Sun-route modal (tap the globe)
A full sun-relation view along the flight: an **advanced, reactive map** that
auto-zooms to the country/countries the route touches (domestic → that country +
neighbours; international → fit both), with real coastlines, a graticule, the
day/night **terminator**, the sun's subsolar point, a colour-by-sun-state route,
dep/arr pins and an animated plane on a time-scrubber.

**The astronomy is pure and already written** (`sunroute.jsx`: `subsolar`,
`altitude`, `sunState`, terminator/route/scrubber). Port it unchanged.

**To put a REAL map under it**, follow `logflight-ux/CLAUDE_CODE_MAP.md` (included
in this bundle): the modal is split into a **base map layer** (replace with the
app's existing Apple `react-native-maps` / `GlobalAirportMap`) and a **transparent
overlay layer** (keep as-is). The doc covers projection alignment (equirectangular
vs native Mercator via `pointForCoordinate`), camera framing, dark styling, and
gesture handling. **This is the key implementation note you asked for.**

---

## Typography
- **Geist Mono** — mono/data labels (`--lf-mono`).
- **Inter / SF** — body (`--lf-sans`).
- **Fraunces** — occasional serif (`--lf-serif`).
- **DSEG7-Classic** (7-seg LED webfont, via `dseg` CDN) — dep/arr block times &
  total time (`.lf-led`, with the faint ghost-8 ::before backdrop).
- **Chakra Petch** — ICAO codes (`.lf-led14`, soft glow).
In RN, bundle DSEG7 + Chakra Petch (or substitute a 7-seg font you ship) and keep
the white-LED + glow treatment; everything else uses the app's existing fonts.

## Design tokens (Navy — `constants/colors.ts`)
bg `#0A1628` · deep `#06101E` · surface `#0F1E3A` · card `#102441` · border
`#1A3A5A` · **primary/cyan `#00C8E8`** · gold `#FFB830` · success `#00E8A0` · night
`#5DA9FF` · violet `#9B8CFF` · danger `#FF4D6A` · text `#FFFFFF` · muted `#5A7FA0`
· inverse `#04101F`. Total-time uses a gold gradient
`linear-gradient(180deg,#FFE9A8,#F2C45A,#C8902A)` with a cyan border.

## Assets in this bundle
- `plane-cyan.png`, `heli-cyan.png` — cyan-toned onboarding glyphs (recolored from
  git's `Pilot-fixedwing.PNG` / `Pilot-helicopter.PNG`). In-app, recolor those
  originals instead of bundling these.
- No other imagery; icons are inline SVG (`LFIcon` in `shared.jsx`).

## Files
| File | Role |
|---|---|
| `source/Log Flight Design.html` | Open in a browser to view the full interactive prototype (Quicklog/Full + Real/Sim toggles). |
| `source/logflight-ux/shared.jsx` | Tokens, demo data, field shapes, `LFIcon`, `LF_isHeli`. **Primary reference for data + tokens.** |
| `source/logflight-ux/fields.jsx` | Field primitives (ICAO column, toggles, counters, bars, crew). |
| `source/logflight-ux/design-a.jsx` | The screen itself — all cards, modes, conditions logic, take-off/landing, stops. **The build reference.** |
| `source/logflight-ux/sunroute.jsx` | Sun-route modal + astronomy (port the math unchanged). |
| `source/logflight-ux/CLAUDE_CODE_MAP.md` | **How to add the real Apple map under the sun overlay.** |
| `ios-frame / design-canvas / app.jsx` | Prototype scaffolding — do not port. |
