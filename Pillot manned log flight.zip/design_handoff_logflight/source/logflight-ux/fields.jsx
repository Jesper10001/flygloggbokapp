// Log Flight — reusable field controls shared by Design A & B.
const { useState: uSt } = React;

// ── Crew editor: second pilot (role + name) + additional crew members ──
const SP_ROLES = [['PIC', 'PIC'], ['COP', 'Co-pilot'], ['FI', 'FI'], ['SPIC', 'SPIC'], ['PICUS', 'PICUS']];
const CREW_ROLES = [['CC', 'Crew chief'], ['RS', 'Rescue swimmer'], ['HO', 'Hoist op'], ['ME', 'Med crew'], ['LM', 'Loadmaster'], ['OBS', 'Observer'], ['STU', 'Student']];
function RolePill({ open, onToggle, label, options, value, onPick }) {
  const C = window.LF_C;
  return (
    <div style={{ position: 'relative' }}>
      <button onClick={onToggle} style={{ display: 'flex', alignItems: 'center', gap: 4, height: 34, padding: '0 9px',
        background: value ? C.primary : C.elevated, border: `1px solid ${value ? C.primary : C.border}`, borderRadius: 8, cursor: 'pointer',
        color: value ? C.inverse : C.text3, fontFamily: window.LF_MONO, fontSize: 10, fontWeight: 700, whiteSpace: 'nowrap' }}>
        {value || label}<window.LFIcon name="chevDown" size={11} /></button>
      {open &&
      <div style={{ position: 'absolute', top: 38, left: 0, zIndex: 30, background: C.card, border: `1px solid ${C.border}`,
        borderRadius: 10, padding: 4, boxShadow: '0 10px 30px rgba(0,0,0,.5)', display: 'flex', flexDirection: 'column', gap: 2, minWidth: 130 }}>
          {options.map(([k, l]) => <button key={k} onClick={() => onPick(k)} style={{ textAlign: 'left', padding: '7px 9px',
          background: value === k ? C.primary + '22' : 'transparent', border: 'none', borderRadius: 6, cursor: 'pointer',
          color: value === k ? C.primary : C.text2, fontFamily: window.LF_SANS, fontSize: 12, fontWeight: 600 }}>
            <b style={{ fontFamily: window.LF_MONO, marginRight: 6 }}>{k}</b>{l}</button>)}
        </div>
      }
    </div>);

}
function CrewEditor({ sp, onSp, crew, onCrew }) {
  const C = window.LF_C;const [open, setOpen] = uSt(null);
  const nameInput = (val, onChange, ph) =>
  <input value={val} onChange={(e) => onChange(e.target.value)} placeholder={ph}
  style={{ flex: 1, minWidth: 0, background: 'none', border: 'none', outline: 'none', color: C.text,
    fontFamily: window.LF_SANS, fontSize: 13, fontWeight: 600, padding: 0 }} />;

  return (
    <div style={{ marginTop: 11, display: 'flex', flexDirection: 'column', gap: 7 }}>
      {/* second pilot — the pilot you fly with */}
      <div>
        <div style={{ marginBottom: 5 }}>{window.lfLabel('Second pilot')}</div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 7, background: C.elevated, border: `1px solid ${C.border}`,
          borderRadius: 10, padding: '7px 9px' }}>
          <RolePill open={open === 'sp'} onToggle={() => setOpen(open === 'sp' ? null : 'sp')} label="Role"
          options={SP_ROLES} value={sp.role} onPick={(k) => {onSp({ ...sp, role: k });setOpen(null);}} />
          {nameInput(sp.name, (v) => onSp({ ...sp, name: v }), 'Name')}
        </div>
      </div>
      {/* additional crew */}
      {crew.length > 0 && <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
        {crew.map((m, i) =>
        <div key={m.id} style={{ display: 'flex', alignItems: 'center', gap: 7, background: C.elevated, border: `1px solid ${C.border}`,
          borderRadius: 10, padding: '7px 9px' }}>
            <RolePill open={open === m.id} onToggle={() => setOpen(open === m.id ? null : m.id)} label="Role"
          options={CREW_ROLES} value={m.role} onPick={(k) => {onCrew(crew.map((x) => x.id === m.id ? { ...x, role: k } : x));setOpen(null);}} />
            {nameInput(m.name, (v) => onCrew(crew.map((x) => x.id === m.id ? { ...x, name: v } : x)), 'Name')}
            <button onClick={() => onCrew(crew.filter((x) => x.id !== m.id))} style={{ flexShrink: 0, width: 26, height: 26, display: 'grid',
            placeItems: 'center', background: 'none', border: 'none', cursor: 'pointer', color: C.muted }}><window.LFIcon name="close" size={14} /></button>
          </div>
        )}
      </div>}
      <button onClick={() => onCrew([...crew, { id: String(Date.now()), role: '', name: '' }])}
      style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 6, height: 36, background: 'none',
        border: `1px dashed ${C.border}`, borderRadius: 10, cursor: 'pointer', color: C.primary,
        fontFamily: window.LF_SANS, fontSize: 12, fontWeight: 700 }}>
        <window.LFIcon name="plus" size={14} />Add crew member</button>
    </div>);

}
window.LF_CrewEditor = CrewEditor;

function lfCard(extra) {const C = window.LF_C;return { background: C.card, border: `1px solid ${C.border}`, borderRadius: 16, ...extra };}
function lfLabel(children) {const C = window.LF_C;return (
    <div style={{ fontFamily: window.LF_MONO, fontSize: 9.5, fontWeight: 700, letterSpacing: '1.3px',
      textTransform: 'uppercase', color: C.text3 }}>{children}</div>);}

// section header with optional auto-filled cue
function LFSection({ icon, title, hint, right }) {
  const C = window.LF_C;
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 8, margin: '2px 2px 9px' }}>
      {icon && <span style={{ color: C.primary, display: 'flex' }}><window.LFIcon name={icon} size={15} /></span>}
      <span style={{ fontFamily: window.LF_MONO, fontSize: 10.5, fontWeight: 700, letterSpacing: '1.4px',
        textTransform: 'uppercase', color: C.text2 }}>{title}</span>
      {hint && <span style={{ fontFamily: window.LF_MONO, fontSize: 9, color: C.muted }}>{hint}</span>}
      <span style={{ flex: 1 }} />
      {right}
    </div>);

}

// auto-filled pill (shows when a value was computed for you)
function AutoPill({ children }) {
  const C = window.LF_C;
  return (
    <span style={{ display: 'inline-flex', alignItems: 'center', gap: 4, padding: '2px 7px', borderRadius: 999,
      background: 'rgba(0,232,160,0.14)', border: '1px solid rgba(0,232,160,0.4)',
      fontFamily: window.LF_MONO, fontSize: 8, fontWeight: 700, letterSpacing: '0.6px', color: C.success, textTransform: 'uppercase' }}>
      <window.LFIcon name="check" size={9} />{children}</span>);

}

// segmented control — sliding indicator
function Seg({ options, value, onChange, size = 'md' }) {
  const C = window.LF_C;const pad = size === 'sm' ? '5px 9px' : '7px 12px';
  const opts = options.map((o) => typeof o === 'string' ? { v: o, l: o } : o);
  const idx = Math.max(0, opts.findIndex((o) => o.v === value));
  return (
    <div style={{ position: 'relative', display: 'flex', background: C.elevated, border: `1px solid ${C.border}`, borderRadius: 9, padding: 3 }}>
      <div style={{ position: 'absolute', top: 3, bottom: 3, left: 3, width: `calc((100% - 6px) / ${opts.length})`,
        transform: `translateX(${idx * 100}%)`, transition: 'transform .22s cubic-bezier(.4,1.3,.5,1)',
        background: C.primary, borderRadius: 7, boxShadow: `0 0 10px ${C.primary}55` }} />
      {opts.map((o) => {const sel = value === o.v;
        return <div key={o.v} onClick={() => onChange(o.v)} style={{ position: 'relative', zIndex: 1, flex: 1, textAlign: 'center', cursor: 'pointer',
          color: sel ? C.inverse : C.text3, transition: 'color .2s', borderRadius: 7, padding: pad,
          fontFamily: window.LF_MONO, fontSize: 11, fontWeight: 700, letterSpacing: '0.4px', whiteSpace: 'nowrap' }}>{o.l}</div>;})}
    </div>);
}

// big tappable time field
function TimeField({ label, value, onChange, auto, zone, onZone, tzAbbr = 'LT', offH = 0 }) {
  const C = window.LF_C;const [foc, setFoc] = uSt(false);
  // git presentation: UTC entered with a "Z" tag; local label "HH:MM CEST" shown beneath.
  const localStr = (() => {
    const m = (value || '').match(/^(\d{1,2}):(\d{2})$/); if (!m) return null;
    const t = ((+m[1] + offH) % 24 + 24) % 24;
    return `${String(t).padStart(2, '0')}:${m[2]}`;
  })();
  const showLocal = zone === 'local';
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 5, flex: 1, minWidth: 0 }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 5 }}>{lfLabel(label)}{auto && <AutoPill>auto</AutoPill>}</div>
      <div style={{ display: 'flex', alignItems: 'center', gap: 6, background: C.elevated,
        border: `1.5px solid ${foc ? C.primary : C.border}`, borderRadius: 11, height: 46, padding: '0 8px 0 11px', transition: 'border-color .15s' }}>
        <input className="lf-led" data-led="88:88" value={showLocal && localStr ? localStr : value} placeholder="--:--" inputMode="numeric"
        readOnly={showLocal}
        onFocus={() => setFoc(true)} onBlur={() => setFoc(false)}
        onChange={(e) => {let v = e.target.value.replace(/[^0-9]/g, '').slice(0, 4);if (v.length >= 3) v = v.slice(0, 2) + ':' + v.slice(2);onChange(v);}}
        style={{ flex: 1, minWidth: 0, background: 'none', border: 'none', outline: 'none', textAlign: 'left',
          fontWeight: 700, fontSize: 17, letterSpacing: '1px', width: '100%' }} />
        {onZone ?
        <button onClick={() => onZone(zone === 'z' ? 'local' : 'z')} title={zone === 'z' ? 'Zulu (UTC)' : 'Local time'}
          style={{ flexShrink: 0, display: 'inline-flex', alignItems: 'center', gap: 3, height: 22, borderRadius: 999, cursor: 'pointer',
          background: 'transparent', border: `1px solid ${(zone === 'z' ? C.primary : C.gold)}44`, padding: '0 5px' }}>
          <span style={{ width: 4, height: 4, borderRadius: '50%', background: zone === 'z' ? C.primary : C.gold,
            boxShadow: `0 0 4px ${zone === 'z' ? C.primary : C.gold}` }} />
          <span style={{ color: zone === 'z' ? C.primary : C.gold, fontFamily: window.LF_MONO, fontSize: 9, fontWeight: 800, letterSpacing: '.5px' }}>
            {zone === 'z' ? 'Z' : tzAbbr}</span></button> :
        <span style={{ fontFamily: window.LF_MONO, fontSize: 10, color: C.muted }}>z</span>}
      </div>
      {/* git-style secondary local label under the field (only in UTC mode) */}
      {onZone && zone === 'z' && localStr &&
        <span style={{ fontFamily: window.LF_MONO, fontSize: 9, fontWeight: 700, letterSpacing: '.4px', color: C.muted, paddingLeft: 2 }}>
          {localStr} {tzAbbr}</span>}
    </div>);

}

// ICAO column — icon header + code/name box with pin, vertical ICAO/Temp toggle at right
function ICAOCol({ legLabel, filled, code, mode, onCode, onMode, recent, icon }) {
  const C = window.LF_C;const [foc, setFoc] = uSt(false);
  const ap = window.LF_AIRPORTS.find((a) => a.icao === code);
  const hasName = mode === 'temp' ? code.length >= 2 : !!ap;
  return (
    <div style={{ flex: 1, minWidth: 0, display: 'flex', flexDirection: 'column', gap: 8 }}>
      {/* clean text title — no icon */}
      <div style={{ display: 'flex', justifyContent: 'center' }}>
        <span style={{ fontFamily: window.LF_SANS, fontSize: 12, fontWeight: 700, letterSpacing: '.3px',
          color: filled ? C.text : C.text2 }}>{legLabel.charAt(0) + legLabel.slice(1).toLowerCase()}</span>
      </div>
      {/* ICAO / ZZZZ segmented toggle — full width, above the code box */}
      {/* ICAO / ZZZZ sliding toggle — single indicator, full width */}
      <div style={{ position: 'relative', display: 'flex', background: C.elevated, border: `1px solid ${C.border}`, borderRadius: 8, padding: 3 }}>
        <div style={{ position: 'absolute', top: 3, bottom: 3, left: 3, width: 'calc((100% - 6px) / 2)',
          transform: `translateX(${mode === 'temp' ? '100%' : '0'})`, transition: 'transform .22s cubic-bezier(.4,1.3,.5,1)',
          background: C.primary, borderRadius: 6, boxShadow: `0 0 10px ${C.primary}55` }} />
        {['icao', 'temp'].map((m) => <div key={m} onClick={() => onMode(m)} style={{ position: 'relative', zIndex: 1, flex: 1, textAlign: 'center', cursor: 'pointer',
          color: mode === m ? C.inverse : C.text3, transition: 'color .2s',
          padding: '4px 0', fontFamily: window.LF_SANS, fontWeight: 700, letterSpacing: '.3px', fontSize: "10px" }}>{m === 'icao' ? 'ICAO' : 'ZZZZ'}</div>)}
      </div>
      <div style={{ display: 'flex', alignItems: 'stretch' }}>
        <div style={{ flex: 1, minWidth: 0, display: 'flex', alignItems: 'center', gap: 4, background: C.elevated,
          border: `1.5px solid ${foc ? C.primary : C.border}`, borderRadius: 10,
          height: 44, padding: '0 8px 0 11px' }}>
          <div style={{ flex: 1, minWidth: 0, display: 'flex', alignItems: 'center' }}>
            <input className="lf-led14" data-led="~~~~~" value={code} placeholder={mode === 'temp' ? 'NAME' : 'ICAO'} onFocus={() => setFoc(true)} onBlur={() => setFoc(false)}
            onChange={(e) => onCode(e.target.value.toUpperCase())} maxLength={5}
            style={{ background: 'none', border: 'none', outline: 'none',
              fontSize: 19, fontWeight: 700, letterSpacing: '2px', textTransform: 'uppercase', width: '100%', padding: 0 }} />
          </div>
          {/* here-pin — fully cyan + "Here" caption */}
          <button title="Nearby airports" style={{ flexShrink: 0, alignSelf: 'center', display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 1,
            background: 'none', border: 'none', cursor: 'pointer', color: C.primary, padding: 0 }}>
            <window.LFIcon name="pinFill" size={18} />
            <span style={{ fontFamily: window.LF_SANS, fontSize: 7.5, fontWeight: 700, letterSpacing: '.3px', color: C.primary }}>Here</span>
          </button>
        </div>
      </div>
      {hasName && <span style={{ fontFamily: window.LF_SANS, fontSize: 10, color: C.text2, whiteSpace: 'nowrap',
        overflow: 'hidden', textOverflow: 'ellipsis', textAlign: 'center' }}>{mode === 'temp' ? 'Temporary site' : ap.name}</span>}
      {/* recent-airport quick buttons */}
      {mode !== 'temp' && recent && recent.length > 0 && (
        <div style={{ display: 'flex', gap: 4 }}>
          {recent.slice(0, 3).map((rc) => {
            const sel = code === rc;
            return (
              <button key={rc} onClick={() => onCode(rc)} style={{ flex: 1, minWidth: 0, cursor: 'pointer',
                background: sel ? C.primary : C.elevated, border: `1px solid ${sel ? C.primary : C.border}`,
                borderRadius: 7, padding: '5px 0', fontFamily: window.LF_MONO, fontSize: 10, fontWeight: 700,
                letterSpacing: '.5px', color: sel ? C.inverse : C.text2 }}>{rc}</button>
            );
          })}
        </div>
      )}
    </div>);

}

// stepper for landings
function Stepper({ label, value, onChange, icon }) {
  const C = window.LF_C;
  return (
    <div style={{ flex: 1, display: 'flex', flexDirection: 'column', gap: 6 }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 5 }}>
        {icon && <span style={{ color: C.text3, display: 'flex' }}><window.LFIcon name={icon} size={12} /></span>}
        {lfLabel(label)}</div>
      <div style={{ display: 'flex', alignItems: 'center', background: C.elevated, border: `1px solid ${C.border}`,
        borderRadius: 11, height: 44, overflow: 'hidden' }}>
        <button onClick={() => onChange(Math.max(0, value - 1))} style={{ width: 38, height: '100%', border: 'none',
          background: 'transparent', color: C.text2, cursor: 'pointer', display: 'grid', placeItems: 'center' }}><window.LFIcon name="minus" size={16} /></button>
        <span style={{ flex: 1, textAlign: 'center', fontFamily: window.LF_MONO, fontSize: 18, fontWeight: 800, color: C.text }}>{value}</span>
        <button onClick={() => onChange(value + 1)} style={{ width: 38, height: '100%', border: 'none',
          background: 'transparent', color: C.primary, cursor: 'pointer', display: 'grid', placeItems: 'center' }}><window.LFIcon name="plus" size={16} /></button>
      </div>
    </div>);

}

// compact inline counter for the TOL table — label + icon, − value +
function MiniStepper({ label, value, onChange, icon }) {
  const C = window.LF_C;
  return (
    <div style={{ flex: 1, display: 'flex', alignItems: 'center', gap: 4, background: C.elevated, border: `1px solid ${C.border}`,
      borderRadius: 9, height: 34, padding: '0 2px' }}>
      <span style={{ display: 'flex', alignItems: 'center', gap: 3, paddingLeft: 6, flex: '0 0 auto' }}>
        {icon && <span style={{ color: C.text3, display: 'flex' }}><window.LFIcon name={icon} size={11} /></span>}
        <span style={{ fontFamily: window.LF_MONO, fontSize: 9, fontWeight: 700, letterSpacing: '.4px', color: C.text3 }}>{label}</span>
      </span>
      <button onClick={() => onChange(Math.max(0, value - 1))} style={{ width: 24, height: '100%', border: 'none', marginLeft: 'auto',
        background: 'transparent', color: C.text2, cursor: 'pointer', display: 'grid', placeItems: 'center' }}><window.LFIcon name="minus" size={13} /></button>
      <span style={{ minWidth: 14, textAlign: 'center', fontFamily: window.LF_MONO, fontSize: 15, fontWeight: 800, color: value ? C.text : C.muted }}>{value}</span>
      <button onClick={() => onChange(value + 1)} style={{ width: 24, height: '100%', border: 'none',
        background: 'transparent', color: C.primary, cursor: 'pointer', display: 'grid', placeItems: 'center' }}><window.LFIcon name="plus" size={13} /></button>
    </div>);

}

// role grid (PIC/CO/FI/DUAL/PICUS + Special)
function RoleGrid({ value, onChange, onSpecial }) {
  const C = window.LF_C;
  const roles = [['pic', 'PIC'], ['co', 'CO-PILOT'], ['fi', 'INSTRUCTOR'], ['dual', 'DUAL'], ['picus', 'PICUS']];
  return (
    <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 7 }}>
      {roles.map(([v, l]) => {const sel = value === v;return (
          <button key={v} onClick={() => onChange(v)} style={{ padding: '10px 4px', borderRadius: 10, cursor: 'pointer',
            background: sel ? 'rgba(0,200,232,0.14)' : C.elevated, border: `1px solid ${sel ? C.primary : C.border}`,
            color: sel ? C.primary : C.text2, fontFamily: window.LF_MONO, fontSize: 10.5, fontWeight: 700, letterSpacing: '0.3px' }}>{l}</button>);})}
      <button onClick={onSpecial} style={{ padding: '10px 4px', borderRadius: 10, cursor: 'pointer',
        background: C.elevated, border: `1px dashed ${C.border}`, color: C.text3,
        fontFamily: window.LF_MONO, fontSize: 10.5, fontWeight: 700, display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 4 }}>
        <window.LFIcon name="star" size={11} />Special</button>
    </div>);

}

// condition time field with twilight auto-fill cue
function CondField({ label, value, onChange, auto, tint }) {
  const C = window.LF_C;const col = tint || C.night;
  return (
    <div style={{ flex: 1, minWidth: 0, display: 'flex', flexDirection: 'column', gap: 5 }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 5 }}>{lfLabel(label)}{auto && <AutoPill>twilight</AutoPill>}</div>
      <div style={{ display: 'flex', alignItems: 'center', gap: 6, background: C.elevated, border: `1px solid ${C.border}`,
        borderRadius: 10, height: 42, padding: '0 10px' }}>
        <input value={value} placeholder="0:00" inputMode="numeric"
        onChange={(e) => {let v = e.target.value.replace(/[^0-9]/g, '').slice(0, 4);if (v.length >= 2) v = v.slice(0, v.length - 2) + ':' + v.slice(-2);onChange(v);}}
        style={{ flex: 1, minWidth: 0, background: 'none', border: 'none', outline: 'none',
          color: auto ? col : C.text, fontFamily: window.LF_MONO, fontSize: 16, fontWeight: 800, width: '100%' }} />
        <span style={{ fontFamily: window.LF_MONO, fontSize: 9, color: C.muted }}>h</span>
      </div>
    </div>);

}

Object.assign(window, { lfCard, lfLabel, LFSection, AutoPill, Seg, TimeField, ICAOCol, Stepper, MiniStepper, RoleGrid, CondField });