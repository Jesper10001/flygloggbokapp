// Sun-route modal — sun relation along a flight, now on an ADVANCED, REACTIVE
// map that auto-zooms to the country/countries the route touches:
//   • domestic route  → zoom into that country + its neighbours
//   • international    → fit both countries with context
// Real lat/lon coastlines, graticule with degree labels, and country labels are
// projected through one dynamic bbox projection, so the sun/terminator
// astronomy (ported unchanged) lines up at any zoom.
const { useState: uS2, useEffect: uE2, useRef: uR2, useMemo: uM2 } = React;

// ── astronomy (compact, unchanged) ──
const DEG = Math.PI / 180;
function subsolar(date) {
  const start = Date.UTC(date.getUTCFullYear(), 0, 0);
  const doy = Math.floor((date - start) / 86400000);
  const decl = -23.44 * Math.cos(DEG * (360 / 365) * (doy + 10));
  const utcH = date.getUTCHours() + date.getUTCMinutes() / 60 + date.getUTCSeconds() / 3600;
  const lon = 180 - utcH * 15;
  return { lat: decl, lon: ((lon + 540) % 360) - 180 };
}
function altitude(lat, lon, sub) {
  const h = (lon - sub.lon) * DEG;
  return Math.asin(Math.sin(lat * DEG) * Math.sin(sub.lat * DEG) +
    Math.cos(lat * DEG) * Math.cos(sub.lat * DEG) * Math.cos(h)) / DEG;
}
function sunState(alt) { return alt > -0.833 ? 'day' : alt > -12 ? 'dusk' : 'night'; }
const SUN_COL = { day: '#F5C84B', dusk: '#F2914A', night: '#7FC4FF', dawn: '#F291C8' };

// ── geography (coarse lat/lon outlines, [lon,lat]) ──
const LANDS = [
  { name: 'NORWAY', c: [9, 62.5], p: [[4.9,58.1],[5.2,59.3],[4.9,61],[7,62.8],[9.5,63.8],[12,65.5],[14,67],[16.5,68.6],[20,70],[25.5,71.1],[29,70.6],[30.8,69.8],[27,69.6],[24,68.8],[20.5,69],[18,68],[16.5,66],[14.5,64.5],[12.2,63],[12.6,61],[11.1,59.9],[11.2,58.9],[8,58.2],[4.9,58.1]] },
  { name: 'SWEDEN', c: [15, 62], p: [[11.2,58.9],[11.1,59.9],[12.6,61],[12.2,63],[14.5,64.5],[16.5,66],[18,68],[20.5,69],[23.2,68],[23.5,66.5],[21.5,65.5],[21,63.5],[18.5,62],[17.8,60.6],[18.8,59.5],[16.8,58.6],[16.5,57],[15,56.1],[12.9,55.4],[12.6,56.4],[11.5,57.7],[11.2,58.9]] },
  { name: 'FINLAND', c: [26, 64], p: [[21.5,65.5],[23.5,66.5],[24,68],[27,69.5],[29.5,68.5],[31.5,66],[30,64],[31.5,62.5],[28.5,61],[27.5,60.4],[24,60],[21.2,60.5],[21,62.5],[21.5,65.5]] },
  { name: 'DENMARK', c: [9.5, 56], p: [[8.1,55],[8.1,57.1],[10.6,57.7],[10.5,56.4],[12.7,56],[12.3,55],[10,54.8],[8.1,55]] },
  { name: 'UNITED KINGDOM', c: [-2, 53.4], p: [[-3,58.6],[-2,57.5],[-2.2,56],[-1.6,54.5],[0.4,53],[1.7,52.4],[1,51.3],[-1.5,50.6],[-5.7,50],[-4.2,51.7],[-5,53.3],[-4.5,54.8],[-5,55.9],[-3,58.6]] },
  { name: 'IRELAND', c: [-8, 53.3], p: [[-10,54.3],[-8,55.3],[-6,55.2],[-6,53.4],[-6.6,52.2],[-9.5,51.5],[-10.5,53.3],[-10,54.3]] },
  { name: '', c: null, p: [[-1.8,43.3],[-1.2,46],[-4.7,48],[-1,49.3],[2,51],[4.3,51.8],[7,53.6],[8.5,53.9],[9.8,54.4],[12.5,54.4],[14.3,53.9],[16.5,54.6],[18.6,54.4],[19.6,54.4],[21,56],[23,56.3],[24,57.8],[24.5,59.5],[28,59.4],[28,56],[27,54],[24,50.5],[22,48.5],[19,48],[16,48.2],[13.5,47.5],[10.5,47.3],[7.5,47.8],[6,46.2],[7,43.8],[3.3,43.3],[-1.8,43.3]] },
  { name: 'IBERIA', c: [-3.7, 40], p: [[-9.3,43],[-8.9,41],[-9.5,38.7],[-9,37],[-7.4,37.2],[-5.6,36],[-2.1,36.7],[0.6,38.8],[3.3,41.9],[3.3,42.5],[-1.8,43.3],[-9.3,43]] },
];
const LABELS = [
  ['FRANCE',2,47.3],['GERMANY',10.2,51],['POLAND',19.5,52],['NETHERLANDS',5.6,52.4],
  ['ESTONIA',25.5,58.7],['LATVIA',24.8,56.9],['LITHUANIA',24,55.3],['BELARUS',27.5,53.5],
];

const COUNTRY = { ES:'Sweden', EN:'Norway', EF:'Finland', EK:'Denmark', EG:'United Kingdom',
  EI:'Ireland', ED:'Germany', ET:'Germany', EH:'Netherlands', EB:'Belgium', EP:'Poland',
  EE:'Estonia', EV:'Latvia', EY:'Lithuania', LF:'France', LE:'Spain', LP:'Portugal',
  LI:'Italy', LO:'Austria', LS:'Switzerland', BI:'Iceland', ET2:'' };
const countryOf = (icao) => COUNTRY[(icao || '').slice(0, 2).toUpperCase()] || 'Unknown';

function SunRouteModal({ onClose, dep, arr, off, on, dateStr }) {
  const C = window.LF_C;
  const W = 720, H = 360;
  const A = { lat: dep?.lat ?? 59.65, lon: dep?.lon ?? 17.93, icao: dep?.icao || 'ESSA' };
  const B = { lat: arr?.lat ?? 58.41, lon: arr?.lon ?? 15.52, icao: arr?.icao || 'ESCF' };
  const cA = countryOf(A.icao), cB = countryOf(B.icao);
  const domestic = cA === cB && cA !== 'Unknown';

  // ── reactive bbox projection — zoom to the route, padded by route type ──
  const proj = uM2(() => {
    const lat0 = Math.min(A.lat, B.lat), lat1 = Math.max(A.lat, B.lat);
    const lon0 = Math.min(A.lon, B.lon), lon1 = Math.max(A.lon, B.lon);
    const dLat = lat1 - lat0, dLon = lon1 - lon0;
    const padLon = dLon * 0.5 + (domestic ? 4.2 : 2.4);
    const padLat = dLat * 0.5 + (domestic ? 3.2 : 1.8);
    const midLat = (lat0 + lat1) / 2, kx = Math.cos(midLat * DEG);
    // world units (x = lon*kx, y = -lat so north is up)
    let wx0 = (lon0 - padLon) * kx, wx1 = (lon1 + padLon) * kx;
    let wy0 = -(lat1 + padLat), wy1 = -(lat0 - padLat);
    let ex = wx1 - wx0, ey = wy1 - wy0; const R = W / H;
    if (ex / ey < R) { const ne = ey * R, d = (ne - ex) / 2; wx0 -= d; wx1 += d; }
    else { const ne = ex / R, d = (ne - ey) / 2; wy0 -= d; wy1 += d; }
    return {
      kx, wx0, wx1, wy0, wy1,
      X: (lon) => ((lon * kx - wx0) / (wx1 - wx0)) * W,
      Y: (lat) => ((-lat - wy0) / (wy1 - wy0)) * H,
      lonSpan: (wx1 - wx0) / kx,
    };
  }, [A.lat, A.lon, B.lat, B.lon, domestic]);
  const PX = proj.X, PY = proj.Y;

  const toMin = (s) => { const m = (s || '').match(/^(\d{1,2}):(\d{2})$/); return m ? +m[1] * 60 + +m[2] : null; };
  const offM = toMin(off) ?? 17 * 60, onM0 = toMin(on) ?? 4 * 60;
  const dur = (onM0 - offM + 1440) % 1440 || 660;
  const baseDate = dateStr ? new Date(dateStr + 'T00:00:00Z') : new Date(Date.UTC(2026, 11, 12));

  const [frac, setFrac] = uS2(0);
  const [playing, setPlaying] = uS2(true);
  const trackRef = uR2(null);
  uE2(() => { setFrac(0); setPlaying(true); }, []);
  uE2(() => {
    if (!playing) return;
    const id = setInterval(() => setFrac(f => { const n = f + 0.01; if (n >= 1) { setPlaying(false); return 1; } return n; }), 70);
    return () => clearInterval(id);
  }, [playing]);

  const timeAt = (fr) => new Date(baseDate.getTime() + (offM + fr * dur) * 60000);
  const posAt = (fr) => ({ lat: A.lat + (B.lat - A.lat) * fr, lon: A.lon + (B.lon - A.lon) * fr });
  const now = timeAt(frac), sub = subsolar(now), plane = posAt(frac);
  const planeAlt = altitude(plane.lat, plane.lon, sub), planeState = sunState(planeAlt);

  // terminator across the visible band (sample by screen-x, invert to lon)
  const termPath = uM2(() => {
    const pts = [];
    for (let x = -30; x <= W + 30; x += 6) {
      const lon = (proj.wx0 + (x / W) * (proj.wx1 - proj.wx0)) / proj.kx;
      const h = (lon - sub.lon) * DEG;
      const lat = Math.atan(-Math.cos(h) / Math.tan(sub.lat * DEG)) / DEG;
      pts.push([x, PY(lat)]);
    }
    return pts;
  }, [sub.lon, sub.lat, proj]);
  const nightFill = uM2(() => {
    const top = sub.lat >= 0 ? `-30,${H}` : `-30,0`;
    const end = sub.lat >= 0 ? `${W + 30},${H}` : `${W + 30},0`;
    return `${top} ` + termPath.map(p => `${p[0].toFixed(1)},${p[1].toFixed(1)}`).join(' ') + ` ${end}`;
  }, [termPath, sub.lat]);

  const segs = uM2(() => {
    const out = []; const N = 48;
    for (let k = 0; k < N; k++) {
      const fr = k / (N - 1), p = posAt(fr), tt = timeAt(fr);
      out.push({ x: PX(p.lon), y: PY(p.lat), st: sunState(altitude(p.lat, p.lon, subsolar(tt))) });
    }
    return out;
  }, [proj, offM, dur]);

  const onScrub = (e) => {
    const el = trackRef.current; if (!el) return;
    const r = el.getBoundingClientRect();
    const x = (e.touches ? e.touches[0].clientX : e.clientX) - r.left;
    setPlaying(false); setFrac(Math.max(0, Math.min(1, x / r.width)));
  };
  const fmtT = (d) => `${String(d.getUTCHours()).padStart(2,'0')}:${String(d.getUTCMinutes()).padStart(2,'0')}`;
  const stateLbl = { day: 'Daylight', dusk: 'Twilight', dawn: 'Twilight', night: 'Night' };

  // graticule step adapts to zoom
  const gStep = proj.lonSpan > 40 ? 10 : proj.lonSpan > 18 ? 5 : 2;
  const grat = uM2(() => {
    const vLat0 = -proj.wy1, vLat1 = -proj.wy0;
    const vLon0 = proj.wx0 / proj.kx, vLon1 = proj.wx1 / proj.kx;
    const la = [], lo = [];
    for (let l = Math.ceil(vLat0 / gStep) * gStep; l <= vLat1; l += gStep) la.push(l);
    for (let l = Math.ceil(vLon0 / gStep) * gStep; l <= vLon1; l += gStep) lo.push(l);
    return { la, lo };
  }, [proj, gStep]);
  const inView = (lon, lat) => { const x = PX(lon), y = PY(lat); return x > 6 && x < W - 6 && y > 12 && y < H - 8; };
  const labelSize = Math.max(9, Math.min(19, 560 / proj.lonSpan));

  return (
    <div onClick={onClose} style={{position:'absolute',inset:0,zIndex:60,background:'rgba(3,8,16,0.86)',
      backdropFilter:'blur(3px)',display:'flex',alignItems:'center',justifyContent:'center',padding:14}}>
      <div onClick={e=>e.stopPropagation()} style={{width:'100%',maxWidth:360,background:C.card,
        border:`1px solid ${C.border}`,borderRadius:18,overflow:'hidden',boxShadow:'0 30px 80px rgba(0,0,0,.6)'}}>
        {/* header */}
        <div style={{display:'flex',alignItems:'center',gap:8,padding:'13px 14px',borderBottom:`1px solid ${C.sep}`}}>
          <span style={{color:C.gold,display:'flex'}}><window.LFIcon name="sun" size={16}/></span>
          <div style={{flex:1,minWidth:0}}>
            <div style={{fontFamily:window.LF_SANS,fontSize:14,fontWeight:700,color:C.text,lineHeight:1.1}}>Sun route</div>
            <div style={{fontFamily:window.LF_MONO,fontSize:9,fontWeight:700,color:domestic?C.success:C.gold,letterSpacing:'.4px',marginTop:2,textTransform:'uppercase',whiteSpace:'nowrap',overflow:'hidden',textOverflow:'ellipsis'}}>
              {domestic ? `Domestic · ${cA}` : `${cA} → ${cB}`}</div>
          </div>
          <span style={{fontFamily:window.LF_MONO,fontSize:11,fontWeight:700,color:C.text3}}>{A.icao} → {B.icao}</span>
          <button onClick={onClose} style={{marginLeft:6,width:26,height:26,borderRadius:8,background:C.elevated,
            border:`1px solid ${C.border}`,color:C.text2,cursor:'pointer',display:'grid',placeItems:'center'}}>
            <window.LFIcon name="close" size={13}/></button>
        </div>

        {/* map */}
        <div style={{position:'relative',background:'#0A1A2E'}}>
          {/* BASE: sea + graticule + landmasses + country labels */}
          <svg width="100%" viewBox={`0 0 ${W} ${H}`} style={{display:'block'}}>
            <defs>
              <linearGradient id="srSea" x1="0" x2="0" y1="0" y2="1">
                <stop offset="0%" stopColor="#10365C"/><stop offset="100%" stopColor="#0A2138"/>
              </linearGradient>
            </defs>
            <rect x="0" y="0" width={W} height={H} fill="url(#srSea)"/>
            {/* graticule */}
            <g stroke="rgba(255,255,255,0.07)" strokeWidth="1">
              {grat.la.map(l=><line key={'a'+l} x1="0" y1={PY(l)} x2={W} y2={PY(l)}/>)}
              {grat.lo.map(l=><line key={'o'+l} x1={PX(l)} y1="0" x2={PX(l)} y2={H}/>)}
            </g>
            <g fill="rgba(150,180,200,0.35)" fontFamily={window.LF_MONO} fontSize="8">
              {grat.la.map(l=> (PY(l)>10&&PY(l)<H-2) ? <text key={'la'+l} x="3" y={PY(l)-2}>{Math.abs(Math.round(l))}°{l<0?'S':'N'}</text> : null)}
              {grat.lo.map(l=> (PX(l)>10&&PX(l)<W-18) ? <text key={'lo'+l} x={PX(l)+2} y={H-3}>{Math.abs(Math.round(l))}°{l<0?'W':'E'}</text> : null)}
            </g>
            {/* landmasses */}
            <g fill="rgba(58,110,80,0.55)" stroke="rgba(120,190,150,0.45)" strokeWidth="1">
              {LANDS.map((L,i)=>(
                <polygon key={i} points={L.p.map(([lo,la])=>`${PX(lo).toFixed(1)},${PY(la).toFixed(1)}`).join(' ')}/>
              ))}
            </g>
            {/* country labels */}
            <g fontFamily={window.LF_MONO} fontWeight="800" fill="rgba(210,230,225,0.62)" textAnchor="middle"
               style={{letterSpacing:'1px',textTransform:'uppercase'}}>
              {LANDS.filter(L=>L.name&&L.c&&inView(L.c[0],L.c[1])).map((L,i)=>(
                <text key={'n'+i} x={PX(L.c[0])} y={PY(L.c[1])} fontSize={labelSize}>{L.name}</text>
              ))}
              {LABELS.filter(([,lo,la])=>inView(lo,la)).map(([n,lo,la],i)=>(
                <text key={'x'+i} x={PX(lo)} y={PY(la)} fontSize={labelSize*0.82}>{n}</text>
              ))}
            </g>
          </svg>

          {/* OVERLAY: transparent sun / terminator / route / plane */}
          <svg width="100%" viewBox={`0 0 ${W} ${H}`} style={{display:'block',position:'absolute',inset:0,pointerEvents:'none'}}>
            <polygon points={nightFill} fill="rgba(4,9,20,0.55)"/>
            <polyline points={termPath.map(p=>`${p[0].toFixed(1)},${p[1].toFixed(1)}`).join(' ')}
              fill="none" stroke="rgba(127,196,255,0.6)" strokeWidth="1.4" strokeDasharray="4 4"/>
            <g transform={`translate(${PX(sub.lon)},${PY(sub.lat)})`}>
              <circle r="20" fill="#F5C84B" opacity="0.16"/><circle r="7" fill="#F5C84B"/>
            </g>
            {segs.slice(1).map((s,i)=>(
              <line key={i} x1={segs[i].x} y1={segs[i].y} x2={s.x} y2={s.y}
                stroke={SUN_COL[s.st]} strokeWidth="3.4" strokeLinecap="round"/>
            ))}
            {[A,B].map((p,i)=>(
              <g key={i} transform={`translate(${PX(p.lon)},${PY(p.lat)})`}>
                <circle r="5" fill={i?C.gold:C.success} stroke="#fff" strokeWidth="1.5"/>
                <text x="0" y="-9" textAnchor="middle" fontFamily={window.LF_MONO} fontSize="11" fontWeight="800"
                  fill="#fff" style={{paintOrder:'stroke',stroke:'#0A1A2E',strokeWidth:3}}>{p.icao}</text>
              </g>
            ))}
            <g transform={`translate(${PX(plane.lon)},${PY(plane.lat)}) rotate(45)`}>
              <rect x="-6" y="-6" width="12" height="12" rx="2" fill="#3FE0FF" stroke="#06101F" strokeWidth="1.5"/>
            </g>
          </svg>
        </div>

        {/* scrubber */}
        <div style={{padding:'12px 14px'}}>
          <div style={{display:'flex',alignItems:'center',gap:9}}>
            <button onClick={()=>{ if(frac>=0.999) setFrac(0); setPlaying(p=>!p); }} style={{width:28,height:28,borderRadius:14,
              border:`1px solid ${C.gold}`,background:C.gold+'1F',color:C.gold,cursor:'pointer',display:'grid',placeItems:'center'}}>
              <window.LFIcon name={playing?'pause':(frac>=0.999?'refresh':'play')} size={13}/></button>
            <span style={{fontFamily:window.LF_MONO,fontSize:10,fontWeight:700,color:C.text2}}>{off||'17:00'}</span>
            <div ref={trackRef} onPointerDown={e=>{e.target.setPointerCapture?.(e.pointerId);onScrub(e);}}
              onPointerMove={e=>{if(e.buttons)onScrub(e);}}
              style={{flex:1,height:24,position:'relative',cursor:'pointer',display:'flex',alignItems:'center'}}>
              <div style={{height:6,borderRadius:3,overflow:'hidden',display:'flex',width:'100%',background:C.border}}>
                {segs.slice(1).map((s,i)=><div key={i} style={{flex:1,background:SUN_COL[s.st]}}/>)}
              </div>
              <div style={{position:'absolute',left:`calc(${(frac*100).toFixed(1)}% - 7px)`,width:14,height:14,borderRadius:7,
                background:C.gold,border:'2px solid #fff',pointerEvents:'none'}}/>
            </div>
            <span style={{fontFamily:window.LF_MONO,fontSize:10,fontWeight:700,color:C.text2}}>{on||'04:00'}</span>
          </div>
          <div style={{display:'flex',alignItems:'center',justifyContent:'space-between',marginTop:11}}>
            <span style={{fontFamily:window.LF_MONO,fontSize:13,fontWeight:800,color:C.text}}>{fmtT(now)} UTC</span>
            <span style={{display:'inline-flex',alignItems:'center',gap:5,padding:'3px 9px',borderRadius:8,
              background:SUN_COL[planeState]+'22',border:`1px solid ${SUN_COL[planeState]}`}}>
              <span style={{width:7,height:7,borderRadius:4,background:SUN_COL[planeState]}}/>
              <span style={{fontFamily:window.LF_MONO,fontSize:10,fontWeight:800,color:SUN_COL[planeState]}}>{stateLbl[planeState]}</span>
            </span>
          </div>
          <div style={{display:'flex',justifyContent:'center',gap:16,marginTop:11}}>
            {[['day','Day'],['dusk','Twilight'],['night','Night']].map(([k,l])=>(
              <span key={k} style={{display:'inline-flex',alignItems:'center',gap:5}}>
                <span style={{width:10,height:3,borderRadius:2,background:SUN_COL[k]}}/>
                <span style={{fontFamily:window.LF_MONO,fontSize:9,fontWeight:700,color:C.muted}}>{l}</span>
              </span>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
window.LF_SunRouteModal = SunRouteModal;
