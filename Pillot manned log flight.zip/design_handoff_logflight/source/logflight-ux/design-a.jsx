// Design A — smart single-scroll with a Quicklog ↔ Full toggle.
// Quicklog = essentials only (route, times, aircraft, role, landings, save).
// Full = every section. Every existing function preserved.
const { useState: uA } = React;

// add-stop builder — ICAO place + stop-kind (git model, no approach/runway here)
function StopBuilder({ kinds, onAdd }) {
  const C = window.LF_C;
  const [icao, setIcao] = uA('');
  const [kind, setKind] = uA(kinds[0]?.k || 'tng');
  const [foc, setFoc] = uA(false);
  React.useEffect(() => {if (!kinds.find((x) => x.k === kind)) setKind(kinds[0]?.k || 'tng');}, [kinds.map((x) => x.k).join()]);
  const add = () => {const ic = icao.trim().toUpperCase();if (ic.length < 2) return;onAdd({ icao: ic, kind });setIcao('');};
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
      <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap' }}>
        {kinds.map((x) => {const s = kind === x.k;return (
            <button key={x.k} onClick={() => setKind(x.k)} style={{ ...{ border: `1px solid ${s ? C.primary : C.border}`, cursor: 'pointer',
                background: s ? C.primary : C.elevated, color: s ? C.inverse : C.text3, borderRadius: 8, padding: '5px 11px',
                fontFamily: window.LF_MONO, fontSize: 10.5, fontWeight: 700, letterSpacing: '.3px' }, fontFamily: "\"Geist Mono\"" }}>{x.l}</button>);})}
      </div>
      <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
        <div style={{ flex: 1, display: 'flex', alignItems: 'center', gap: 6, background: C.elevated,
          border: `1.5px solid ${foc ? C.primary : C.border}`, borderRadius: 10, height: 42, padding: '0 11px', transition: 'border-color .15s', fontSize: "15px" }}>
          <span style={{ color: C.text3, display: 'flex' }}><window.LFIcon name="pin" size={14} /></span>
          <input value={icao} placeholder="ICAO place" onFocus={() => setFoc(true)} onBlur={() => setFoc(false)}
          onChange={(e) => setIcao(e.target.value.toUpperCase().slice(0, 4))}
          style={{ flex: 1, minWidth: 0, background: 'none', border: 'none', outline: 'none', color: C.text,
            fontFamily: window.LF_MONO, fontSize: 15, fontWeight: 800, letterSpacing: '1px', width: '100%' }} />
        </div>
        <button onClick={add} style={{ flexShrink: 0, border: 'none', cursor: 'pointer', background: icao.trim().length >= 2 ? C.primary : C.elevated,
          color: icao.trim().length >= 2 ? C.inverse : C.muted, borderRadius: 10, height: 42, padding: '0 16px',
          fontFamily: window.LF_MONO, fontSize: 12, fontWeight: 800, letterSpacing: '.4px' }}>Add</button>
      </div>
    </div>);

}

function ModeToggle({ mode, onChange }) {
  const C = window.LF_C;
  return (
    <div style={{ position: 'relative', display: 'flex', background: C.elevated, border: `1px solid ${C.border}`, borderRadius: 8, padding: 2 }}>
      <div style={{ position: 'absolute', top: 2, bottom: 2, left: 2, width: 'calc((100% - 4px) / 2)',
        transform: `translateX(${mode === 'full' ? '100%' : '0'})`, transition: 'transform .22s cubic-bezier(.4,1.3,.5,1)',
        background: C.primary, borderRadius: 6, boxShadow: `0 0 10px ${C.primary}55` }} />
      {[['quick', 'Quicklog'], ['full', 'Full']].map(([v, l]) => {const sel = mode === v;return (
          <div key={v} onClick={() => onChange(v)} style={{ flex: 1, position: 'relative', zIndex: 1, cursor: 'pointer', textAlign: 'center', whiteSpace: 'nowrap',
            color: sel ? C.inverse : C.text3, transition: 'color .2s', padding: '5px 11px',
            fontFamily: window.LF_SANS, fontSize: 9.5, fontWeight: 700, letterSpacing: '.2px' }}>{l}</div>);})}
    </div>);

}

// thin day/night route strip — shades the leg that falls after dusk (auto from twilight)
function DayNightStrip({ off, on, nightFrac = 0.0 }) {
  const C = window.LF_C;
  return (
    <div style={{ marginTop: 12, paddingTop: 12, borderTop: `1px solid ${C.sep}` }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 6, marginBottom: 6 }}>
        {window.lfLabel('Day / night')}<window.AutoPill>twilight</window.AutoPill>
      </div>
      <div style={{ position: 'relative', height: 10, borderRadius: 6, overflow: 'hidden',
        background: `linear-gradient(90deg, ${C.success}44 0%, ${C.success}44 ${(1 - nightFrac) * 100}%, ${C.night}66 ${(1 - nightFrac) * 100}%, ${C.night}88 100%)`,
        border: `1px solid ${C.border}` }}>
        {nightFrac > 0 && <div style={{ position: 'absolute', top: 0, bottom: 0, left: `${(1 - nightFrac) * 100}%`, width: 1, background: C.night }} />}
      </div>
      <div style={{ display: 'flex', justifyContent: 'space-between', marginTop: 4, fontFamily: window.LF_MONO, fontSize: 8.5, color: C.muted }}>
        <span>{off}</span><span style={{ color: nightFrac > 0 ? C.night : C.success }}>{nightFrac > 0 ? 'dusk on route' : 'all daylight'}</span><span>{on}</span>
      </div>
    </div>);

}

// draggable percentage bar for a flight-condition profile (VFR/IFR/NVG).
// drag anywhere on the track to set what share of the flight was flown in it.
function CondBar({ label, pct, onPct, tint, totalMin, readOnly, auto, warnAbove, extraSnaps, notches }) {
  const C = window.LF_C;const ref = React.useRef(null);
  const mins = Math.round(totalMin * pct / 100);
  const hm = `${Math.floor(mins / 60)}:${String(mins % 60).padStart(2, '0')}`;
  const snap = (raw) => {
    if (!totalMin) return Math.round(raw);
    const stepPct = 5 / totalMin * 100; // 5-minute increments
    let best = Math.round(raw / stepPct) * stepPct;
    [50, 100, ...(extraSnaps || [])].forEach((e) => {if (Math.abs(raw - e) < Math.abs(raw - best)) best = e;});
    return Math.max(0, Math.min(100, best));
  };
  const fromX = (clientX) => {const el = ref.current;if (!el) return;const r = el.getBoundingClientRect();
    onPct(snap((clientX - r.left) / r.width * 100));};
  const down = (e) => {if (readOnly) return;e.preventDefault();fromX(e.clientX);
    const mv = (ev) => fromX(ev.clientX);const up = () => {window.removeEventListener('pointermove', mv);window.removeEventListener('pointerup', up);};
    window.addEventListener('pointermove', mv);window.addEventListener('pointerup', up);};
  return (
    <div style={{ marginBottom: 11 }}>
      <div style={{ display: 'flex', alignItems: 'center', marginBottom: 5 }}>
        <span style={{ flex: 1, display: 'flex', alignItems: 'center', gap: 6 }}>{window.lfLabel(label)}{auto && <window.AutoPill>twilight</window.AutoPill>}</span>
        <span style={{ fontFamily: window.LF_MONO, fontSize: 11, fontWeight: 800, color: tint }}>{hm}</span>
        <span style={{ fontFamily: window.LF_MONO, fontSize: 9, color: C.muted, marginLeft: 6, width: 30, textAlign: 'right' }}>{Math.round(pct)}%</span>
      </div>
      <div ref={ref} onPointerDown={down} style={{ position: 'relative', height: 14, borderRadius: 8, cursor: readOnly ? 'default' : 'pointer',
        background: C.elevated, border: `1px solid ${C.border}`, overflow: 'hidden', touchAction: 'none', opacity: readOnly ? .92 : 1 }}>
        <div style={{ position: 'absolute', top: 0, bottom: 0, left: 0, width: `${Math.min(pct, warnAbove || 100)}%`, background: tint, opacity: .5 }} />
        {warnAbove && pct > warnAbove && <div style={{ position: 'absolute', top: 0, bottom: 0, left: `${warnAbove}%`, width: `${pct - warnAbove}%`, background: C.danger, opacity: .7 }} />}
        {(notches || []).map((n, i) => <div key={i} style={{ position: 'absolute', top: 1, bottom: 1, left: `${n}%`, width: 2, marginLeft: -1,
          background: C.text, opacity: .45, borderRadius: 1, pointerEvents: 'none' }} />)}
        {!readOnly && <div style={{ position: 'absolute', top: -2, bottom: -2, left: `calc(${pct}% - 5px)`, width: 10, borderRadius: 4,
          background: warnAbove && pct > warnAbove ? C.danger : tint, boxShadow: `0 0 6px ${warnAbove && pct > warnAbove ? C.danger : tint}` }} />}
      </div>
    </div>);

}

// segmented twilight bar — day/dusk/night/dawn across the flight, night time centred over its segment.
function TwilightBar({ segs, night, pct, nvgPct = 0 }) {
  const C = window.LF_C;
  // night segment center + valid NVG window (dusk+night+dawn) boundaries
  let acc = 0,nightL = 50,nightW = 0,validL = 0,validR = 100;
  segs.forEach((s) => {
    if (s.k === 'dusk') {validL = acc;}
    if (s.k === 'night') {nightL = acc + s.f / 2;nightW = s.f;}
    if (s.k === 'dawn') {validR = acc + s.f;}
    acc += s.f;
  });
  return (
    <div style={{ marginBottom: 11 }}>
      <div style={{ position: 'relative', height: 15, marginBottom: 3 }}>
        {night && night !== '0:00' && <span style={{ position: 'absolute', left: `${nightL}%`, transform: 'translateX(-50%)',
          fontFamily: window.LF_MONO, fontSize: 11, fontWeight: 800, color: C.night, whiteSpace: 'nowrap' }}>{night}</span>}
      </div>
      <div style={{ position: 'relative', display: 'flex', height: 14, borderRadius: 8, overflow: 'hidden', border: `1px solid ${C.border}` }}>
        {segs.map((s, i) => <div key={i} style={{ ...{ width: `${s.f}%`, background: s.c, opacity: s.k === 'night' ? .85 : .4 }, opacity: "0.9" }} />)}
        {/* NVG glow — expands from night centre; once a side hits the window edge it grows only the other way; past the window it warns red */}
        {nvgPct > 0 && (() => {
          const half = nvgPct / 2;
          let wl = nightL - half,wr = nightL + half;
          if (wl < validL) {wr += validL - wl;wl = validL;}
          if (wr > validR) {wl -= wr - validR;wr = validR;}
          wl = Math.max(validL, wl);wr = Math.min(validR, wr);
          const excess = Math.max(0, nvgPct - (wr - wl));
          const redR = Math.min(excess, 100 - validR),redL = Math.max(0, excess - redR);
          return <>
            <div style={{ position: 'absolute', top: 0, bottom: 0, left: `${wl}%`, width: `${wr - wl}%`, pointerEvents: 'none',
              background: 'rgba(255,255,255,0.55)', boxShadow: '0 0 10px rgba(255,255,255,0.7)', mixBlendMode: 'screen' }} />
            {redR > 0 && <div style={{ position: 'absolute', top: 0, bottom: 0, left: `${validR}%`, width: `${redR}%`, pointerEvents: 'none',
              background: 'rgba(255,77,106,0.7)', boxShadow: `0 0 10px ${C.danger}` }} />}
            {redL > 0 && <div style={{ position: 'absolute', top: 0, bottom: 0, left: `${validL - redL}%`, width: `${redL}%`, pointerEvents: 'none',
              background: 'rgba(255,77,106,0.7)', boxShadow: `0 0 10px ${C.danger}` }} />}
          </>;
        })()}
      </div>
      <div style={{ display: 'flex', marginTop: 3 }}>
        {segs.map((s, i) => <span key={i} style={{ width: `${s.f}%`, textAlign: 'center', fontFamily: window.LF_MONO,
          fontSize: 7, fontWeight: 700, letterSpacing: '.3px', color: s.k === 'night' ? C.night : C.muted, textTransform: 'uppercase',
          overflow: 'hidden', whiteSpace: 'nowrap' }}>{s.f >= 8 ? s.k : ''}</span>)}
      </div>
    </div>);

}

// Per-ICAO approach builder — picks 2D/3D → type → runway, building a remark
// string like "ESSA ILS 26". Ghost prompt appears after each ICAO when IFR.
const LF_APP = { '2d': ['VOR', 'NDB', 'LOC'], '3d': ['ILS', 'RNAV', 'GLS'] };
const LF_RWY = { ESSA: ['01L', '19R', '08', '26'], ESCF: ['11', '29'], ESGG: ['03', '21'], EGLL: ['09L', '27R'],
  EKCH: ['04L', '22R'], EDDF: ['07C', '25C'], LFPG: ['08R', '26L'], ESSB: ['12', '30'], ESNZ: ['12', '30'] };
function ApproachFlow({ icaos, ifr, value, onChange }) {
  const C = window.LF_C;
  const upd = (icao, patch) => onChange({ ...value, [icao]: { ...(value[icao] || {}), ...patch } });
  const Opt = ({ on, onClick, children }) =>
  <button onClick={onClick} style={{ background: on ? 'rgba(0,200,232,0.16)' : C.elevated,
    border: `1px solid ${on ? C.primary : C.border}`, borderRadius: 7, padding: '5px 9px', cursor: 'pointer',
    fontFamily: window.LF_MONO, fontSize: 10, fontWeight: 700, color: on ? C.primary : C.text3 }}>{children}</button>;
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 9 }}>
      {icaos.map((icao) => {
        const v = value[icao] || {};
        return (
          <div key={icao} style={{ background: C.elevated, border: `1px solid ${C.border}`, borderRadius: 11, padding: '9px 11px' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 8, flexWrap: 'wrap' }}>
              <span style={{ fontFamily: window.LF_MONO, fontSize: 14, fontWeight: 800, color: C.text, letterSpacing: '.5px' }}>{icao}</span>
              {v.app && <span style={{ fontFamily: window.LF_MONO, fontSize: 13, fontWeight: 700, color: C.primary }}>{v.app}{v.rwy ? ` ${v.rwy}` : ''}</span>}
              {/* ghost prompt — semi-transparent, outlined — only when IFR & not started */}
              {ifr && !v.dim && <span style={{ fontFamily: window.LF_MONO, fontSize: 11, fontWeight: 700, letterSpacing: '.4px',
                color: 'rgba(255,255,255,0.28)', WebkitTextStroke: `0.5px ${C.text2}` }}>+ approach</span>}
              {v.dim && <span onClick={() => onChange({ ...value, [icao]: {} })} style={{ marginLeft: 'auto', cursor: 'pointer',
                fontFamily: window.LF_MONO, fontSize: 10, color: C.muted }}>reset</span>}
            </div>
            {/* step 1 — 2D / 3D */}
            {ifr && !v.dim &&
            <div style={{ display: 'flex', gap: 6, marginTop: 8 }}>
                <Opt onClick={() => upd(icao, { dim: '2d' })}>2D approach</Opt>
                <Opt onClick={() => upd(icao, { dim: '3d' })}>3D approach</Opt>
              </div>
            }
            {/* step 2 — approach type */}
            {v.dim && !v.app &&
            <div style={{ display: 'flex', gap: 6, marginTop: 8 }}>
                {LF_APP[v.dim].map((a) => <Opt key={a} onClick={() => upd(icao, { app: a })}>{a}</Opt>)}
              </div>
            }
            {/* step 3 — runway */}
            {v.app && !v.rwy &&
            <div style={{ display: 'flex', gap: 6, marginTop: 8, flexWrap: 'wrap' }}>
                <span style={{ fontFamily: window.LF_MONO, fontSize: 9, color: C.muted, alignSelf: 'center' }}>RWY</span>
                {(LF_RWY[icao] || ['—']).map((r) => <Opt key={r} onClick={() => upd(icao, { rwy: r })}>{r}</Opt>)}
              </div>
            }
          </div>);

      })}
    </div>);

}

function DesignA({ initialMode = 'full' }) {
  const C = window.LF_C;
  const [f, setF] = uA({ ...window.LF_DEMO });
  const [appx, setAppx] = uA({});
  const [mode, setMode] = uA(initialMode);
  const [sim, setSim] = uA(false);
  const [sunOpen, setSunOpen] = uA(false);
  const [dateOpen, setDateOpen] = uA(false);
  const [cond, setCond] = uA({ ifr: 100, vfr: 0, nvg: 0, night: 0 }); // % of flight per profile
  const set = (k, v) => setF((s) => ({ ...s, [k]: v }));
  // IFR + VFR are complementary — you must fly one, never both; they always sum to 100.
  const setC = (k, v) => setCond((s) => {
    if (k === 'ifr') return { ...s, ifr: v, vfr: 100 - v };
    if (k === 'vfr') return { ...s, vfr: v, ifr: 100 - v };
    return { ...s, [k]: v };
  });
  const total = window.autoTotal(f.off, f.on) || f.total;
  const totalMin = (() => {const m = (total || '').match(/^(\d+):(\d{2})$/);return m ? +m[1] * 60 + +m[2] : 0;})();
  const nightMin = (() => {const m = (f.night || '').match(/^(\d+):(\d{2})$/);return m ? +m[1] * 60 + +m[2] : 0;})();
  const nightPct = totalMin ? Math.round(nightMin / totalMin * 100) : 0;
  const dateLabel = (() => { const s = f.date.toLocaleDateString('en-US', { weekday: 'long', day: 'numeric', month: 'long' }); return s.charAt(0).toUpperCase() + s.slice(1); })();
  const full = mode === 'full';
  const zSuffix = f.timeMode === 'utc' ? 'z' : 'L';

  return (
    <div style={{ position: 'absolute', inset: 0, background: C.bg, fontFamily: window.LF_SANS, display: 'flex', flexDirection: 'column' }}>
      {/* header: close · date · scan */}
      <div style={{ flexShrink: 0, paddingTop: 48, paddingBottom: 10, background: C.surface,
        borderBottom: `.5px solid ${C.sep}`, display: 'grid', gridTemplateColumns: '40px 1fr 40px', alignItems: 'center', zIndex: 5 }}>
        <div style={{ justifySelf: 'center', color: C.text2, display: 'flex' }}><window.LFIcon name="close" size={20} /></div>
        <div style={{ textAlign: 'center', cursor: 'pointer' }} onClick={() => setDateOpen(true)}>
          <div style={{ fontFamily: window.LF_SERIF, fontSize: 19, fontWeight: 600, color: C.text, letterSpacing: '-.3px', textTransform: 'capitalize' }}>{dateLabel}</div>
          <div style={{ fontFamily: window.LF_MONO, fontSize: 8, fontWeight: 700, letterSpacing: '1px', color: C.primary, textTransform: 'uppercase', marginTop: 1 }}>Tap to change</div>
        </div>
        <div style={{ justifySelf: 'center', width: 30, height: 30, borderRadius: 9, background: 'rgba(0,200,232,0.14)',
          border: `1px solid ${C.primary}55`, color: C.primary, display: 'grid', placeItems: 'center' }}><window.LFIcon name="scan" size={16} /></div>
      </div>

      {/* mode toggle bar */}
      <div style={{ flexShrink: 0, display: 'flex', alignItems: 'center', gap: 8, padding: '8px 14px', background: C.surface, borderBottom: `.5px solid ${C.sep}` }}>
        <ModeToggle mode={mode} onChange={setMode} />
        <span style={{ flex: 1 }} />
        <div style={{ position: 'relative', display: 'flex', background: C.elevated, border: `1px solid ${C.border}`, borderRadius: 8, padding: 2 }}>
          <div style={{ position: 'absolute', top: 2, bottom: 2, left: 2, width: 'calc((100% - 4px) / 2)',
            transform: `translateX(${sim ? '100%' : '0'})`, transition: 'transform .22s cubic-bezier(.4,1.3,.5,1), background .2s',
            background: sim ? C.gold : C.primary, borderRadius: 6, boxShadow: `0 0 10px ${sim ? C.gold : C.primary}55` }} />
          {[['real', 'Real flight'], ['sim', 'Sim']].map(([v, l]) => {const s = v === 'sim' === sim;return (
              <div key={v} onClick={() => setSim(v === 'sim')} style={{ flex: 1, position: 'relative', zIndex: 1, cursor: 'pointer', textAlign: 'center', whiteSpace: 'nowrap',
                color: s ? C.inverse : C.text3, transition: 'color .2s', padding: '5px 11px',
                fontFamily: window.LF_SANS, fontSize: 9.5, fontWeight: 700 }}>{l}</div>);})}
        </div>
      </div>

      <div style={{ flex: 1, overflowY: 'auto', padding: '14px 14px 84px' }}>
        {/* reverse-last quick bar */}
        <div style={{ display: 'flex', alignItems: 'center', gap: 10, background: 'rgba(0,200,232,0.09)',
          border: '1px solid rgba(0,200,232,0.28)', borderRadius: 12, padding: '9px 11px', marginBottom: 14, cursor: 'pointer' }}>
          <span style={{ color: C.primary, display: 'flex' }}><window.LFIcon name="swap" size={16} /></span>
          <div style={{ flex: 1, minWidth: 0 }}>
            <div style={{ fontFamily: window.LF_MONO, fontSize: 8, fontWeight: 700, letterSpacing: '1.2px', color: C.primary, textTransform: 'uppercase' }}>Reverse last flight</div>
            <div style={{ fontFamily: window.LF_MONO, fontSize: 12, fontWeight: 700, color: C.text, marginTop: 1 }}>EGLL → ESSA · A320 SE-MJZ</div>
          </div>
          <window.LFIcon name="chevRight" size={15} />
        </div>

        {/* ROUTE — two columns, the centrepiece */}
        <div style={{ ...window.lfCard(), padding: 14, marginBottom: 12 }}>
          {/* sim-type chooser — only when Sim is selected */}
          {sim && (() => {
            const cats = ['FFS', 'FTD', 'FNPT_II', 'FNPT_I', 'BITD', 'CPT_PPT', 'CBT'];
            const noCredit = f.simCat === 'CPT_PPT' || f.simCat === 'CBT';
            return (
              <div style={{ marginBottom: 12 }}>
                <div style={{ marginBottom: 6 }}>{window.lfLabel('Simulator type')}</div>
                <div style={{ display: 'flex', flexWrap: 'wrap', gap: 6 }}>
                  {cats.map((cat) => {const a = (f.simCat || 'FFS') === cat;return (
                      <div key={cat} onClick={() => set('simCat', cat)} style={{ cursor: 'pointer', padding: '5px 10px', borderRadius: 7,
                        background: a ? C.primary : C.elevated, border: `1px solid ${a ? C.primary : C.border}`,
                        color: a ? C.inverse : C.text3, fontFamily: window.LF_MONO, fontSize: 11, fontWeight: 700, letterSpacing: '.3px' }}>
                        {cat.replace(/_/g, '/')}</div>);})}
                </div>
                {noCredit && <div style={{ marginTop: 7, display: 'flex', alignItems: 'center', gap: 6, color: C.warning,
                  fontFamily: window.LF_SANS, fontSize: 10.5, fontWeight: 600 }}>
                  <span style={{ fontWeight: 800 }}>!</span> Does not count toward licence/rating credit.</div>}
              </div>);
          })()}
          {/* Departure / Arrival as two synced legs, each: ICAO over its block time */}
          <div style={{ display: 'flex', alignItems: 'stretch', gap: 0, position: 'relative', margin: '0 -14px' }}>
            <div style={{ flex: 1, display: 'flex', flexDirection: 'column', gap: 10,
              background: 'rgba(0,200,232,0.05)', borderTop: `1px solid ${C.sep}`, borderBottom: `1px solid ${C.sep}`, borderRight: `1px solid ${C.sep}`,
              borderRadius: '0 12px 12px 0', padding: '10px 12px 11px' }}>
              <window.ICAOCol legLabel="Departure" icon="depart" filled code={f.dep} mode={f.depMode}
              onCode={(v) => set('dep', v)} onMode={(v) => set('depMode', v)} recent={window.LF_RECENT_DEP} />
              <window.TimeField label="Off block" value={f.off} onChange={(v) => set('off', v)}
              zone={f.offZone || 'z'} onZone={(v) => set('offZone', v)} tzAbbr="CEST" offH={2} />
            </div>

            {/* center connector — ties the two legs together */}
            <div style={{ width: 30, flexShrink: 0, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'space-between', padding: '1px 1px' }}>
              {(() => {const flag = (ic) => ({ ES: '🇸🇪', EK: '🇩🇰', EG: '🇬🇧', ED: '🇩🇪', EH: '🇳🇱', EN: '🇳🇴', EF: '🇫🇮', LF: '🇫🇷', LE: '🇪🇸', LO: '🇦🇹', LS: '🇨🇭' })[(ic || '').slice(0, 2).toUpperCase()] || '🏳️';
                return <>
                <span style={{ fontSize: 18, lineHeight: 1 }}>{flag(f.dep)}</span>
                <div style={{ flex: 1, width: 1.5, background: `repeating-linear-gradient(180deg,${C.primary} 0 3px,transparent 3px 7px)`, opacity: .4, minHeight: 10 }} />
                <img src={`logflight-ux/${window.LF_isHeli(f.aircraftType) ? 'heli-cyan' : 'plane-cyan'}.png`} alt="" style={{ width: 32, height: 32, objectFit: 'contain', transform: 'rotate(180deg)', flexShrink: 0,
                    filter: `drop-shadow(0 0 4px ${C.primary}88)` }} />
                <div style={{ flex: 1, width: 1.5, background: `repeating-linear-gradient(180deg,${C.primary} 0 3px,transparent 3px 7px)`, opacity: .4, minHeight: 10 }} />
                <span style={{ fontSize: 18, lineHeight: 1 }}>{flag(f.arr)}</span>
              </>;})()}
            </div>

            <div style={{ flex: 1, display: 'flex', flexDirection: 'column', gap: 10,
              background: 'rgba(0,200,232,0.05)', borderTop: `1px solid ${C.sep}`, borderBottom: `1px solid ${C.sep}`, borderLeft: `1px solid ${C.sep}`,
              borderRadius: '12px 0 0 12px', padding: '10px 12px 11px' }}>
              <window.ICAOCol legLabel="Arrival" icon="arrive" filled={!!f.arr} code={f.arr} mode={f.arrMode}
              onCode={(v) => set('arr', v)} onMode={(v) => set('arrMode', v)} recent={window.LF_RECENT_ARR} />
              <window.TimeField label="On block" value={f.on} onChange={(v) => set('on', v)}
              zone={f.onZone || 'z'} onZone={(v) => set('onZone', v)} tzAbbr="CEST" offH={2} />
            </div>
          </div>
          {/* ── TOTAL BLOCK TIME — hero, with a refined day/night globe accent ── */}
          {(() => {
            const isNight = f.night && f.night !== '0:00';
            const np = Math.max(0, Math.min(100, nightPct)) / 100;
            const lit = 1 - np;
            const GS = 45;
            return (
              <div style={{ position: 'relative', marginTop: 8, minHeight: GS + 26, paddingTop: 6,
                display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center' }}>
                {/* left: distance + stops/app trigger — stacked */}
                <div style={{ position: 'absolute', left: 0, top: 26,
                  display: 'flex', flexDirection: 'column', alignItems: 'flex-start', gap: "8px", margin: "-3px", borderStyle: "solid", borderRadius: "0px", borderWidth: "0px", padding: "1px" }}>
                  {!sim && <div style={{ display: 'flex', alignItems: 'center', gap: 7 }}>
                  <span style={{ color: C.primary, display: 'flex', opacity: .9 }}><window.LFIcon name="distance" size={15} /></span>
                  <div style={{ display: 'flex', flexDirection: 'column', lineHeight: 1 }}>
                    <span style={{ fontFamily: 'var(--lf-led14)', fontWeight: 800 }}>
                      <span style={{ fontSize: 21, color: '#FFFFFF' }}>352</span>
                      <span style={{ fontSize: 10, color: C.primary, marginLeft: 3, fontFamily: window.LF_MONO }}>NM</span>
                    </span>
                    <span style={{ fontFamily: window.LF_MONO, fontSize: 7.5, fontWeight: 800, letterSpacing: '1.6px',
                        color: C.text3, textTransform: 'uppercase', marginTop: 4 }}>Distance</span>
                  </div>
                  </div>}
                  {false && full && !sim && (() => {const sc = (f.stops || []).length;return (
                      <div onClick={() => set('_stopsOpen', !f._stopsOpen)} style={{ display: 'flex', alignItems: 'center', gap: 5, cursor: 'pointer',
                        background: C.elevated, border: `1px solid ${C.border}`, borderRadius: 7, padding: '4px 8px' }}>
                    <span style={{ fontFamily: window.LF_MONO, fontSize: 8.5, fontWeight: 800, letterSpacing: '.8px', textTransform: 'uppercase', color: C.text2 }}>Stops/App</span>
                    {sc > 0 && <span style={{ fontFamily: window.LF_MONO, fontSize: 8.5, fontWeight: 800, color: C.inverse, background: C.primary, borderRadius: 5, padding: '0 5px' }}>{sc}</span>}
                    <span style={{ display: 'flex', color: C.text3, transform: f._stopsOpen ? 'rotate(180deg)' : 'none', transition: 'transform .15s' }}><window.LFIcon name="chevDown" size={13} /></span>
                  </div>);})()}
                </div>
                {/* center: total flight time (time on top, label below) — centred under arrival flag */}
                <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center',
                  padding: '8px 14px', borderRadius: 14, border: `1px solid ${C.gold}55`,
                  background: `linear-gradient(180deg, ${C.gold}0F, transparent)`,
                  boxShadow: `0 0 14px -6px ${C.gold}88, inset 0 0 12px -8px ${C.gold}` }}>
                <span style={{ fontFamily: 'var(--lf-serif)', fontWeight: 600, letterSpacing: '0px', lineHeight: 1,
                  ...(total ? {
                    color: '#FFFFFF',
                    filter: `drop-shadow(0 0 5px ${C.gold}88)`
                  } : { color: C.muted }), fontSize: "22px", color: "rgb(255, 255, 255)" }}>{total || '--:--'}</span>
                <span style={{ marginTop: 4, fontFamily: window.LF_MONO, fontWeight: 800, letterSpacing: '1.4px',
                  color: C.text3, textTransform: 'uppercase', fontSize: "10px" }}>Total flight time</span>
                <span style={{ display: 'inline-flex', alignItems: 'center', gap: 4, marginTop: 5, fontSize: "8px" }}>
                  <span style={{ width: 4, height: 4, borderRadius: '50%', background: isNight ? C.night : C.gold }} />
                  <span style={{ fontFamily: window.LF_MONO, fontSize: 8, fontWeight: 700, letterSpacing: '.5px',
                    color: C.text3, textTransform: 'uppercase' }}>{isNight ? 'Night flight' : 'Day flight'}</span>
                </span>
                </div>
                {/* right: refined globe (hidden for sim) */}
                {!sim && <button title="Open sun route" onClick={() => setSunOpen(true)} style={{ position: 'absolute', right: 0, top: 0,
                  background: 'none', border: 'none', cursor: 'pointer', padding: 0, display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 6 }}>
                  <div style={{ position: 'relative', width: GS + 12, height: GS + 12, display: 'grid', placeItems: 'center' }}>
                    <svg width={GS + 12} height={GS + 12} viewBox="0 0 100 100" style={{ position: 'absolute', inset: 0 }}>
                      <circle cx="50" cy="50" r="48" fill="none" stroke={C.sep} strokeWidth="1.2" />
                      <circle cx="50" cy="50" r="48" fill="none" stroke={isNight ? C.night : C.gold} strokeWidth="1.8"
                      strokeDasharray={`${lit * 301.6} 301.6`} strokeLinecap="round" transform="rotate(-90 50 50)"
                      style={{ filter: `drop-shadow(0 0 4px ${isNight ? C.night : C.gold}88)` }} />
                    </svg>
                    <svg width={GS} height={GS} viewBox="0 0 100 100" style={{ display: 'block' }}>
                      <defs>
                        <radialGradient id="lfDigi" cx="36%" cy="30%" r="78%">
                          <stop offset="0%" stopColor="#16324F" /><stop offset="60%" stopColor="#0E2238" /><stop offset="100%" stopColor="#091726" />
                        </radialGradient>
                        <radialGradient id="lfSphere" cx="34%" cy="28%" r="78%">
                          <stop offset="0%" stopColor="#00C8E8" stopOpacity=".22" /><stop offset="45%" stopColor="#00C8E8" stopOpacity="0" />
                          <stop offset="100%" stopColor="#000" stopOpacity=".45" />
                        </radialGradient>
                        <clipPath id="lfGlobe"><circle cx="50" cy="50" r="47" /></clipPath>
                        <linearGradient id="lfNight" x1="0" x2="1">
                          <stop offset={`${lit * 100}%`} stopColor="#060C1C" stopOpacity="0" />
                          <stop offset={`${Math.min(100, lit * 100 + 5)}%`} stopColor="#060C1C" stopOpacity=".72" />
                          <stop offset="100%" stopColor="#03070F" stopOpacity=".85" />
                        </linearGradient>
                      </defs>
                      <g clipPath="url(#lfGlobe)">
                        <circle cx="50" cy="50" r="47" fill="url(#lfDigi)" />
                        {/* grid system — latitudes + longitudes in cyan/grey */}
                        <g fill="none" stroke="#00C8E8" strokeOpacity=".55" strokeWidth=".7">
                          <line x1="3" y1="50" x2="97" y2="50" />
                          <ellipse cx="50" cy="50" rx="47" ry="14" />
                          <ellipse cx="50" cy="50" rx="47" ry="31" />
                        </g>
                        <g fill="none" stroke="#5A7FA0" strokeOpacity=".45" strokeWidth=".6">
                          <line x1="50" y1="3" x2="50" y2="97" />
                          <ellipse cx="50" cy="50" rx="16" ry="47" />
                          <ellipse cx="50" cy="50" rx="33" ry="47" />
                        </g>
                        {/* node dots at a couple of intersections */}
                        <g fill="#00C8E8">
                          <circle cx="50" cy="19" r="1.3" /><circle cx="50" cy="81" r="1.3" />
                          <circle cx="33" cy="36" r="1" fillOpacity=".7" /><circle cx="67" cy="64" r="1" fillOpacity=".7" />
                        </g>
                        <circle cx="50" cy="50" r="47" fill="url(#lfSphere)" />
                        {/* night side */}
                        <rect x="0" y="0" width="100" height="100" fill="url(#lfNight)" />
                        {/* rim */}
                        <circle cx="50" cy="50" r="47" fill="none" stroke="#00C8E8" strokeOpacity=".35" strokeWidth="1" />
                      </g>
                    </svg>
                  </div>
                  <span style={{ display: 'flex', alignItems: 'center', gap: 3, fontFamily: window.LF_MONO, fontSize: 7.5, fontWeight: 700,
                    letterSpacing: '.4px', color: C.text3, textTransform: 'uppercase' }}>
                    <window.LFIcon name="tap" size={10} />Sun route</span>
                </button>}
              </div>);

          })()}
          {/* night / twilight breakdown — between globe row and stops/via (hidden for sim) */}
          {!sim && <div style={{ marginTop: 13 }}>
            <TwilightBar night={f.night} pct={nightPct} nvgPct={cond.nvg} segs={[
            { k: 'day', f: 45.5, c: C.success }, { k: 'dusk', f: 9, c: C.gold },
            { k: 'night', f: 31.8, c: C.night }, { k: 'dawn', f: 9, c: C.gold }, { k: 'day', f: 4.5, c: C.success }]
            } />
          </div>}
          {/* Stops/App trigger — bottom-left, beside the bar */}
          {full && !sim && (() => {const sc = (f.stops || []).length;return (
              <div onClick={() => set('_stopsOpen', !f._stopsOpen)} style={{ display: 'inline-flex', alignItems: 'center', gap: 5, cursor: 'pointer', marginTop: 11,
                background: C.elevated, border: `1px solid ${C.border}`, borderRadius: 7, padding: '4px 8px' }}>
                <span style={{ fontFamily: window.LF_MONO, fontSize: 8.5, fontWeight: 800, letterSpacing: '.8px', textTransform: 'uppercase', color: C.text2 }}>Stops/App</span>
                {sc > 0 && <span style={{ fontFamily: window.LF_MONO, fontSize: 8.5, fontWeight: 800, color: C.inverse, background: C.primary, borderRadius: 5, padding: '0 5px' }}>{sc}</span>}
                <span style={{ display: 'flex', color: C.text3, transform: f._stopsOpen ? 'rotate(180deg)' : 'none', transition: 'transform .15s' }}><window.LFIcon name="chevDown" size={13} /></span>
              </div>);})()}
          {/* route stops (via / touch & go) — under the globe, git stop-kind + place model */}
          {full && (() => {
            const rule = cond.ifr >= 100 ? 'IFR' : cond.vfr >= 100 ? 'VFR' : 'YZ';
            // kinds react to rule: IFR uses approaches downstream so Touch&go is VFR/YZ only
            const KINDS = [
            { k: 'tng', l: 'Touch & go', rules: ['VFR', 'YZ'] },
            { k: 'lowapp', l: 'Low approach', rules: ['VFR', 'YZ', 'IFR'] },
            { k: 'pickup', l: 'Pickup', rules: ['VFR', 'YZ', 'IFR'] },
            { k: 'dropoff', l: 'Drop off', rules: ['VFR', 'YZ', 'IFR'] },
            { k: 'refuel', l: 'Hot refuel', rules: ['VFR', 'YZ', 'IFR'] }].
            filter((x) => x.rules.includes(rule));
            const TOK = { tng: 'TnG', lowapp: 'LA', pickup: 'PU', dropoff: 'DO', refuel: 'HR' };
            const stops = f.stops || [];
            const setStops = (v) => set('stops', v);
            const open = !!f._stopsOpen;
            return (
              <div style={{ marginTop: open || stops.length ? 13 : 0 }}>
                {/* existing stops */}
                {open && stops.length > 0 &&
                <div style={{ display: 'flex', flexDirection: 'column', gap: 6, marginBottom: 8 }}>
                    {stops.map((s, i) =>
                  <div key={i} style={{ display: 'flex', alignItems: 'center', gap: 8, background: C.elevated,
                    border: `1px solid ${C.border}`, borderRadius: 10, padding: '7px 10px' }}>
                        <span style={{ fontFamily: window.LF_MONO, fontSize: 13, fontWeight: 800, color: C.text, letterSpacing: '.4px' }}>{s.icao}</span>
                        <span style={{ fontFamily: window.LF_MONO, fontSize: 9, fontWeight: 800, letterSpacing: '.4px', color: C.inverse,
                      background: C.primary, borderRadius: 5, padding: '2px 6px' }}>{TOK[s.kind]}</span>
                        <span style={{ flex: 1, fontFamily: window.LF_MONO, fontSize: 10, color: C.text3 }}>{KINDS.concat([{ k: 'tng', l: 'Touch & go' }, { k: 'lowapp', l: 'Low approach' }, { k: 'pickup', l: 'Pickup' }, { k: 'dropoff', l: 'Drop off' }, { k: 'refuel', l: 'Hot refuel' }]).find((x) => x.k === s.kind)?.l}</span>
                        <span onClick={() => setStops(stops.filter((_, j) => j !== i))} style={{ cursor: 'pointer', color: C.muted, fontFamily: window.LF_MONO, fontSize: 14 }}>×</span>
                      </div>
                  )}
                  </div>
                }
                {/* add-stop builder: ICAO place + kind */}
                {open && <StopBuilder kinds={KINDS} onAdd={(s) => setStops([...stops, s])} />}
              </div>);

          })()}
        </div>

        {/* ── VFR / Y·Z / IFR — full-width horizontal toggle (both modes) ── */}
        <div style={{ padding: '0 4px', marginBottom: 12 }}>
          {(() => {
            const active = cond.ifr >= 100 ? 'IFR' : cond.vfr >= 100 ? 'VFR' : 'YZ';
            const idx = active === 'VFR' ? 0 : active === 'YZ' ? 1 : 2;
            const tint = active === 'VFR' ? C.success : active === 'IFR' ? C.primary : C.gold;
            const pick = (r) => {if (r === 'IFR') setCond((s) => ({ ...s, ifr: 100, vfr: 0 }));else if (r === 'VFR') setCond((s) => ({ ...s, ifr: 0, vfr: 100 }));else setCond((s) => ({ ...s, ifr: 50, vfr: 50 }));};
            // quicklog: VFR / IFR only · full: VFR / Y·Z / IFR
            const items = full ? [['VFR', 'VFR'], ['YZ', 'Y·Z'], ['IFR', 'IFR']] : [['VFR', 'VFR'], ['IFR', 'IFR']];
            const qActive = active === 'YZ' ? 'IFR' : active;
            const qIdx = qActive === 'VFR' ? 0 : 1;
            const useIdx = full ? idx : qIdx;
            return (
              <div style={{ position: 'relative', display: 'flex', width: '100%', background: C.card, borderRadius: 11, padding: 3 }}>
                <div style={{ position: 'absolute', top: 3, bottom: 3, left: 3, width: `calc((100% - 6px) / ${items.length})`,
                  transform: `translateX(${useIdx * 100}%)`, transition: 'transform .22s cubic-bezier(.4,1.3,.5,1), background .2s',
                  background: full ? tint : (qActive === 'VFR' ? C.success : C.primary), borderRadius: 8, boxShadow: `0 0 12px ${tint}66` }} />
                {items.map(([k, l]) => {const s = (full ? active : qActive) === k;return (
                    <div key={k} onClick={() => pick(k)} style={{ position: 'relative', zIndex: 1, flex: 1, textAlign: 'center',
                      padding: '8px 0', cursor: 'pointer', fontFamily: window.LF_MONO, fontSize: 12, fontWeight: 700,
                      letterSpacing: '.5px', color: s ? C.inverse : C.text3, transition: 'color .2s' }}>{l}</div>);})}
              </div>);
          })()}
        </div>

        {/* ── Flight-condition bars — floating below the top card ── */}
        {full &&
        <div style={{ padding: '0 4px', marginBottom: 18 }}>
            <CondBar label="VFR" pct={cond.vfr} onPct={(v) => setC('vfr', v)} tint={C.success} totalMin={totalMin} />
            <CondBar label="IFR" pct={cond.ifr} onPct={(v) => setC('ifr', v)} tint={C.primary} totalMin={totalMin} />
            {sim && <CondBar label="Night" pct={cond.night} onPct={(v) => setCond((s) => ({ ...s, night: v }))} tint={C.night} totalMin={totalMin} />}
            {(sim ? cond.night > 0 : nightPct > 0) && (sim
              ? <CondBar label="NVG" pct={cond.nvg} onPct={(v) => setC('nvg', v)} tint={C.violet} totalMin={totalMin} />
              : <CondBar label="NVG" pct={cond.nvg} onPct={(v) => setC('nvg', v)} tint={C.violet} totalMin={totalMin} warnAbove={49.8}
          extraSnaps={[31.8, 49.8]} notches={[31.8, 49.8]} />)}
          </div>
        }

        {/* AIRCRAFT + role */}
        <div style={{ ...window.lfCard(), padding: 14, marginBottom: 12 }}>
          <div style={{ display: 'flex', gap: 10 }}>
            <div style={{ flex: 1.1 }}>
              <div style={{ marginBottom: 5 }}>{window.lfLabel('Aircraft type')}</div>
              <div style={{ display: 'flex', alignItems: 'center', background: C.elevated, border: `1px solid ${C.border}`,
                borderRadius: 10, height: 44, padding: '0 11px' }}>
                <span style={{ fontFamily: window.LF_MONO, fontSize: 16, fontWeight: 800, color: C.text }}>{f.aircraftType}</span>
                <span style={{ flex: 1 }} /><window.LFIcon name="chevDown" size={14} /></div>
            </div>
            <div style={{ flex: 1 }}>
              <div style={{ marginBottom: 5 }}>{window.lfLabel('Registration')}</div>
              <div style={{ display: 'flex', alignItems: 'center', background: C.elevated, border: `1px solid ${C.border}`,
                borderRadius: 10, height: 44, padding: '0 11px' }}>
                <span style={{ fontFamily: window.LF_MONO, fontSize: 14, fontWeight: 700, color: C.text2 }}>{f.reg}</span>
                <span style={{ flex: 1 }} /><window.LFIcon name="chevDown" size={14} /></div>
            </div>
          </div>
          {/* your role */}
          <div style={{ marginTop: 13, marginBottom: 8 }}>{window.lfLabel('Your role')}</div>
          <window.RoleGrid value={f.role} onChange={(v) => set('role', v)} onSpecial={() => {}} />
          {/* second pilot + additional crew */}
          <window.LF_CrewEditor
            sp={{ role: f.role2, name: f.secondPilot }}
            onSp={(v) => {set('role2', v.role);set('secondPilot', v.name);}}
            crew={f.crew || []}
            onCrew={(v) => set('crew', v)} />
        </div>

        {/* TAKE-OFFS · APPROACHES · LANDINGS — floating, no card. Full only. */}
        {full && <div style={{ padding: '0 4px', marginBottom: 18 }}>
          {(() => {
            const Row = ({ label, a, b, first }) =>
            <div style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '7px 0', borderTop: first ? 'none' : `1px solid ${C.border}` }}>
                <span style={{ flex: '0 0 70px', fontFamily: window.LF_MONO, fontSize: 9.5, fontWeight: 700, letterSpacing: '.6px',
                textTransform: 'uppercase', color: C.text2 }}>{label}</span>
                <div style={{ flex: 1, display: 'flex', gap: 8 }}>
                  <window.MiniStepper {...a} />
                  <window.MiniStepper {...b} />
                </div>
              </div>;

            return (
              <div>
                <Row label="Take-offs" first
                a={{ label: 'Day', value: f.toDay, onChange: (v) => set('toDay', v) }}
                b={{ label: 'Night', value: f.toNight, onChange: (v) => set('toNight', v) }} />
                {cond.ifr > 0 && <Row label="Approaches"
                a={{ label: '2D', value: f.app2d, onChange: (v) => set('app2d', v) }}
                b={{ label: '3D', value: f.app3d, onChange: (v) => set('app3d', v) }} />}
                <Row label="Landings"
                a={{ label: 'Day', value: f.landDay, onChange: (v) => set('landDay', v) }}
                b={{ label: 'Night', value: f.landNight, onChange: (v) => set('landNight', v) }} />
                {/* Max altitude — rectangular barometer ticker */}
                {(() => {
                  const alt = parseInt(f.maxAlt, 10) || 0;
                  const MAXA = 45000;
                  const fill = Math.max(0, Math.min(1, alt / MAXA));
                  const step = (d) => set('maxAlt', String(Math.max(0, Math.round(alt / 500) * 500 + d * 500)));
                  const ticks = [0, 0.25, 0.5, 0.75, 1];
                  const fromX = (e, el) => {
                    const r = el.getBoundingClientRect();
                    const x = ((e.touches ? e.touches[0].clientX : e.clientX) - r.left) / r.width;
                    set('maxAlt', String(Math.max(0, Math.min(MAXA, Math.round(x * MAXA / 500) * 500))));
                  };
                  const onDown = (e) => {
                    const el = e.currentTarget;e.preventDefault();fromX(e, el);
                    const mv = (ev) => fromX(ev, el);
                    const up = () => {window.removeEventListener('pointermove', mv);window.removeEventListener('pointerup', up);};
                    window.addEventListener('pointermove', mv);window.addEventListener('pointerup', up);
                  };
                  return (
                    <div style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '9px 0', borderTop: `1px solid ${C.border}` }}>
                      <span style={{ flex: '0 0 70px', fontFamily: window.LF_MONO, fontSize: 9.5, fontWeight: 700, letterSpacing: '.6px',
                        textTransform: 'uppercase', color: C.text2 }}>Max alt</span>
                      <div style={{ flex: 1, display: 'flex', alignItems: 'center', gap: 10 }}>
                        {/* rectangular barometer column — drag left/right to set */}
                        <div onPointerDown={onDown} style={{ position: 'relative', flex: 1, height: 26, borderRadius: 6, overflow: 'hidden',
                          background: C.bg, border: `1px solid ${C.border}`, cursor: 'ew-resize', touchAction: 'none' }}>
                          <div style={{ position: 'absolute', left: 0, top: 0, bottom: 0, width: `${fill * 100}%`,
                            background: `linear-gradient(90deg, ${C.primary}55, ${C.primary})`,
                            boxShadow: `0 0 10px ${C.primary}66` }} />
                          {/* drag handle at the fill edge */}
                          <div style={{ position: 'absolute', top: 0, bottom: 0, left: `${fill * 100}%`, width: 2,
                            transform: 'translateX(-1px)', background: '#F4FAFF', boxShadow: `0 0 6px ${C.primary}` }} />
                          {/* graduation ticks */}
                          {ticks.map((t, i) => <div key={i} style={{ position: 'absolute', top: 3, bottom: 3, left: `${t * 100}%`,
                            width: 1, background: 'rgba(255,255,255,.16)', pointerEvents: 'none' }} />)}
                          <span style={{ position: 'absolute', right: 8, top: '50%', transform: 'translateY(-50%)', pointerEvents: 'none',
                            fontFamily: 'var(--lf-led7, ui-monospace)', fontSize: 14, fontWeight: 700, color: '#F4FAFF',
                            textShadow: '0 0 5px rgba(220,240,255,.4)' }}>{alt.toLocaleString()}<span style={{ fontSize: 8.5, color: C.text3, marginLeft: 3, fontFamily: window.LF_MONO }}>FT</span></span>
                        </div>
                        {/* +/- */}
                        <div style={{ display: 'flex', gap: 4 }}>
                          <button onClick={() => step(-1)} style={{ width: 28, height: 26, borderRadius: 6, cursor: 'pointer',
                            background: C.elevated, border: `1px solid ${C.border}`, color: C.text2, fontSize: 16, fontWeight: 700, lineHeight: 1 }}>−</button>
                          <button onClick={() => step(1)} style={{ width: 28, height: 26, borderRadius: 6, cursor: 'pointer',
                            background: C.elevated, border: `1px solid ${C.border}`, color: C.text2, fontSize: 16, fontWeight: 700, lineHeight: 1 }}>+</button>
                        </div>
                      </div>
                    </div>);

                })()}
              </div>);

          })()}
        </div>}

        {/* QUICKLOG — auto 1 take-off + 1 landing from day/night */}
        {!full && (() => {
          const C = window.LF_C;
          const toNight = nightMin > 0 && nightMin >= totalMin; // departs in night only if whole flight night
          const landNight = nightMin > 0; // lands at night if any night on the leg
          const Chip = ({ lbl, night }) =>
          <div style={{ flex: 1, display: 'flex', alignItems: 'center', gap: 8, background: C.elevated,
            border: `1px solid ${C.border}`, borderRadius: 10, padding: '9px 11px' }}>
              <span style={{ fontFamily: window.LF_MONO, fontSize: 18, fontWeight: 800, color: C.text }}>1</span>
              <div style={{ display: 'flex', flexDirection: 'column' }}>
                <span style={{ fontFamily: window.LF_MONO, fontSize: 9.5, fontWeight: 700, letterSpacing: '.5px',
                textTransform: 'uppercase', color: C.text2 }}>{lbl}</span>
                <span style={{ fontFamily: window.LF_MONO, fontSize: 9, fontWeight: 700, color: night ? C.night : C.success }}>{night ? 'Night' : 'Day'}</span>
              </div>
            </div>;

          return (
            <div style={{ padding: '0 4px', marginBottom: 18 }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 6, marginBottom: 8 }}>
                {window.lfLabel('Take-off / landing')}
                <window.AutoPill>auto</window.AutoPill>
              </div>
              <div style={{ display: 'flex', gap: 8 }}>
                <Chip lbl="Take-off" night={toNight} />
                <Chip lbl="Landing" night={landNight} />
              </div>
            </div>);

        })()}

        {full &&
        <div style={{ ...window.lfCard(), padding: 14 }}>
            {!sim && <window.LFSection icon="doc" title="Approach & notes" />}
            {!sim && <div style={{ marginBottom: 8 }}>{window.lfLabel('Training approaches')}</div>}
            {!sim && <ApproachFlow icaos={[...f.stops, f.arr].filter(Boolean)} ifr={cond.ifr > 0} value={appx} onChange={setAppx} />}
            {/* completed approaches land in remarks */}
            {!sim && (() => {const t = [...f.stops, f.arr].filter(Boolean).map((ic) => {const v = appx[ic] || {};
              return v.app ? `${ic} ${v.app}${v.rwy ? ' ' + v.rwy : ''}` : null;}).filter(Boolean).join(' · ');
            return t ? <div style={{ marginTop: 10, display: 'flex', alignItems: 'center', gap: 7, background: 'rgba(0,200,232,0.08)',
              border: `1px solid ${C.primary}55`, borderRadius: 9, padding: '8px 10px' }}>
                <span style={{ fontFamily: window.LF_MONO, fontSize: 8, fontWeight: 700, letterSpacing: '1px', color: C.primary, textTransform: 'uppercase' }}>In remarks</span>
                <span style={{ fontFamily: window.LF_MONO, fontSize: 12, fontWeight: 700, color: C.text }}>{t}</span></div> : null;})()}
            <textarea placeholder="Remarks &amp; endorsements…" value={f.remarks} onChange={(e) => set('remarks', e.target.value)}
          style={{ width: '100%', marginTop: sim ? 0 : 12, background: C.elevated, border: `1px solid ${C.border}`, borderRadius: 10,
            padding: '11px 12px', color: C.text, fontFamily: window.LF_SANS, fontSize: 13, outline: 'none', boxSizing: 'border-box',
            minHeight: sim ? 75 : 64, resize: 'vertical' }} />
            <button style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8, width: '100%', marginTop: 10,
            background: C.elevated, border: `1px dashed ${C.border}`, borderRadius: 10, padding: '11px', cursor: 'pointer',
            color: C.text3, fontFamily: window.LF_SANS, fontSize: 13, fontWeight: 600 }}>
              <window.LFIcon name="cam" size={16} />Add photo or video</button>
          </div>
        }

        {/* quicklog hint to reveal the rest */}
        {!full &&
        <button onClick={() => setMode('full')} style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 7,
          width: '100%', background: 'transparent', border: `1px dashed ${C.border}`, borderRadius: 12, padding: '12px', cursor: 'pointer',
          color: C.text3, fontFamily: window.LF_SANS, fontSize: 12.5, fontWeight: 600 }}>
            <window.LFIcon name="chevDown" size={15} />Conditions · approach · notes · media — open Full
          </button>
        }
      </div>

      {/* sun-route modal — opens from the globe tap */}
      {sunOpen && <window.LF_SunRouteModal onClose={() => setSunOpen(false)}
      dep={{ icao: f.dep, lat: 59.65, lon: 17.93 }} arr={{ icao: f.arr, lat: 58.41, lon: 15.52 }}
      off={f.off} on={f.on} dateStr={'2026-12-12'} />}

      {/* date picker bottom sheet — tap header to open (git: spinner sheet + Done, max = today) */}
      {dateOpen && (() => {
        const sel = f.date;
        const addDays = (d, n) => { const x = new Date(d); x.setDate(x.getDate() + n); return x; };
        const today = new Date('2026-06-29T12:00:00');
        const sameDay = (a, b) => a.toDateString() === b.toDateString();
        const monthStart = new Date(sel.getFullYear(), sel.getMonth(), 1);
        const startDow = (monthStart.getDay() + 6) % 7; // Mon=0
        const daysInMonth = new Date(sel.getFullYear(), sel.getMonth() + 1, 0).getDate();
        const cells = []; for (let i = 0; i < startDow; i++) cells.push(null);
        for (let d = 1; d <= daysInMonth; d++) cells.push(new Date(sel.getFullYear(), sel.getMonth(), d, 12));
        const shiftMonth = (n) => set('date', new Date(sel.getFullYear(), sel.getMonth() + n, Math.min(sel.getDate(), 28), 12));
        return (
          <div onClick={() => setDateOpen(false)} style={{ position: 'absolute', inset: 0, zIndex: 60,
            background: 'rgba(2,8,16,0.6)', display: 'flex', flexDirection: 'column', justifyContent: 'flex-end' }}>
            <div onClick={(e) => e.stopPropagation()} style={{ background: C.surface, borderTopLeftRadius: 18, borderTopRightRadius: 18,
              borderTop: `1px solid ${C.border}`, padding: '10px 16px 24px' }}>
              {/* sheet header: title + Done */}
              <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '4px 2px 12px' }}>
                <span style={{ fontFamily: window.LF_SERIF, fontSize: 16, fontWeight: 600, color: C.text }}>Flight date</span>
                <button onClick={() => setDateOpen(false)} style={{ background: 'none', border: 'none', cursor: 'pointer',
                  fontFamily: window.LF_SANS, fontSize: 15, fontWeight: 700, color: C.primary }}>Done</button>
              </div>
              {/* quick chips */}
              <div style={{ display: 'flex', gap: 7, marginBottom: 12 }}>
                {[['Today', 0], ['Yesterday', -1]].map(([lbl, n]) => { const d = addDays(today, n); const on = sameDay(d, sel); return (
                  <button key={lbl} onClick={() => set('date', d)} style={{ flex: 1, padding: '8px 0', borderRadius: 9, cursor: 'pointer',
                    background: on ? C.primary : C.elevated, border: `1px solid ${on ? C.primary : C.border}`,
                    color: on ? C.inverse : C.text2, fontFamily: window.LF_SANS, fontSize: 12, fontWeight: 700 }}>{lbl}</button>); })}
              </div>
              {/* month nav */}
              <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 8 }}>
                <button onClick={() => shiftMonth(-1)} style={{ width: 30, height: 30, borderRadius: 8, cursor: 'pointer',
                  background: C.elevated, border: `1px solid ${C.border}`, color: C.text2, display: 'grid', placeItems: 'center' }}><window.LFIcon name="chevLeft" size={15} /></button>
                <span style={{ fontFamily: window.LF_SANS, fontSize: 14, fontWeight: 700, color: C.text }}>
                  {sel.toLocaleDateString('en-US', { month: 'long', year: 'numeric' })}</span>
                <button onClick={() => shiftMonth(1)} style={{ width: 30, height: 30, borderRadius: 8, cursor: 'pointer',
                  background: C.elevated, border: `1px solid ${C.border}`, color: C.text2, display: 'grid', placeItems: 'center' }}><window.LFIcon name="chevRight" size={15} /></button>
              </div>
              {/* weekday row */}
              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(7,1fr)', gap: 4, marginBottom: 4 }}>
                {['M','T','W','T','F','S','S'].map((w, i) => <span key={i} style={{ textAlign: 'center', fontFamily: window.LF_MONO,
                  fontSize: 8.5, fontWeight: 700, color: C.text3 }}>{w}</span>)}
              </div>
              {/* day grid */}
              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(7,1fr)', gap: 4 }}>
                {cells.map((d, i) => {
                  if (!d) return <span key={i} />;
                  const on = sameDay(d, sel); const future = d > today;
                  return (
                    <button key={i} disabled={future} onClick={() => set('date', d)} style={{ aspectRatio: '1', borderRadius: 8,
                      cursor: future ? 'default' : 'pointer', border: `1px solid ${on ? C.primary : 'transparent'}`,
                      background: on ? C.primary : 'transparent', color: future ? C.sep : on ? C.inverse : C.text,
                      fontFamily: window.LF_MONO, fontSize: 12, fontWeight: on ? 800 : 600 }}>{d.getDate()}</button>
                  );
                })}
              </div>
            </div>
          </div>
        );
      })()}

      {/* sticky save */}
      <div style={{ position: 'absolute', left: 0, right: 0, bottom: 0, padding: '12px 16px 26px',
        background: `linear-gradient(180deg,transparent,${C.bg} 26%)` }}>
        <button style={{ width: '100%', padding: 15, borderRadius: 14, border: 'none', background: C.primary, color: C.inverse,
          cursor: 'pointer', fontFamily: window.LF_SANS, fontSize: 15, fontWeight: 800, letterSpacing: '-.1px',
          boxShadow: `0 14px 30px -14px ${C.primary}`, display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8 }}>
          <window.LFIcon name="check" size={17} />Save flight · {total || '--:--'}</button>
      </div>
    </div>);

}
window.DesignA = DesignA;