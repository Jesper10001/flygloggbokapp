// Log Flight redesign — Design A (smart single-scroll) with a Quicklog/Full
// mode toggle. Quicklog shows only the essentials; Full reveals every section.
// Every existing function is preserved.
function App(){
  return (
    <>
    <window.DesignCanvas>
      <window.DCSection id="logflight" title="Log Flight — redesign"
        subtitle="Design A · smart single-scroll. Toggle Quicklog (essentials only) ↔ Full (every field) in the header.">
        <window.DCArtboard id="a-full" label="A · Full" width={393} height={812}>
          <window.IOSDevice width={393} height={812} dark={true}><window.DesignA initialMode="full"/></window.IOSDevice>
        </window.DCArtboard>
        <window.DCArtboard id="a-quick" label="A · Quicklog" width={393} height={812}>
          <window.IOSDevice width={393} height={812} dark={true}><window.DesignA initialMode="quick"/></window.IOSDevice>
        </window.DCArtboard>
      </window.DCSection>
    </window.DesignCanvas>
    </>
  );
}
ReactDOM.createRoot(document.getElementById('root')).render(<App/>);
