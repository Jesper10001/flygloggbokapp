# Claude Code — add a real map under the Sun-route overlay

## Goal
The Sun-route view (`sunroute.jsx` → `SunRouteModal`, opened by tapping the
day/night globe in the Log-flight route card) currently draws everything in SVG.
It is now split into **two stacked layers**:

1. **BASE map layer** — a placeholder equirectangular world (gradient + graticule
   + simplified continent silhouettes).
2. **OVERLAY layer** — a fully transparent SVG on top (`position:absolute; inset:0;
   pointerEvents:none`) holding the **night fill, terminator, sun, coloured route,
   dep/arr pins and the animated plane**.

**Keep the overlay exactly as is. Replace ONLY the base layer with a real map.**

## How to implement the map (React Native / Expo app)
- Reuse the app's existing map component (the **Apple map** already used in
  `GlobalAirportMap` / `AirportMapWidget` — `react-native-maps`).
- Render it as the bottom layer of the modal's map area, same fixed aspect box
  the overlay uses (the prototype uses a 720×360 / 2:1 equirectangular frame —
  match that ratio so the overlay's lon/lat projection lines up).
- **Camera / framing:** fit the map region to the great-circle between
  `dep {lat,lon}` and `arr {lat,lon}` with padding, OR — to keep the
  terminator math trivial — render the map in a **flat equirectangular**
  projection covering the longitudes/latitudes the route spans. If you use
  Apple's native Mercator map, the overlay's terminator/route must be reprojected
  to screen coords from the map's current region (see "Projection" below).
- Style it dark/subdued (muted/!satellite, low-saturation) so the sun overlay
  reads clearly on top. A "muted standard" or custom dark style is ideal.
- Map gestures: **disable** scroll/zoom inside the modal so the time-scrubber and
  the route stay the focus (or allow pinch but recompute the overlay on region
  change — heavier; not required for v1).

## Projection — keeping the overlay aligned to the map
The overlay positions everything with:
```
projX(lon, W) = ((lon + 180) / 360) * W
projY(lat, H) = ((90 - lat) / 180) * H
```
i.e. **equirectangular**. Two options:

**A. Easiest — match the map to equirectangular.**
Crop/fit the base map so a known lon/lat window maps linearly to the box, then
feed the same window into `projX/projY` (replace the hard-coded ±180/±90 with the
window bounds). The terminator, route and sun then line up with no per-frame work.

**B. Native Mercator map (Apple).**
On every `onRegionChangeComplete`, convert each overlay point (terminator
vertices, route samples, sun subsolar point, dep/arr, plane) from lat/lon to
screen X/Y via the map's `pointForCoordinate` (or a Mercator formula matching the
region), and redraw the overlay SVG/Canvas with those screen coords. The
astronomy stays identical — only the projection function changes.

## What the overlay needs (already computed in `sunroute.jsx`)
- `subsolar(date)` → sun lat/lon; `altitude(lat,lon,sub)` → solar altitude;
  `sunState(alt)` → day/dusk/night. **Port these unchanged** — they drive the
  terminator polyline, the night polygon, the route colour, and the plane's
  current sun state. They are pure functions of UTC time + position.
- Inputs: `dep{icao,lat,lon}`, `arr{icao,lat,lon}`, `off`/`on` block times, and
  the flight date. The scrubber animates `frac` 0→1; `timeAt(frac)` and
  `posAt(frac)` interpolate UTC time and great-circle position.

## Acceptance
- Real map is visible beneath the sun overlay; terminator/route/pins/plane sit
  exactly over the correct geography.
- Tapping the globe still opens this view; the scrubber still works and recolours
  by sun state; closing returns to the form.
- Dark, low-distraction map styling; gestures don't fight the scrubber.
