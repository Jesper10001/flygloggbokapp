// BLADES — Log Flight redesign · shared foundation.
// Navy theme. Demo: A320 commercial IFR flight ESSA→EGLL.
// Field primitives are reused by both Design A and Design B.

const LF_C = {
  bg:'#0A1628', bgDeep:'#06101E', surface:'#0F1E3A', surface2:'#132845',
  elevated:'#152338', card:'#102441', border:'#1A3A5A', borderSoft:'#142B45', sep:'#122030',
  primary:'#00C8E8', gold:'#FFB830', success:'#00E8A0', night:'#5DA9FF', violet:'#9B8CFF', danger:'#FF4D6A',
  text:'#FFFFFF', text2:'#A8BFD6', text3:'#7FA8C8', muted:'#5A7FA0', faint:'#3A5A7A', inverse:'#04101F',
};
const LF_MONO = 'var(--lf-mono)';
const LF_SERIF = 'var(--lf-serif)';
const LF_SANS = 'var(--lf-sans)';

const LF_AIRPORTS = [
  {icao:'ESSA',name:'Stockholm Arlanda',city:'Stockholm, SE'},
  {icao:'ESGG',name:'Göteborg Landvetter',city:'Gothenburg, SE'},
  {icao:'ESSB',name:'Stockholm Bromma',city:'Stockholm, SE'},
  {icao:'EGLL',name:'London Heathrow',city:'London, GB'},
  {icao:'EKCH',name:'Copenhagen Kastrup',city:'Copenhagen, DK'},
  {icao:'EDDF',name:'Frankfurt am Main',city:'Frankfurt, DE'},
  {icao:'ENGM',name:'Oslo Gardermoen',city:'Oslo, NO'},
  {icao:'LFPG',name:'Paris Charles de Gaulle',city:'Paris, FR'},
  {icao:'ESCF',name:'Linköping / Malmen',city:'Linköping, SE'},
];
const cityOf = (icao) => (LF_AIRPORTS.find(a=>a.icao===icao)||{}).name || '';

// default demo form state — everything an A320 IFR leg needs
const LF_DEMO = {
  date: new Date(2026,5,21),
  aircraftType: 'AW139', reg: 'SE-JEX',
  secondPilot: 'M. Berg', role2: 'COP', crew: [],
  dep:'ESSA', depMode:'icao', off:'17:00',
  arr:'ESCF', arrMode:'icao', on:'04:00',
  total:'11:00',
  role:'pic',           // pic | co | fi | dual | picus
  rules:'IFR',          // IFR | VFR | Y | Z
  toDay:0, toNight:1, landDay:0, landNight:1,
  app2d:0, app3d:1,
  night:'3:30', nvg:'0:00', ifr:'2:42', vfr:'0:00',
  approach:'ILS', runway:'27R',
  flightType:'normal',  // normal | tng | sim
  remarks:'',
  timeMode:'utc',       // utc | local
  stops:[],             // intermediate touch&go / via airports
};

const LF_SAVED_TYPES = ['A320','A321','A319','DA40','C172'];
// helicopter type detection — used to pick the heli vs fixed-wing glyph
const LF_HELI_TYPES = ['AW139','AW169','EC135','EC145','H125','H145','R44','R66','B206','S76','AS350','EC120','B412'];
function LF_isHeli(t){ if(!t) return false; const u=(''+t).toUpperCase().replace(/[\s-]/g,''); return LF_HELI_TYPES.some(h=>u.includes(h)); }
const LF_RECENT_DEP = ['ESSA','EGLL','EDDF'];
const LF_RECENT_ARR = ['EGLL','EKCH','ENGM'];
const LF_REGS = { A320:['SE-MJZ','SE-RUA','SE-DOZ'], A321:['SE-RKA'], DA40:['SE-MBF'] };

// ── icons ──
const I = {fill:'none',stroke:'currentColor',strokeWidth:1.8,strokeLinecap:'round',strokeLinejoin:'round'};
function LFIcon({name,size=20}){
  const p={width:size,height:size,viewBox:'0 0 24 24'};
  switch(name){
    case 'close': return <svg {...p}><path {...I} d="M6 6l12 12M18 6 6 18"/></svg>;
    case 'scan': return <svg {...p}><path {...I} d="M4 8V5.5A1.5 1.5 0 0 1 5.5 4H8M16 4h2.5A1.5 1.5 0 0 1 20 5.5V8M20 16v2.5a1.5 1.5 0 0 1-1.5 1.5H16M8 20H5.5A1.5 1.5 0 0 1 4 18.5V16M4 12h16"/></svg>;
    case 'pin': return <svg {...p}><path {...I} d="M12 21s7-5.5 7-11a7 7 0 1 0-14 0c0 5.5 7 11 7 11z"/><circle cx="12" cy="10" r="2.6"/></svg>;
    case 'pinFill': return <svg width={size} height={size} viewBox="0 0 24 24"><path d="M12 21s7-5.5 7-11a7 7 0 1 0-14 0c0 5.5 7 11 7 11z" fill="currentColor"/><circle cx="12" cy="10" r="2.6" fill="#0A1628"/></svg>;
    case 'swap': return <svg {...p}><path {...I} d="M17 2l4 4-4 4M21 6H9a4 4 0 0 0-4 4M7 22l-4-4 4-4M3 18h12a4 4 0 0 0 4-4"/></svg>;
    case 'plane': return <svg {...p}><path {...I} d="M10.2 3.3a1.7 1.7 0 0 1 3.6 0V9l8 4.5v2.2L13.8 13v4.2l2.4 1.8v1.8L12 19.6 7.8 20.8V19l2.4-1.8V13L2 15.7v-2.2L10.2 9V3.3z"/></svg>;
    case 'planeFill': return <svg width={size} height={size} viewBox="0 0 512 512"><path fill="currentColor" d="M186.62 464H160a16 16 0 01-14.57-22.61l64.08-145.16L113 297l-35.8 42.13a16 16 0 01-12.19 5.61H50a16 16 0 01-15.48-20.07l23-86-23-86A16 16 0 0150 132.27L65 132a16 16 0 0112.22 5.66L113 180l96.44 1.39L145.43 36.6A16 16 0 01160 14h26.91a16 16 0 0114.49 9.19L295.05 181l95.3 1.8c9.88.14 23.19 1 32.49 4.00 00 44.57 14.89 51 21.33A32 32 0 01480 256v.07c-.11 9.24-5.34 17.8-14.61 24.14-7.05 4.82-21.58 10.65-51 13.52a183.35 183.35 0 01-31.93-.14L295.05 331 201.4 488.81A16 16 0 01186.62 464z"/></svg>;
    case 'clock': return <svg {...p}><circle {...I} cx="12" cy="12" r="8.5"/><path {...I} d="M12 7v5l3.5 2"/></svg>;
    case 'chevDown': return <svg {...p}><path {...I} d="M6 9l6 6 6-6"/></svg>;
    case 'chevRight': return <svg {...p}><path {...I} d="M9 6l6 6-6 6"/></svg>;
    case 'chevLeft': return <svg {...p}><path {...I} d="M15 6l-6 6 6 6"/></svg>;
    case 'check': return <svg {...p}><path {...I} d="M4 12.5 9 17.5 20 6.5"/></svg>;
    case 'moon': return <svg {...p}><path {...I} d="M20 13.5A8 8 0 1 1 10.5 4a6.5 6.5 0 0 0 9.5 9.5z"/></svg>;
    case 'sun': return <svg {...p}><circle {...I} cx="12" cy="12" r="4"/><path {...I} d="M12 2v3M12 19v3M2 12h3M19 12h3M5 5l2 2M17 17l2 2M19 5l-2 2M7 17l-2 2"/></svg>;
    case 'distance': return <svg {...p}><path {...I} d="M5 19L19 5"/><circle cx="5" cy="19" r="2.2" {...I}/><circle cx="19" cy="5" r="2.2" {...I}/></svg>;
    case 'play': return <svg {...p}><path {...I} d="M7 4.5v15l13-7.5z"/></svg>;
    case 'pause': return <svg {...p}><path {...I} d="M8 5v14M16 5v14"/></svg>;
    case 'refresh': return <svg {...p}><path {...I} d="M4 12a8 8 0 1 1 2.3 5.6M4 18v-4h4"/></svg>;
    case 'minus': return <svg {...p}><path {...I} d="M5 12h14"/></svg>;
    case 'plus': return <svg {...p}><path {...I} d="M12 5v14M5 12h14"/></svg>;
    case 'cam': return <svg {...p}><path {...I} d="M3 8.5A1.5 1.5 0 0 1 4.5 7h2L8 5h8l1.5 2h2A1.5 1.5 0 0 1 21 8.5v9A1.5 1.5 0 0 1 19.5 19h-15A1.5 1.5 0 0 1 3 17.5z"/><circle {...I} cx="12" cy="13" r="3.2"/></svg>;
    case 'doc': return <svg {...p}><path {...I} d="M6 3h8l4 4v14H6zM14 3v4h4M9 13h6M9 16h4"/></svg>;
    case 'bolt': return <svg {...p}><path {...I} d="M13 2 4 14h6l-1 8 9-12h-6z"/></svg>;
    case 'tap': return <svg {...p}><path {...I} d="M9 11V6.5a1.5 1.5 0 0 1 3 0V11M12 11V8.5a1.5 1.5 0 0 1 3 0V11M15 11v-1a1.5 1.5 0 0 1 3 0v5a5 5 0 0 1-5 5h-1a5 5 0 0 1-4.3-2.5L5 17a1.6 1.6 0 0 1 2.5-2L9 16.5V11a1.5 1.5 0 0 1 3 0"/></svg>;
    case 'star': return <svg {...p}><path {...I} d="M12 3.5l2.6 5.3 5.9.9-4.2 4.1 1 5.8L12 17l-5.3 2.6 1-5.8L3.5 9.7l5.9-.9z"/></svg>;
    case 'people': return <svg {...p}><circle {...I} cx="9" cy="8" r="3.2"/><path {...I} d="M3.5 20a5.5 5.5 0 0 1 11 0M16 5.5a3.2 3.2 0 0 1 0 6M17 20a5.5 5.5 0 0 0-3-4.9"/></svg>;
    case 'flag': return <svg {...p}><path {...I} d="M5 21V4M5 4h12l-2 4 2 4H5"/></svg>;
    case 'depart': return <svg {...p}><path {...I} d="M2 22h20M3.5 16.5l5 .8 9.3 3a1.6 1.6 0 0 0 1.9-2.3L17 14l-1.5-7.5a1.4 1.4 0 0 0-2.6-.3L11 10.5 6 9.6 4.5 6 3 6.4l1 5.1z"/></svg>;
    case 'arrive': return <svg {...p}><path {...I} d="M2 22h20M21 13.8l-5-.5L7 9.8a1.6 1.6 0 0 0-2.1 2L7 16l-2.3 6.6M16 13.3l1.2-7.6a1.4 1.4 0 0 0-2.4-1.2L9.8 9.6"/></svg>;
    default: return null;
  }
}

// ── small shared bits ──
function autoTotal(off,on){
  const md=off.replace(':','').match(/^([0-2]\d)([0-5]\d)$/), ma=on.replace(':','').match(/^([0-2]\d)([0-5]\d)$/);
  if(!md||!ma) return '';
  let t=(+ma[1]*60+ +ma[2])-(+md[1]*60+ +md[2]); if(t<0)t+=1440;
  return Math.floor(t/60)+':'+String(t%60).padStart(2,'0');
}

Object.assign(window,{
  LF_C,LF_MONO,LF_SERIF,LF_SANS,LF_AIRPORTS,cityOf,LF_DEMO,
  LF_SAVED_TYPES,LF_RECENT_DEP,LF_RECENT_ARR,LF_REGS,LFIcon,autoTotal,LF_isHeli,
});
