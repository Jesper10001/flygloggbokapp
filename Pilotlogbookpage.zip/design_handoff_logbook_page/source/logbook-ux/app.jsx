// Logbook redesign — app shell: List/Book toggle, calendar + detail overlays, Tweaks.

const L_DEFAULTS = /*EDITMODE-BEGIN*/{
  "accent": "#00C8E8",
  "mode": "list"
}/*EDITMODE-END*/;

function injectAccent(hex) {
  const n = parseInt(hex.replace('#',''), 16);
  const r = (n>>16)&255, g = (n>>8)&255, b = n&255;
  const s = document.documentElement.style;
  s.setProperty('--acc', hex); s.setProperty('--acc-soft', `rgba(${r},${g},${b},0.14)`);
}

const TABS = [['home','Home','list'],['log','Logbook','book'],['ins','Insights','bolt'],['more','More','gear']];

function LogbookApp() {
  const [tw, setTweak] = window.useTweaks(L_DEFAULTS);
  const accent = tw.accent || L_DEFAULTS.accent;
  const [mode, setMode] = React.useState(tw.mode || 'list');
  const [cal, setCal] = React.useState(false);
  const [detail, setDetail] = React.useState(null);
  const C = window.L_C;

  React.useEffect(() => { injectAccent(accent); }, [accent]);
  React.useEffect(() => { if (tw.mode) setMode(tw.mode); }, [tw.mode]);

  return (
    <>
      <div style={{ position: 'fixed', inset: 0, display: 'grid', placeItems: 'center',
        background: 'radial-gradient(1100px 700px at 50% -200px, #0E1E33, transparent 70%), #05080F',
        padding: 20, boxSizing: 'border-box' }}>
        <window.IOSDevice width={393} height={812} dark={true}>
          <div style={{ position: 'absolute', inset: 0, background: C.bg, fontFamily: window.L_FONT, overflow: 'hidden' }}>
            {/* List/Book segmented toggle pinned top-right of the header zone */}
            <div style={{ position: 'absolute', top: 56, right: 14, zIndex: 8, display: 'flex', gap: 3,
              background: C.surface, border: `1px solid ${C.border}`, borderRadius: 9, padding: 3 }}>
              {[['list','list'],['book','book'],['fleet','grid']].map(([k, ic]) => {
                const sel = mode === k;
                return (
                  <button key={k} onClick={() => { setMode(k); setTweak('mode', k); }} style={{ width: 32, height: 28, borderRadius: 7,
                    border: 'none', cursor: 'pointer', background: sel ? accent : 'transparent',
                    color: sel ? C.bgDeep : C.text3, display: 'grid', placeItems: 'center' }}>
                    <window.LIcon name={ic} size={15}/></button>
                );
              })}
            </div>

            {mode === 'list'
              ? <window.LogbookList accent={accent} onOpenFlight={setDetail} onOpenCalendar={() => setCal(true)}/>
              : mode === 'fleet'
              ? <window.FleetView accent={accent}/>
              : <window.BookView accent={accent}/>}

            {/* bottom tab bar */}
            <div style={{ position: 'absolute', left: 0, right: 0, bottom: 0, zIndex: 9,
              background: `linear-gradient(180deg, transparent, ${C.bg} 22%)`, paddingTop: 14 }}>
              <div style={{ display: 'flex', justifyContent: 'space-around', background: 'rgba(15,30,58,0.92)',
                backdropFilter: 'blur(16px)', borderTop: `1px solid ${C.border}`, padding: '8px 8px 24px' }}>
                {TABS.map(([k, label, ic]) => {
                  const active = k === 'log';
                  return (
                    <div key={k} style={{ flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 4,
                      color: active ? accent : C.muted }}>
                      <window.LIcon name={ic} size={22}/>
                      <span style={{ fontFamily: window.L_MONO, fontSize: 8.5, fontWeight: 700, letterSpacing: '0.06em', textTransform: 'uppercase' }}>{label}</span>
                    </div>
                  );
                })}
              </div>
            </div>

            {detail && <window.FlightDetail f={detail} accent={accent} onClose={() => setDetail(null)}/>}
            {cal && <window.CalendarSheet accent={accent} onClose={() => setCal(false)}
              onPickDay={(d) => { setCal(false); const f = window.L_FLIGHTS.find((x) => x.date.toDateString() === d.toDateString()); if (f) setDetail(f); }}/>}
          </div>
        </window.IOSDevice>
      </div>

      <window.TweaksPanel title="Tweaks">
        <window.TweakSection label="View"/>
        <window.TweakRadio label="Mode" value={mode} options={['list','book','fleet']} onChange={(v) => { setMode(v); setTweak('mode', v); }}/>
        <window.TweakSection label="Accent"/>
        <window.TweakColor label="Color" value={accent} options={window.L_ACCENTS} onChange={(v) => setTweak('accent', v)}/>
      </window.TweaksPanel>
    </>
  );
}

ReactDOM.createRoot(document.getElementById('root')).render(<LogbookApp/>);
