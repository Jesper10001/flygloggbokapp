// Fleet view — aircraft models flown, each with performance stats (editable),
// type-rating validity, total time, and a top-3 registrations dropdown.
// Sorted by most-recently-flown (current aircraft first).

const { useState: fS } = React;

// mixed demo fleet — lastFlown drives order (newest first)
const FLEET = [
  { model: 'A320', maker: 'Airbus', cls: 'Type rating', lastFlown: '2026-06-13',
    totalH: 4980, rating: { status: 'valid', date: '2027-11-30' },
    vne: 350, vne_u: 'KIAS', cruise: 447, cruise_u: 'kt', endur: 5.5, mtow: 78000, mtow_u: 'kg',
    regs: [ { r: 'SE-MJZ', h: 2140 }, { r: 'SE-RUA', h: 1620 }, { r: 'SE-DOZ', h: 880 }, { r: 'SE-RJF', h: 340 } ] },
  { model: 'DA40', maker: 'Diamond', cls: 'SEP (land)', lastFlown: '2026-04-22',
    totalH: 212, rating: { status: 'expiring', date: '2026-09-02' },
    vne: 178, vne_u: 'kt', cruise: 135, cruise_u: 'kt', endur: 5.5, mtow: 1200, mtow_u: 'kg',
    regs: [ { r: 'SE-MBF', h: 128 }, { r: 'SE-LKP', h: 64 }, { r: 'SE-GVR', h: 20 } ] },
  { model: 'C172', maker: 'Cessna', cls: 'SEP (land)', lastFlown: '2025-11-08',
    totalH: 96, rating: { status: 'valid', date: '2027-05-14' },
    vne: 163, vne_u: 'kt', cruise: 122, cruise_u: 'kt', endur: 5.0, mtow: 1157, mtow_u: 'kg',
    regs: [ { r: 'SE-KMP', h: 58 }, { r: 'SE-IRO', h: 38 } ] },
  { model: 'PA28', maker: 'Piper', cls: 'SEP (land)', lastFlown: '2024-08-30',
    totalH: 61, rating: { status: 'expired', date: '2025-12-31' },
    vne: 154, vne_u: 'kt', cruise: 115, cruise_u: 'kt', endur: 4.5, mtow: 1055, mtow_u: 'kg',
    regs: [ { r: 'SE-GZK', h: 41 }, { r: 'SE-FPL', h: 20 } ] },
];

const fmtTotal = (h) => `${Math.floor(h)}:${String(Math.round((h % 1) * 60)).padStart(2, '0')}`;
const relMonth = (iso) => {
  const d = new Date(iso + 'T00:00:00'), now = new Date('2026-06-13T00:00:00');
  const days = Math.round((now - d) / 86400000);
  if (days < 30) return `${days}d ago`;
  const mo = Math.round(days / 30);
  if (mo < 12) return `${mo}mo ago`;
  return `${(days / 365).toFixed(1)}y ago`;
};
const RATING = {
  valid:    { c: '#00E8A0', label: 'Valid' },
  expiring: { c: '#FFB830', label: 'Expiring' },
  expired:  { c: '#FF4D6A', label: 'Expired' },
};

function StatCell({ label, value, unit, editable, editing, onChange }) {
  const C = window.L_C;
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
      <span style={{ fontFamily: window.L_MONO, fontSize: 7.5, fontWeight: 700, letterSpacing: '0.1em',
        textTransform: 'uppercase', color: C.muted }}>{label}</span>
      {editing && editable ? (
        <input value={value} onChange={(e) => onChange(e.target.value.replace(/[^0-9.]/g, ''))}
          inputMode="decimal" style={{ width: '100%', background: C.bgDeep, border: `1px solid var(--acc)`,
            borderRadius: 5, color: C.text, fontFamily: window.L_MONO, fontSize: 12, fontWeight: 700,
            padding: '2px 4px', outline: 'none' }} />
      ) : (
        <span style={{ fontFamily: window.L_MONO, fontSize: 12.5, fontWeight: 700, color: C.text, whiteSpace: 'nowrap' }}>
          {value}<span style={{ fontSize: 8, color: C.muted, marginLeft: 2 }}>{unit}</span></span>
      )}
    </div>
  );
}

function FleetCard({ ac, accent, current, big }) {
  const C = window.L_C;
  const [editing, setEditing] = fS(false);
  const [showAll, setShowAll] = fS(false);
  const [stats, setStats] = fS({ vne: ac.vne, cruise: ac.cruise, endur: ac.endur, mtow: ac.mtow });
  const set = (k) => (v) => setStats((s) => ({ ...s, [k]: v }));
  const rt = RATING[ac.rating.status];
  const regs = showAll ? ac.regs : ac.regs.slice(0, 3);

  return (
    <div style={{ background: C.card, border: `1px solid ${current ? accent + '88' : C.border}`,
      borderRadius: 16, padding: 13, display: 'flex', flexDirection: 'column', gap: 11,
      boxShadow: current ? `0 0 0 1px ${accent}44, 0 10px 24px -16px ${accent}` : 'none' }}>
      {/* header */}
      <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between' }}>
        <div style={{ minWidth: 0 }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
            <span style={{ fontFamily: window.L_SERIF, fontSize: big ? 30 : 20, fontWeight: 600, color: C.text, letterSpacing: '-0.01em' }}>{ac.model}</span>
            {current && <span style={{ fontFamily: window.L_MONO, fontSize: 7, fontWeight: 700, letterSpacing: '0.12em',
              color: C.bgDeep, background: accent, padding: '2px 5px', borderRadius: 4 }}>NOW</span>}
          </div>
          <div style={{ fontFamily: window.L_FONT, fontSize: 10.5, color: C.muted, marginTop: 1, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{ac.maker}</div>
        </div>
        <button onClick={() => setEditing((e) => !e)} style={{ flexShrink: 0, width: 24, height: 24, borderRadius: 7,
          background: editing ? accent : C.elevated, border: `1px solid ${editing ? accent : C.border}`,
          color: editing ? C.bgDeep : C.text3, cursor: 'pointer', display: 'grid', placeItems: 'center' }}>
          <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 20h9M16.5 3.5a2.1 2.1 0 0 1 3 3L7 19l-4 1 1-4 12.5-12.5z"/></svg>
        </button>
      </div>

      {/* total time + type rating */}
      <div style={{ display: 'flex', alignItems: 'flex-end', justifyContent: 'space-between' }}>
        <div>
          <div style={{ fontFamily: window.L_MONO, fontSize: 7.5, fontWeight: 700, letterSpacing: '0.1em', textTransform: 'uppercase', color: C.muted }}>Total time</div>
          <div style={{ fontFamily: window.L_MONO, fontSize: big ? 28 : 17, fontWeight: 700, color: accent }}>{fmtTotal(ac.totalH)}</div>
        </div>
        <div style={{ textAlign: 'right' }}>
          <div style={{ display: 'inline-flex', alignItems: 'center', gap: 4 }}>
            <span style={{ width: 6, height: 6, borderRadius: '50%', background: rt.c }}/>
            <span style={{ fontFamily: window.L_MONO, fontSize: 9, fontWeight: 700, color: rt.c, letterSpacing: '0.04em' }}>{rt.label}</span>
          </div>
          <div style={{ fontFamily: window.L_MONO, fontSize: 9, color: C.muted, marginTop: 1 }}>{ac.cls} · {ac.rating.date.slice(0, 7)}</div>
        </div>
      </div>

      {/* perf stat grid (editable) */}
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '9px 10px',
        padding: '10px 0', borderTop: `1px solid ${C.separator}`, borderBottom: `1px solid ${C.separator}` }}>
        <StatCell label="VNE" value={stats.vne} unit={ac.vne_u} editable editing={editing} onChange={set('vne')} />
        <StatCell label="Cruise" value={stats.cruise} unit={ac.cruise_u} editable editing={editing} onChange={set('cruise')} />
        <StatCell label="Endurance" value={stats.endur} unit="h" editable editing={editing} onChange={set('endur')} />
        <StatCell label="MTOW" value={stats.mtow} unit={ac.mtow_u} editable editing={editing} onChange={set('mtow')} />
      </div>

      {/* registrations */}
      <div>
        <div style={{ display: 'flex', alignItems: 'baseline', justifyContent: 'space-between', marginBottom: 6 }}>
          <span style={{ fontFamily: window.L_MONO, fontSize: 7.5, fontWeight: 700, letterSpacing: '0.1em', textTransform: 'uppercase', color: C.muted }}>Registrations</span>
          <span style={{ fontFamily: window.L_MONO, fontSize: 9, fontWeight: 700, color: C.text3 }}>{ac.regs.length}</span>
        </div>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 4 }}>
          {regs.map((r) => (
            <div key={r.r} style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
              <span style={{ fontFamily: window.L_MONO, fontSize: 11, fontWeight: 700, color: C.text2, letterSpacing: '0.04em' }}>{r.r}</span>
              <span style={{ fontFamily: window.L_MONO, fontSize: 10, color: C.muted }}>{fmtTotal(r.h)}</span>
            </div>
          ))}
        </div>
        {ac.regs.length > 3 && (
          <button onClick={() => setShowAll((v) => !v)} style={{ marginTop: 7, width: '100%', padding: '5px',
            borderRadius: 7, background: 'transparent', border: `1px solid ${C.border}`, color: accent,
            cursor: 'pointer', fontFamily: window.L_MONO, fontSize: 9, fontWeight: 700, letterSpacing: '0.06em' }}>
            {showAll ? 'Show less' : `Show all ${ac.regs.length}`}</button>
        )}
      </div>

      <div style={{ display: 'flex', alignItems: 'center', gap: 5, fontFamily: window.L_MONO, fontSize: 8.5, color: C.faint }}>
        <window.LIcon name="clock" size={10}/> Last flown {relMonth(ac.lastFlown)}
      </div>
    </div>
  );
}

function FleetView({ accent }) {
  const C = window.L_C;
  const sorted = [...FLEET].sort((a, b) => new Date(b.lastFlown) - new Date(a.lastFlown));
  return (
    <div style={{ position: 'absolute', inset: 0, display: 'flex', flexDirection: 'column' }}>
      <div style={{ flexShrink: 0, padding: '54px 14px 12px', background: C.bg, borderBottom: `1px solid ${C.separator}` }}>
        <div style={{ paddingRight: 90 }}>
          <span style={{ fontFamily: window.L_SERIF, fontSize: 26, fontWeight: 600, color: C.text }}>Fleet</span>
        </div>
        <div style={{ fontFamily: window.L_MONO, fontSize: 9.5, color: C.muted, letterSpacing: '0.04em', marginTop: 2 }}>
          {FLEET.length} types · {FLEET.reduce((s, a) => s + a.regs.length, 0)} registrations · by last flown</div>
      </div>
      <div style={{ flex: 1, overflowY: 'auto', padding: '14px' }}>
        <div style={{ display: 'grid', gridTemplateColumns: sorted.length === 1 ? '1fr' : '1fr 1fr', gap: 12, paddingBottom: 24 }}>
          {sorted.map((ac, i) => <FleetCard key={ac.model} ac={ac} accent={accent} current={i === 0} big={sorted.length === 1} />)}
        </div>
      </div>
    </div>
  );
}

Object.assign(window, { FleetView });
