// Logbook — rich flight cards + year→month accordion list, sticky search, chips.

const { useState: uS, useMemo: uM, useRef: uR } = React;

function badge(C, color, label) {
  return (
    <span style={{ display: 'inline-flex', alignItems: 'center', gap: 3,
      fontFamily: window.L_MONO, fontSize: 8.5, fontWeight: 700, letterSpacing: '0.08em',
      color, background: color + '1F', border: `1px solid ${color}55`, padding: '2px 5px', borderRadius: 4 }}>
      {label}</span>
  );
}

// simplified flight card — clean single block, no divider/photo flourish
function FlightCard({ f, accent, onOpen }) {
  const C = window.L_C;
  const dep = window.CITY[f.dep] || f.dep, arr = window.CITY[f.arr] || f.arr;
  const roleColor = f.role === 'PIC' ? accent : C.text3;
  return (
    <div onClick={onOpen} style={{ display: 'flex', alignItems: 'center', gap: 13, padding: '12px 14px',
      cursor: 'pointer', borderTop: `1px solid ${C.separator}` }}>
      {/* date chip */}
      <div style={{ flexShrink: 0, width: 34, textAlign: 'center' }}>
        <div style={{ fontFamily: window.L_SERIF, fontSize: 20, fontWeight: 600, color: C.text, lineHeight: 1 }}>{f.date.getDate()}</div>
        <div style={{ fontFamily: window.L_MONO, fontSize: 8, fontWeight: 700, letterSpacing: '0.08em',
          color: C.muted, textTransform: 'uppercase', marginTop: 2 }}>{['Sun','Mon','Tue','Wed','Thu','Fri','Sat'][f.date.getDay()]}</div>
      </div>
      {/* main */}
      <div style={{ flex: 1, minWidth: 0 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 7 }}>
          <span style={{ fontFamily: window.L_MONO, fontSize: 14, fontWeight: 700, color: C.text, letterSpacing: '0.02em', whiteSpace: 'nowrap', flexShrink: 0 }}>{f.dep} → {f.arr}</span>
          {f.ifr && badge(C, accent, 'IFR')}
          {f.night && badge(C, C.night, <span style={{ display: 'inline-flex' }}><window.LIcon name="moon" size={9}/></span>)}
        </div>
        <div style={{ fontFamily: window.L_MONO, fontSize: 10, color: C.muted, marginTop: 3, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>
          <span style={{ color: roleColor, fontWeight: 700 }}>{f.role === 'CO-PILOT' ? 'CO-PI' : f.role}</span> · {f.type} {f.reg}
        </div>
      </div>
      {/* duration */}
      <div style={{ flexShrink: 0, textAlign: 'right' }}>
        <div style={{ fontFamily: window.L_MONO, fontSize: 14, fontWeight: 700, color: C.text, fontVariantNumeric: 'tabular-nums' }}>{f.durLabel}</div>
        <div style={{ fontFamily: window.L_MONO, fontSize: 9, color: C.muted, marginTop: 2 }}>
          {f.depUTC} <span style={{ color: C.faint }}>·</span> {(() => { const [h,m]=f.depUTC.split(':').map(Number); const t=h*60+m+Math.round(f.durH*60); return `${String(Math.floor(t/60)%24).padStart(2,'0')}:${String(t%60).padStart(2,'0')}`; })()}z</div>
      </div>
      <window.LIcon name="chevron" size={15}/>
    </div>
  );
}

function PhotoCard({ f, accent, onOpen }) {
  const C = window.L_C;
  return (
    <div onClick={onOpen} style={{ cursor: 'pointer', margin: '10px 12px 0', borderRadius: 14,
      overflow: 'hidden', border: `1px solid ${C.border}`, background: C.card }}>
      <div style={{ position: 'relative', width: '100%', aspectRatio: '16 / 10',
        background: `linear-gradient(135deg, ${accent}33, ${C.violet}33), url('share-assets/example-photo.jpeg') center/cover` }}>
        <div style={{ position: 'absolute', inset: 0, background: 'linear-gradient(180deg, transparent 45%, rgba(6,11,22,0.78))' }}/>
        <div style={{ position: 'absolute', left: 12, right: 12, bottom: 10, display: 'flex', alignItems: 'flex-end', justifyContent: 'space-between' }}>
          <div>
            <div style={{ fontFamily: window.L_MONO, fontSize: 15, fontWeight: 700, color: '#fff', letterSpacing: '0.04em', textShadow: '0 1px 6px rgba(0,0,0,0.6)' }}>{f.dep} → {f.arr}</div>
            <div style={{ fontFamily: window.L_MONO, fontSize: 9.5, color: 'rgba(255,255,255,0.82)', marginTop: 2, textShadow: '0 1px 6px rgba(0,0,0,0.6)' }}>
              {f.date.toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: '2-digit' })} · {f.type} {f.reg}</div>
          </div>
          <span style={{ fontFamily: window.L_MONO, fontSize: 14, fontWeight: 700, color: '#fff', textShadow: '0 1px 6px rgba(0,0,0,0.6)' }}>{f.durLabel}</span>
        </div>
      </div>
    </div>
  );
}

function MonthGroup({ grp, accent, openOpen, onToggle, onOpenFlight, photo }) {
  const C = window.L_C;
  return (
    <div>
      <div onClick={onToggle} style={{ display: 'flex', alignItems: 'center',
        gap: 10, padding: '9px 14px', cursor: 'pointer',
        background: 'rgba(15,30,58,0.96)',
        borderBottom: openOpen ? `1px solid ${C.separator}` : 'none' }}>
        <span style={{ display: 'flex', color: accent, transform: openOpen ? 'none' : 'rotate(-90deg)', transition: 'transform .15s' }}>
          <window.LIcon name="chevDown" size={15}/></span>
        <span style={{ fontFamily: window.L_SERIF, fontSize: 16, fontWeight: 600, color: C.text }}>{grp.label}</span>
        <span style={{ flex: 1 }}/>
        {photo
          ? <span style={{ fontFamily: window.L_MONO, fontSize: 10, fontWeight: 700, color: accent }}>{grp.count} photo{grp.count > 1 ? 's' : ''}</span>
          : <><span style={{ fontFamily: window.L_MONO, fontSize: 10, fontWeight: 700, color: accent }}>{window.fmtInt(grp.hours)}h</span>
        <span style={{ fontFamily: window.L_MONO, fontSize: 10, color: C.muted }}>· {grp.count} flt</span></>}
      </div>
      {openOpen && !photo && grp.flights.map((f) => <FlightCard key={f.id} f={f} accent={accent} onOpen={() => onOpenFlight(f)}/>)}
      {openOpen && photo && (
        <div style={{ paddingBottom: 12 }}>
          {grp.flights.map((f) => <PhotoCard key={f.id} f={f} accent={accent} onOpen={() => onOpenFlight(f)}/>)}
        </div>
      )}
    </div>
  );
}

const FILTERS = [['all','All'],['pic','PIC'],['ifr','IFR'],['night','Night'],['photo','Photo']];

function LogbookList({ accent, onOpenFlight, onOpenCalendar }) {
  const C = window.L_C;
  const [q, setQ] = uS('');
  const [filter, setFilter] = uS('all');
  const [ovr, setOvr] = uS({}); // key → explicit open/closed override
  const [yearOvr, setYearOvr] = uS({}); // year → explicit open/closed override
  const NOW = new Date(2026, 5, 13);
  const isDefaultOpen = (yr, m) => yr === NOW.getFullYear() && m === NOW.getMonth();

  const filtered = uM(() => {
    const ql = q.trim().toLowerCase();
    return window.L_FLIGHTS.filter((f) => {
      if (filter === 'pic' && f.role !== 'PIC') return false;
      if (filter === 'ifr' && !f.ifr) return false;
      if (filter === 'night' && !f.night) return false;
      if (filter === 'photo' && !f.hasPhoto) return false;
      if (ql) {
        const hay = `${f.dep} ${f.arr} ${window.CITY[f.dep]||''} ${window.CITY[f.arr]||''} ${f.reg} ${f.type} ${f.role}`.toLowerCase();
        if (!hay.includes(ql)) return false;
      }
      return true;
    });
  }, [q, filter]);

  const years = uM(() => window.groupFlights(filtered), [filtered]);
  const latest = window.L_FLIGHTS[0];

  return (
    <div style={{ position: 'absolute', inset: 0, display: 'flex', flexDirection: 'column' }}>
      {/* sticky header: title + search + chips */}
      <div style={{ flexShrink: 0, padding: '54px 14px 10px', background: C.bg, zIndex: 5,
        borderBottom: `1px solid ${C.separator}` }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 12 }}>
          <span style={{ fontFamily: window.L_SERIF, fontSize: 26, fontWeight: 600, color: C.text, flex: 1 }}>Logbook</span>
          <button onClick={onOpenCalendar} style={{ width: 34, height: 34, borderRadius: 9, background: C.surface,
            border: `1px solid ${C.border}`, color: C.text2, cursor: 'pointer', display: 'grid', placeItems: 'center' }}>
            <window.LIcon name="calendar" size={17}/></button>
        </div>
        {/* search */}
        <div style={{ display: 'flex', alignItems: 'center', gap: 8, background: C.surface, border: `1px solid ${C.border}`,
          borderRadius: 11, padding: '9px 12px' }}>
          <span style={{ color: C.muted, display: 'flex' }}><window.LIcon name="search" size={16}/></span>
          <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search airport, aircraft, role…"
            style={{ flex: 1, background: 'none', border: 'none', outline: 'none', color: C.text,
              fontFamily: window.L_FONT, fontSize: 13.5 }}/>
          {q && <span onClick={() => setQ('')} style={{ color: C.muted, cursor: 'pointer', display: 'flex' }}><window.LIcon name="close" size={14}/></span>}
        </div>
        {/* filter chips */}
        <div style={{ display: 'flex', gap: 6, marginTop: 10, overflowX: 'auto', scrollbarWidth: 'none' }}>
          {FILTERS.map(([k, label]) => {
            const sel = filter === k;
            return (
              <button key={k} onClick={() => setFilter(k)} style={{ flexShrink: 0, padding: '6px 12px', borderRadius: 999,
                border: `1px solid ${sel ? accent : C.border}`, cursor: 'pointer',
                background: sel ? accent : C.surface, color: sel ? C.bgDeep : C.text2,
                fontFamily: window.L_MONO, fontSize: 10.5, fontWeight: 700, letterSpacing: '0.06em' }}>{label}</button>
            );
          })}
        </div>
      </div>

      {/* scroll body */}
      <div style={{ flex: 1, overflowY: 'auto' }}>
        {/* latest flight shortcut */}
        {filter === 'all' && !q && (
          <div style={{ padding: '12px 14px 4px' }}>
            <div onClick={() => onOpenFlight(latest)} style={{ cursor: 'pointer', borderRadius: 16, overflow: 'hidden',
              background: `linear-gradient(140deg, ${accent}22, ${C.surface})`, border: `1px solid ${accent}55` }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 8, padding: '12px 14px 8px' }}>
                <span style={{ fontFamily: window.L_MONO, fontSize: 9.5, fontWeight: 700, letterSpacing: '0.18em',
                  textTransform: 'uppercase', color: accent }}>Latest flight</span>
                <span style={{ flex: 1, height: 1, background: `${accent}33` }}/>
                <span style={{ fontFamily: window.L_MONO, fontSize: 10, color: C.text3 }}>
                  {latest.date.toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: '2-digit' })}</span>
              </div>
              <div style={{ display: 'flex', alignItems: 'center', gap: 12, padding: '0 14px 6px' }}>
                <window.NightRoute dep={latest.dep} arr={latest.arr} nightFrac={window.nightFraction(latest)} size={30} accent={accent}/>
                <span style={{ flex: 1 }}/>
                <div style={{ textAlign: 'right' }}>
                  <div style={{ fontFamily: window.L_MONO, fontSize: 17, fontWeight: 700, color: C.text }}>{latest.durLabel}</div>
                  <div style={{ fontFamily: window.L_MONO, fontSize: 9, color: C.muted }}>BLOCK</div>
                </div>
              </div>
              {/* night-portion caption */}
              <div style={{ display: 'flex', alignItems: 'center', gap: 6, padding: '0 14px 8px' }}>
                <span style={{ color: '#C7CDDA', display: 'flex' }}><window.LIcon name="moon" size={11}/></span>
                <span style={{ fontFamily: window.L_MONO, fontSize: 9.5, fontWeight: 700, letterSpacing: '0.04em', color: '#C7CDDA' }}>
                  {Math.round(window.nightFraction(latest) * 100)}% night</span>
                <span style={{ fontFamily: window.L_MONO, fontSize: 9.5, color: C.muted }}>· dark {latest.darkOnset}z</span>
              </div>
              <div style={{ fontFamily: window.L_FONT, fontSize: 11.5, color: C.text3, padding: '0 14px 10px' }}>
                {(window.CITY[latest.dep]||latest.dep)} → {(window.CITY[latest.arr]||latest.arr)}</div>
              <div style={{ display: 'flex', gap: 0, borderTop: `1px solid ${accent}33` }}>
                {[['Role', latest.role === 'CO-PILOT' ? 'CO-PI' : latest.role], ['Aircraft', `${latest.type} ${latest.reg}`],
                  ['Dep', latest.depUTC + 'z'], ['Rules', latest.ifr ? 'IFR' : 'VFR'], ['Arr', (() => { const [h,m]=latest.depUTC.split(':').map(Number); const t=h*60+m+Math.round(latest.durH*60); return `${String(Math.floor(t/60)%24).padStart(2,'0')}:${String(t%60).padStart(2,'0')}z`; })()]].map(([k, v], i) => (
                  <div key={k} style={{ flex: 1, padding: '8px 6px', borderLeft: i ? `1px solid ${accent}22` : 'none', textAlign: 'center' }}>
                    <div style={{ fontFamily: window.L_MONO, fontSize: 7.5, fontWeight: 700, letterSpacing: '0.1em', textTransform: 'uppercase', color: C.muted }}>{k}</div>
                    <div style={{ fontFamily: window.L_MONO, fontSize: 10.5, fontWeight: 700, color: i === 0 && latest.role === 'PIC' ? accent : C.text, marginTop: 3, whiteSpace: 'nowrap' }}>{v}</div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {years.length === 0 && (
          <div style={{ textAlign: 'center', padding: '50px 20px', fontFamily: window.L_MONO, fontSize: 12, color: C.muted }}>
            No flights match “{q}”.</div>
        )}

        {years.map((yr) => {
          const curYear = years[0].year;
          const isCur = yr.year === curYear;
          const yearKey = `year-${yr.year}`;
          const yearOpen = (q || filter !== 'all') ? true
            : (yearOvr[yearKey] !== undefined ? yearOvr[yearKey] : false);
          return (
            <div key={yr.year}>
              <div onClick={() => setYearOvr((c) => ({ ...c, [yearKey]: !yearOpen }))}
                style={{ display: 'flex', alignItems: 'baseline', gap: 8, padding: '14px 14px 7px',
                  cursor: 'pointer' }}>
                <span style={{ display: 'flex', alignSelf: 'center', color: accent,
                  transform: yearOpen ? 'none' : 'rotate(-90deg)', transition: 'transform .15s' }}>
                  <window.LIcon name="chevDown" size={15}/></span>
                <span style={{ fontFamily: window.L_SERIF, fontSize: 21, fontWeight: 600, color: C.text, letterSpacing: '-0.01em' }}>{yr.year}</span>
                <span style={{ flex: 1, height: 1, background: C.separator }}/>
                <span style={{ fontFamily: window.L_MONO, fontSize: 11, fontWeight: 700, color: accent }}>{filter === 'photo' ? `${yr.count} photos` : `${window.fmtInt(yr.hours)}h${filter !== 'all' ? ` ${filter.toUpperCase()}` : ''}`}</span>
                <span style={{ fontFamily: window.L_MONO, fontSize: 11, color: C.muted }}>{filter === 'photo' ? '' : `${yr.count} flights`}</span>
              </div>
              {yearOpen && yr.months.map((grp) => {
                const key = `${yr.year}-${grp.m}`;
                const openOpen = (q || filter !== 'all') ? true
                  : (ovr[key] !== undefined ? ovr[key] : isDefaultOpen(yr.year, grp.m));
                return (
                  <div key={key} style={{ margin: '0 14px 10px', borderRadius: 14, overflow: 'hidden',
                    border: `1px solid ${C.border}`, background: C.card }}>
                    <MonthGroup grp={grp} accent={accent} openOpen={openOpen} photo={filter === 'photo'}
                      onToggle={() => setOvr((c) => ({ ...c, [key]: !openOpen }))}
                      onOpenFlight={onOpenFlight}/>
                  </div>
                );
              })}
            </div>
          );
        })}
        <div style={{ height: 24 }}/>
      </div>
    </div>
  );
}

Object.assign(window, { LogbookList });
