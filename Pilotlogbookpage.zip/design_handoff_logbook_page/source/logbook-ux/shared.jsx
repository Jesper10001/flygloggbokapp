// BLADES — Logbook page redesign · shared foundation.
// Palette mirrors the app's Navy theme. Demo persona: A320 commercial pilot.

const L_C = {
  bg: '#0A1628', bgDeep: '#06101E', surface: '#0F1E3A', surface2: '#132845',
  elevated: '#16314E', card: '#102441', border: '#1A3A5A', borderSoft: '#142B45',
  separator: '#122030',
  primary: '#00C8E8', gold: '#FFB830', success: '#00E8A0', violet: '#9B8CFF',
  night: '#5DA9FF', danger: '#FF6B5B',
  text: '#FFFFFF', text2: '#A8BFD6', text3: '#7FA8C8', muted: '#5A7FA0', faint: '#3A5A7A',
};
const L_FONT = '-apple-system, "SF Pro Display", "Inter", system-ui, sans-serif';
const L_SERIF = '"Fraunces", Georgia, serif';
const L_MONO = '"JetBrains Mono", "SF Mono", ui-monospace, monospace';
const L_ACCENTS = ['#00C8E8', '#FFB830', '#00E8A0', '#9B8CFF'];

const CITY = {
  ESSA: 'Stockholm', EGLL: 'London', EDDF: 'Frankfurt', LFPG: 'Paris', EKCH: 'Copenhagen',
  EHAM: 'Amsterdam', LEBL: 'Barcelona', LOWW: 'Vienna', LSZH: 'Zürich', EDDM: 'Munich',
  ENGM: 'Oslo', EFHK: 'Helsinki', LIRF: 'Rome', LEMD: 'Madrid', EGKK: 'London',
};

// build a believable A320 flight history (newest first)
const L_FLIGHTS = (() => {
  const routes = [
    ['ESSA','EGLL'],['EGLL','ESSA'],['ESSA','EDDF'],['EDDF','ESSA'],['ESSA','LFPG'],['LFPG','ESSA'],
    ['ESSA','EKCH'],['EKCH','EHAM'],['ESSA','LEBL'],['LEBL','ESSA'],['ESSA','LOWW'],['LOWW','ESSA'],
    ['ESSA','ENGM'],['ENGM','ESSA'],['ESSA','EFHK'],['EFHK','ESSA'],['ESSA','LIRF'],['LIRF','ESSA'],
    ['ESSA','LSZH'],['LSZH','EDDM'],
  ];
  const regs = ['SE-MJZ','SE-RUA','SE-DOZ','SE-RJF'];
  const roles = ['PIC','CO-PILOT','PIC','PIC','CO-PILOT'];
  let seed = 20260613;
  const rnd = () => { seed = (seed * 1103515245 + 12345) & 0x7fffffff; return seed / 0x7fffffff; };
  const out = [];
  let d = new Date(2026, 5, 13);
  for (let i = 0; i < 64; i++) {
    const r = routes[Math.floor(rnd() * routes.length)];
    const durH = 1 + rnd() * 3.2;
    const h = Math.floor(durH), m = Math.round((durH - h) * 60);
    const depMin = 5 * 60 + Math.floor(rnd() * 16 * 60);
    const night = rnd() < 0.28, nvg = false, ifr = rnd() < 0.92;
    out.push({
      id: 1000 + i, date: new Date(d), dep: r[0], arr: r[1],
      reg: regs[Math.floor(rnd() * regs.length)], type: 'A320',
      role: roles[Math.floor(rnd() * roles.length)],
      durLabel: `${h}:${String(m).padStart(2,'0')}`, durH: durH,
      depUTC: `${String(Math.floor(depMin/60)%24).padStart(2,'0')}:${String(depMin%60).padStart(2,'0')}`,
      ifr, night, nvg, hasPhoto: rnd() < 0.22, landings: 1 + (rnd() < 0.3 ? 1 : 0),
    });
    d = new Date(d); d.setDate(d.getDate() - (1 + Math.floor(rnd() * 6)));
  }
  return out;
})();
// latest flight = the night-portion example: ESCF→ESSA, dep 21:00, dark 22:30, arr 23:00 (last ¼ night)
L_FLIGHTS[0] = { ...L_FLIGHTS[0], dep: 'ESCF', arr: 'ESSA', depUTC: '21:00', durH: 2, durLabel: '2:00',
  ifr: true, night: true, darkOnset: '22:30', reg: 'SE-MJZ', type: 'A320', role: 'PIC', landings: 1 };

// fraction of a flight flown after dark (from arrival end), 0..1
function nightFraction(f) {
  if (!f.darkOnset) return f.night ? 1 : 0;
  const toMin = (s) => { const [h, m] = s.split(':').map(Number); return h * 60 + m; };
  const dep = toMin(f.depUTC); let dark = toMin(f.darkOnset);
  const arr = dep + Math.round(f.durH * 60);
  if (dark < dep) dark += 1440;
  const nm = Math.max(0, arr - Math.max(dep, dark));
  return Math.min(1, nm / Math.max(1, arr - dep));
}

// Route text (DEP → ARR) where the trailing night fraction is filled platinum.
function NightRoute({ dep, arr, nightFrac, size = 30, accent }) {
  const SILVER = '#C7CDDA';
  const total = dep.length + arr.length;
  const nightStart = total * (1 - nightFrac); // char index where night begins
  const renderCh = (ch, pos, idx) => {
    const start = pos, end = pos + 1;
    if (end <= nightStart) return <span key={idx} style={{ color: '#fff' }}>{ch}</span>;
    if (start >= nightStart) return <span key={idx} style={{ color: SILVER, textShadow: `0 0 10px ${SILVER}66` }}>{ch}</span>;
    const f = (nightStart - start) * 100;
    return <span key={idx} style={{
      backgroundImage: `linear-gradient(90deg, #fff ${Math.max(0, f - 8).toFixed(0)}%, ${SILVER} ${Math.min(100, f + 8).toFixed(0)}%)`,
      WebkitBackgroundClip: 'text', backgroundClip: 'text', color: 'transparent', WebkitTextFillColor: 'transparent' }}>{ch}</span>;
  };
  return (
    <span style={{ display: 'inline-flex', alignItems: 'center', gap: 10,
      fontFamily: window.L_SERIF, fontSize: size, fontWeight: 600 }}>
      <span>{[...dep].map((ch, i) => renderCh(ch, i, i))}</span>
      <span style={{ color: accent || 'var(--acc)', display: 'flex' }}><window.LIcon name="arrow" size={18}/></span>
      <span>{[...arr].map((ch, i) => renderCh(ch, dep.length + i, i))}</span>
    </span>
  );
}

const fmtInt = (n) => Math.round(n).toLocaleString('sv-SE');
const MONTH_FULL = ['January','February','March','April','May','June','July','August','September','October','November','December'];
const MONTH_ABBR = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];

// group flights → [{ year, months: [{ m, label, flights, hours, count }] }]
function groupFlights(flights) {
  const years = {};
  flights.forEach((f) => {
    const y = f.date.getFullYear(), m = f.date.getMonth();
    (years[y] = years[y] || {});
    (years[y][m] = years[y][m] || []).push(f);
  });
  return Object.keys(years).sort((a, b) => b - a).map((y) => ({
    year: +y,
    hours: flights.filter((f) => f.date.getFullYear() === +y).reduce((s, f) => s + f.durH, 0),
    count: flights.filter((f) => f.date.getFullYear() === +y).length,
    months: Object.keys(years[y]).sort((a, b) => b - a).map((m) => ({
      m: +m, label: MONTH_FULL[+m],
      flights: years[y][m],
      hours: years[y][m].reduce((s, f) => s + f.durH, 0),
      count: years[y][m].length,
    })),
  }));
}

// ── icons ──
const IS = { fill: 'none', stroke: 'currentColor', strokeWidth: 1.7, strokeLinecap: 'round', strokeLinejoin: 'round' };
function LIcon({ name, size = 20 }) {
  const p = { width: size, height: size, viewBox: '0 0 24 24' };
  switch (name) {
    case 'search': return <svg {...p}><circle {...IS} cx="11" cy="11" r="7"/><path {...IS} d="M20 20l-3.5-3.5"/></svg>;
    case 'calendar': return <svg {...p}><rect {...IS} x="3" y="4.5" width="18" height="16" rx="2.5"/><path {...IS} d="M3 9h18M8 2.5v4M16 2.5v4"/></svg>;
    case 'book': return <svg {...p}><path {...IS} d="M4 4.5A1.5 1.5 0 0 1 5.5 3H11v17H5.5A1.5 1.5 0 0 0 4 21.5V4.5zM20 4.5A1.5 1.5 0 0 0 18.5 3H13v17h5.5A1.5 1.5 0 0 1 20 21.5V4.5z"/></svg>;
    case 'list': return <svg {...p}><path {...IS} d="M8 6h13M8 12h13M8 18h13M3.5 6h.01M3.5 12h.01M3.5 18h.01"/></svg>;
    case 'grid': return <svg {...p}><rect {...IS} x="3.5" y="3.5" width="7" height="7" rx="1.5"/><rect {...IS} x="13.5" y="3.5" width="7" height="7" rx="1.5"/><rect {...IS} x="3.5" y="13.5" width="7" height="7" rx="1.5"/><rect {...IS} x="13.5" y="13.5" width="7" height="7" rx="1.5"/></svg>;
    case 'plane': return <svg {...p}><path {...IS} d="M10.2 3.3a1.7 1.7 0 0 1 3.6 0V9l8 4.5v2.2L13.8 13v4.2l2.4 1.8v1.8L12 19.6 7.8 20.8V19l2.4-1.8V13L2 15.7v-2.2L10.2 9V3.3z"/></svg>;
    case 'arrow': return <svg {...p}><path {...IS} d="M5 12h14M13 6l6 6-6 6"/></svg>;
    case 'chevron': return <svg {...p}><path {...IS} d="M9 6l6 6-6 6"/></svg>;
    case 'chevDown': return <svg {...p}><path {...IS} d="M6 9l6 6 6-6"/></svg>;
    case 'moon': return <svg {...p}><path {...IS} d="M20 13.5A8 8 0 1 1 10.5 4a6.5 6.5 0 0 0 9.5 9.5z"/></svg>;
    case 'clock': return <svg {...p}><circle {...IS} cx="12" cy="12" r="8.5"/><path {...IS} d="M12 7v5l3.5 2"/></svg>;
    case 'close': return <svg {...p}><path {...IS} d="M6 6l12 12M18 6L6 18"/></svg>;
    case 'gear': return <svg {...p}><circle {...IS} cx="12" cy="12" r="3"/><path {...IS} d="M12 2.5v3M12 18.5v3M21.5 12h-3M5.5 12h-3M18.7 5.3l-2.1 2.1M7.4 16.6l-2.1 2.1M18.7 18.7l-2.1-2.1M7.4 7.4 5.3 5.3"/></svg>;
    case 'bolt': return <svg {...p}><path {...IS} d="M13 2L4 14h6l-1 8 9-12h-6l1-8z"/></svg>;
    default: return null;
  }
}

Object.assign(window, {
  L_C, L_FONT, L_SERIF, L_MONO, L_ACCENTS, L_FLIGHTS, CITY, MONTH_FULL, MONTH_ABBR,
  fmtInt, groupFlights, LIcon, nightFraction, NightRoute,
});
