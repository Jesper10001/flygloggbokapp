// Calendar jump-to-day sheet + flight-detail screen + woven physical-book view.

const { useState: cS } = React;

// ── Calendar (jump to a day; days with flights are dotted) ──
function CalendarSheet({ accent, onClose, onPickDay }) {
  const C = window.L_C;
  const [view, setView] = cS(new Date(2026, 5, 1));
  const y = view.getFullYear(), m = view.getMonth();
  const days = new Date(y, m + 1, 0).getDate();
  const firstDow = new Date(y, m, 1).getDay();
  const flownDays = {};
  window.L_FLIGHTS.forEach((f) => { if (f.date.getFullYear() === y && f.date.getMonth() === m) flownDays[f.date.getDate()] = (flownDays[f.date.getDate()] || 0) + 1; });
  const cells = [];
  for (let i = 0; i < firstDow; i++) cells.push(null);
  for (let d = 1; d <= days; d++) cells.push(d);
  const step = (delta) => setView(new Date(y, m + delta, 1));
  return (
    <div onClick={onClose} style={{ position: 'absolute', inset: 0, zIndex: 40, background: 'rgba(4,12,24,0.7)',
      display: 'flex', flexDirection: 'column', justifyContent: 'flex-end' }}>
      <div onClick={(e) => e.stopPropagation()} style={{ background: C.surface, borderTopLeftRadius: 22, borderTopRightRadius: 22,
        borderTop: `1px solid ${C.border}`, padding: '12px 18px 30px' }}>
        <div style={{ width: 38, height: 4, borderRadius: 2, background: C.border, margin: '0 auto 16px' }}/>
        <div style={{ display: 'flex', alignItems: 'center', marginBottom: 14 }}>
          <button onClick={() => step(-1)} style={navBtn(C)}><span style={{ transform: 'rotate(180deg)', display: 'flex' }}><window.LIcon name="chevron" size={16}/></span></button>
          <span style={{ flex: 1, textAlign: 'center', fontFamily: window.L_SERIF, fontSize: 18, fontWeight: 600, color: C.text }}>
            {window.MONTH_FULL[m]} {y}</span>
          <button onClick={() => step(1)} style={navBtn(C)}><window.LIcon name="chevron" size={16}/></button>
        </div>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(7,1fr)', gap: 4, marginBottom: 4 }}>
          {['S','M','T','W','T','F','S'].map((d, i) => (
            <span key={i} style={{ textAlign: 'center', fontFamily: window.L_MONO, fontSize: 9, fontWeight: 700, color: C.faint }}>{d}</span>
          ))}
        </div>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(7,1fr)', gap: 4 }}>
          {cells.map((d, i) => {
            if (!d) return <div key={i}/>;
            const n = flownDays[d] || 0;
            return (
              <div key={i} onClick={() => n && onPickDay(new Date(y, m, d))} style={{ aspectRatio: '1', borderRadius: 8,
                background: n ? accent + '22' : 'transparent', border: `1px solid ${n ? accent + '66' : C.borderSoft}`,
                display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 2,
                cursor: n ? 'pointer' : 'default' }}>
                <span style={{ fontFamily: window.L_MONO, fontSize: 12, fontWeight: 700, color: n ? C.text : C.faint }}>{d}</span>
                {n > 0 && <span style={{ width: 4, height: 4, borderRadius: 2, background: accent }}/>}
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
const navBtn = (C) => ({ width: 34, height: 34, borderRadius: 9, background: C.elevated, border: `1px solid ${C.border}`,
  color: C.text2, cursor: 'pointer', display: 'grid', placeItems: 'center' });

// ── Flight detail — every logbook field, grouped for fast transcription ──
function FlightDetail({ f, accent, onClose }) {
  const C = window.L_C;
  const dep = window.CITY[f.dep] || f.dep, arr = window.CITY[f.arr] || f.arr;
  const isPIC = f.role === 'PIC';
  const arrUTC = (() => { const [h,m]=f.depUTC.split(':').map(Number); const t=h*60+m+Math.round(f.durH*60); return `${String(Math.floor(t/60)%24).padStart(2,'0')}:${String(t%60).padStart(2,'0')}`; })();
  const dur = f.durLabel;
  const sections = [
    { title: 'Aircraft', rows: [['Type', f.type], ['Registration', f.reg], ['Engine', 'Multi-engine'], ['Crew', 'Multi-pilot']] },
    { title: 'Departure', rows: [['Place', `${f.dep} · ${dep}`], ['Time (UTC)', f.depUTC + 'z']] },
    { title: 'Arrival', rows: [['Place', `${f.arr} · ${arr}`], ['Time (UTC)', arrUTC + 'z']] },
    { title: 'Pilot function time', rows: [['PIC', isPIC ? dur : '—'], ['Co-pilot', isPIC ? '—' : dur], ['Dual', '—'], ['Instructor', '—']] },
    { title: 'Operational condition', rows: [['IFR', f.ifr ? dur : '—'], ['Night', f.night ? dur : '—'], ['NVG', f.nvg ? dur : '—']] },
    { title: 'Landings', rows: [['Day', f.night ? '0' : String(f.landings)], ['Night', f.night ? String(f.landings) : '0']] },
  ];
  return (
    <div style={{ position: 'absolute', inset: 0, zIndex: 30, background: C.bg, overflowY: 'auto' }}>
      {/* sticky header */}
      <div style={{ position: 'sticky', top: 0, zIndex: 2, background: 'rgba(10,22,40,0.96)', backdropFilter: 'blur(10px)',
        borderBottom: `1px solid ${C.separator}`, padding: '54px 16px 12px' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
          <button onClick={onClose} style={{ width: 34, height: 34, borderRadius: 9, background: C.surface,
            border: `1px solid ${C.border}`, color: C.text, cursor: 'pointer', display: 'grid', placeItems: 'center', flexShrink: 0 }}>
            <span style={{ transform: 'rotate(180deg)', display: 'flex' }}><window.LIcon name="chevron" size={17}/></span></button>
          <div style={{ flex: 1, minWidth: 0 }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
              <span style={{ fontFamily: window.L_SERIF, fontSize: 22, fontWeight: 600, color: C.text }}>{f.dep} → {f.arr}</span>
              {f.ifr && badge2(C, accent, 'IFR')}{f.night && badge2(C, C.night, 'NGT')}
            </div>
            <div style={{ fontFamily: window.L_MONO, fontSize: 9.5, color: C.muted, letterSpacing: '0.04em', marginTop: 1 }}>
              {f.date.toLocaleDateString('en-GB', { weekday: 'short', day: '2-digit', month: 'short', year: 'numeric' })}</div>
          </div>
          <div style={{ textAlign: 'right', flexShrink: 0 }}>
            <div style={{ fontFamily: window.L_MONO, fontSize: 18, fontWeight: 700, color: accent }}>{dur}</div>
            <div style={{ fontFamily: window.L_MONO, fontSize: 8, color: C.muted, letterSpacing: '0.1em' }}>TOTAL</div>
          </div>
        </div>
      </div>

      <div style={{ padding: '14px 16px 30px' }}>
        {sections.map((s) => (
          <div key={s.title} style={{ marginBottom: 12, borderRadius: 14, overflow: 'hidden', border: `1px solid ${C.border}`, background: C.card }}>
            <div style={{ fontFamily: window.L_MONO, fontSize: 9, fontWeight: 700, letterSpacing: '0.14em', textTransform: 'uppercase',
              color: accent, padding: '9px 14px 4px' }}>{s.title}</div>
            {s.rows.map(([k, v], i) => (
              <div key={k} style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between',
                padding: '8px 14px', borderTop: `1px solid ${C.separator}` }}>
                <span style={{ fontFamily: window.L_FONT, fontSize: 13, color: C.text3 }}>{k}</span>
                <span style={{ fontFamily: window.L_MONO, fontSize: 13, fontWeight: 700,
                  color: v === '—' ? C.faint : C.text, fontVariantNumeric: 'tabular-nums' }}>{v}</span>
              </div>
            ))}
          </div>
        ))}
        <button style={{ width: '100%', padding: 14, borderRadius: 13, border: `1px solid ${C.border}`,
          background: C.surface, color: accent, cursor: 'pointer', fontFamily: window.L_FONT, fontSize: 14, fontWeight: 700,
          display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8 }}>
          <window.LIcon name="book" size={16}/> See this row in the book</button>
      </div>
    </div>
  );
}
function badge2(C, color, label) {
  return (
    <span style={{ fontFamily: window.L_MONO, fontSize: 8.5, fontWeight: 700, letterSpacing: '0.08em',
      color, background: color + '1F', border: `1px solid ${color}55`, padding: '2px 6px', borderRadius: 5 }}>{label}</span>
  );
}

// ── Woven physical book — a real landscape Professional Pilot Logbook spread,
// shown legibly on the page (horizontal scroll) without needing fullscreen. ──
const PRO_COLS = [
  { id: 'date', label: 'Date', sub: 'dd/mm/yy', w: 62, grp: '' },
  { id: 'mm', label: 'Make/var', w: 60, grp: 'Aircraft' },
  { id: 'reg', label: 'Reg', w: 56, grp: 'Aircraft' },
  { id: 'dplace', label: 'Place', w: 46, grp: 'Departure' },
  { id: 'dutc', label: 'UTC', w: 42, grp: 'Departure' },
  { id: 'aplace', label: 'Place', w: 46, grp: 'Arrival' },
  { id: 'autc', label: 'UTC', w: 42, grp: 'Arrival' },
  { id: 'total', label: 'Total', w: 46, grp: '' },
  { id: 'mp', label: 'MP', w: 44, grp: '' },
  { id: 'se', label: 'SE', w: 38, grp: 'Single-pilot' },
  { id: 'me', label: 'ME', w: 38, grp: 'Single-pilot', dash: true },
  { id: 'pic', label: 'PIC', w: 42, grp: 'Pilot function time' },
  { id: 'cop', label: 'Co-Pi', w: 46, grp: 'Pilot function time' },
  { id: 'dual', label: 'Dual', w: 42, grp: 'Pilot function time' },
  { id: 'instr', label: 'Instr', w: 44, grp: 'Pilot function time', dash: true },
  { id: 'ifr', label: 'IFR', w: 42, grp: 'Op. cond.' },
  { id: 'ngt', label: 'Night', w: 44, grp: 'Op. cond.', dash: true },
  { id: 'lday', label: 'Day', w: 36, grp: 'Landings' },
  { id: 'lngt', label: 'Ngt', w: 36, grp: 'Landings', dash: true },
  { id: 'rmk', label: 'Remarks and endorsements', w: 150, grp: '' },
];
function proRow(f) {
  const isPIC = f.role === 'PIC';
  const d = `${String(f.date.getDate()).padStart(2,'0')}/${String(f.date.getMonth()+1).padStart(2,'0')}/${String(f.date.getFullYear()).slice(2)}`;
  const arrMin = (() => { const [h,m]=f.depUTC.split(':').map(Number); const t=h*60+m+Math.round(f.durH*60); return `${String(Math.floor(t/60)%24).padStart(2,'0')}:${String(t%60).padStart(2,'0')}`; })();
  return { date: d, mm: f.type, reg: f.reg, dplace: f.dep, dutc: f.depUTC, aplace: f.arr, autc: arrMin,
    total: f.durH.toFixed(1), mp: f.durH.toFixed(1), se: '', me: '',
    pic: isPIC ? f.durH.toFixed(1) : '', cop: isPIC ? '' : f.durH.toFixed(1), dual: '', instr: '',
    ifr: f.ifr ? f.durH.toFixed(1) : '', ngt: f.night ? f.durH.toFixed(1) : '',
    lday: f.night ? '' : String(f.landings), lngt: f.night ? String(f.landings) : '',
    rmk: f.role === 'PIC' ? '' : `PIC: M. Berg` };
}

function BookView({ accent }) {
  const C = window.L_C;
  const rows = window.L_FLIGHTS.slice(0, 12).map(proRow);
  const totalW = PRO_COLS.reduce((s, c) => s + c.w, 0);
  const ROWH = 22;
  // grouped header spans
  const groups = [];
  PRO_COLS.forEach((c) => { const last = groups[groups.length - 1]; if (last && last.grp === c.grp && c.grp) last.w += c.w; else groups.push({ grp: c.grp, w: c.w }); });
  const sum = (key) => rows.reduce((s, r) => s + (parseFloat(r[key]) || 0), 0).toFixed(1);

  const cellStyle = (c, i) => ({ width: c.w, flexShrink: 0, padding: '0 4px', boxSizing: 'border-box',
    borderRight: `${c.dash ? '1px dashed' : '1px solid'} ${C.borderSoft}`,
    display: 'flex', alignItems: 'center' });

  const scale = (680 - 12) / totalW;
  const SPREAD_H = 340;
  return (
    <div style={{ position: 'absolute', inset: 0, background: C.bgDeep, overflow: 'hidden' }}>
      {/* landscape stage — spread rotated so it reads like a real open book */}
      <div style={{ position: 'absolute', top: '47%', left: '50%', width: 680, height: 360,
        transform: 'translate(-50%, -50%) rotate(90deg)', transformOrigin: 'center',
        display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 8 }}>
        <div style={{ width: totalW * scale, display: 'flex', alignItems: 'baseline', gap: 8 }}>
          <span style={{ fontFamily: window.L_SERIF, fontSize: 18, fontWeight: 600, color: C.text }}>Professional Pilot Logbook</span>
          <span style={{ flex: 1 }}/>
          <span style={{ fontFamily: window.L_MONO, fontSize: 10, fontWeight: 700, color: C.muted }}>Book 3 · pp. 142–143</span>
        </div>
        <div style={{ position: 'relative', width: totalW * scale, height: SPREAD_H * scale,
          borderRadius: 8, overflow: 'hidden', border: `1px solid ${C.border}` }}>
          <div style={{ position: 'absolute', top: 0, left: 0, width: totalW, transform: `scale(${scale})`, transformOrigin: 'top left',
            background: '#FBF7EC', color: '#1A2433' }}>
          {/* group header */}
          <div style={{ display: 'flex', background: '#EFE7D2', borderBottom: `1px solid #C9BE9E` }}>
            {groups.map((g, i) => (
              <div key={i} style={{ width: g.w, flexShrink: 0, padding: '3px 4px', boxSizing: 'border-box',
                borderRight: `1px solid #C9BE9E`, textAlign: 'center',
                fontFamily: window.L_MONO, fontSize: 7, fontWeight: 700, letterSpacing: '0.04em',
                color: g.grp ? '#5A4A2A' : 'transparent', textTransform: 'uppercase', minHeight: 13 }}>{g.grp || '·'}</div>
            ))}
          </div>
          {/* column header */}
          <div style={{ display: 'flex', background: '#F3ECD9', borderBottom: `1.5px solid #B7A981` }}>
            {PRO_COLS.map((c, i) => (
              <div key={i} style={{ ...cellStyle(c, i), borderRightColor: '#C9BE9E', justifyContent: c.id === 'rmk' ? 'flex-start' : 'center',
                padding: '4px 4px', flexDirection: 'column', alignItems: c.id === 'rmk' ? 'flex-start' : 'center' }}>
                <span style={{ fontFamily: window.L_MONO, fontSize: 8, fontWeight: 700, color: '#3A2E18', lineHeight: 1.1, textAlign: 'center' }}>{c.label}</span>
                {c.sub && <span style={{ fontFamily: window.L_MONO, fontSize: 6, color: '#8A7A52' }}>{c.sub}</span>}
              </div>
            ))}
          </div>
          {/* data rows */}
          {rows.map((r, ri) => (
            <div key={ri} style={{ display: 'flex', height: ROWH, borderBottom: `1px solid #E2D8BE`,
              background: ri % 2 ? '#F7F1E0' : '#FBF7EC' }}>
              {PRO_COLS.map((c, i) => (
                <div key={i} style={{ ...cellStyle(c, i), borderRightColor: c.dash ? '#C9BE9E' : '#E2D8BE',
                  justifyContent: c.id === 'rmk' || c.id === 'mm' ? 'flex-start' : 'center' }}>
                  <span style={{ fontFamily: window.L_MONO, fontSize: 8.5, fontWeight: c.id === 'pic' || c.id === 'total' ? 700 : 500,
                    color: ['total','pic','mp'].includes(c.id) ? '#0E2A4A' : '#36404E', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{r[c.id]}</span>
                </div>
              ))}
            </div>
          ))}
          {/* totals footer */}
          <div style={{ display: 'flex', height: ROWH + 2, background: '#EBE2C8', borderTop: `1.5px solid #B7A981` }}>
            {PRO_COLS.map((c, i) => {
              const totalCols = ['total','mp','pic','cop','dual','instr','ifr','ngt'];
              const cntCols = ['lday','lngt'];
              return (
                <div key={i} style={{ ...cellStyle(c, i), borderRightColor: '#C9BE9E', justifyContent: 'center' }}>
                  {c.id === 'date' ? <span style={{ fontFamily: window.L_MONO, fontSize: 7.5, fontWeight: 700, color: '#5A4A2A', letterSpacing: '0.04em' }}>TOTAL</span>
                    : totalCols.includes(c.id) ? <span style={{ fontFamily: window.L_MONO, fontSize: 8.5, fontWeight: 700, color: '#0E2A4A' }}>{sum(c.id)}</span>
                    : cntCols.includes(c.id) ? <span style={{ fontFamily: window.L_MONO, fontSize: 8.5, fontWeight: 700, color: '#0E2A4A' }}>{rows.reduce((s,r)=>s+(parseInt(r[c.id])||0),0)}</span>
                    : null}
                </div>
              );
            })}
          </div>
          </div>
        </div>
      </div>

      <div style={{ position: 'absolute', bottom: 84, left: 0, right: 0, display: 'flex', alignItems: 'center',
        justifyContent: 'center', gap: 8, fontFamily: window.L_MONO, fontSize: 9.5, color: C.muted, letterSpacing: '0.04em' }}>
        <window.LIcon name="book" size={13}/> Shown landscape · tap to open fullscreen / export PDF
      </div>
    </div>
  );
}

Object.assign(window, { CalendarSheet, FlightDetail, BookView });
