# Handoff: Logbook page redesign (List · Physical book · Fleet)

## Overview

A redesign of the **Logbook tab** for the BLADES Joint Logbook app (pilot-manned).
It's one screen with a **three-way segmented toggle** (top-right) switching between:

1. **List** — the flight list, grouped year → month, searchable & filterable.
2. **Book** — the physical EASA logbook spread, shown **landscape directly on the
   page** (no fullscreen needed).
3. **Fleet** — an overview of every aircraft model flown, with performance stats,
   type-rating validity, and registrations.

Visual language matches the rest of the app: navy surfaces, cyan accent, Fraunces
serif for display numbers/headings, JetBrains Mono for data.

## About the design files

`source/` is a **design reference** (React + Babel, browser). **Not production
code** — recreate in the app's React Native / Expo Logbook tab, reusing the real
`Colors`, fonts, flight store, and the existing physical-book renderer. Translate
`<div>`/CSS → `View`/`Text`/`StyleSheet`; SVG → `react-native-svg`.

**Prototype-only scaffolding (don't port):** `logbook-ux/ios-frame.jsx`,
`logbook-ux/tweaks-panel.jsx`, and the TweaksPanel block + `injectAccent` in
`logbook-ux/app.jsx` (accent is a colour token in the app).

Open `source/Logbook Design.html` to see it; the top-right toggle (list / book /
grid icons) switches the three modes. Tweaks panel switches Mode + accent.

## Fidelity
High-fidelity layout, type, spacing on a ~393pt-wide screen.

---

## File map
| File | Contents |
|---|---|
| `logbook-ux/shared.jsx` | Palette `L_C`, fonts, `CITY` lookup, demo `L_FLIGHTS`, `groupFlights()`, `nightFraction()`, `NightRoute`, `LIcon` icon set. |
| `logbook-ux/list.jsx` | `LogbookList` — search, filter chips, latest-flight card, year→month accordion, `FlightCard`, `PhotoCard`, `MonthGroup`. |
| `logbook-ux/views.jsx` | `CalendarSheet` (jump-to-day), `FlightDetail` (logbook-field detail), `BookView` (landscape EASA spread). |
| `logbook-ux/fleet.jsx` | `FleetView` + `FleetCard` — aircraft overview. |
| `logbook-ux/app.jsx` | Shell: 3-way toggle, bottom tab bar, overlays, Tweaks (prototype only). |

---

## 1. List view (`LogbookList`)
- **Sticky header**: "Logbook" title + calendar button; a **search field**
  (matches ICAO, city, registration, type, role); **filter chips**:
  All / PIC / IFR / Night / Photo.
- **Latest-flight card** (only when filter=All & no query): header reads
  **"LATEST FLIGHT"** in mono caps with a thin accent hairline (no icon). Below:
  the route via `NightRoute`, block time, **night-portion caption** (% night +
  dark-onset time), city pair, and a 5-cell strip (Role / Aircraft / Dep / Rules
  / Arr).
- **Year → Month accordion**: **all years collapsed by default** (including the
  current year) — tap a year to expand its months, tap a month to expand its
  flights. Year header: chevron, year (Fraunces 21px), hours, "{n} flights".
  When a filter is active the year hours carry the filter label (e.g. "50h PIC").
- **FlightCard** (a flight row): date chip (day + weekday) · `DEP → ARR` +
  IFR/Night badges · role · type/reg · right side shows block time and
  **both off-block and on-block UTC** separated by a middle dot
  (e.g. `06:18 · 09:00z`).
- **Calendar** button → `CalendarSheet`: month grid, days with flights are
  dotted; tapping a flown day opens that flight.

### Night route fill (`NightRoute`) — distinctive detail
The `DEP → ARR` text on the latest-flight card is filled **white for the daytime
portion and platinum/silver for the night portion**, proportional to how much of
the flight was flown after dark. `nightFraction(f)` computes the trailing
fraction from `depUTC`, `darkOnset`, and block time; the last *fraction* of the
combined ICAO string is rendered silver via a per-character gradient. Demo
example: ESCF→ESSA, dep 21:00, dark onset 22:30, arr 23:00 → last ¼ silver.
Use the app's existing civil-twilight/dark-onset calc to drive this.

## Photo filter — gallery
With the **Photo** chip active, the same year→month accordion is kept, but months
show **"{n} photos"** and each flight renders as a **`PhotoCard`**: a large
16:10 photo preview with route, date, type/reg, and block time over a bottom
gradient. (In the app, use the flight's own photo; the prototype uses one sample.)

## 2. Book view (`BookView`)
The official **Professional Pilot Logbook** EASA spread, rendered as **cream paper
shown landscape directly on the page** (rotated 90° to fill the portrait phone) —
so the pilot reads the real spread without entering a separate fullscreen mode.
Grouped EASA column headers (Aircraft / Departure / Arrival / Single-pilot /
Pilot function time / Op. condition / Landings / Remarks), ruled rows, dashed
sub-column rules, TOTAL footer. In production, reuse the app's existing
physical-book renderer / templates — keep the "shown landscape inline" behaviour
as the improvement over today's fullscreen-only view.

## 3. Fleet view (`FleetView`)
Overview of aircraft **models** flown, **sorted by most-recently-flown** (current
aircraft first, marked with a "NOW" pill + accent glow).
- **Responsive grid**: **1 model → one large full-width tile**; **2+ → 2-column
  compact grid**.
- **FleetCard** per model: model + maker; **total time on the model**;
  **type-rating status** colour-coded (green Valid / amber Expiring / red Expired)
  + expiry date + class/rating label; an editable **performance stat grid** —
  **VNE, Cruise, Endurance, MTOW** (pencil toggles them to inputs; all four
  editable); **registrations** — top 3 always shown (reg code + hours on that
  reg), "Show all N" expands the rest; "Last flown {relative}".
- Demo fleet: A320 (current, 4 regs, type-rating valid) · DA40 (expiring) ·
  C172 (valid) · PA28 (expired) — shows all rating states.

## Tokens
Navy theme (`constants/colors.ts`): bg `#0A1628`, deep `#06101E`, card `#102441`,
surface `#0F1E3A`, border `#1A3A5A`, separator `#122030`. Accent cyan `#00C8E8`
(tweakable: gold `#FFB830`, mint `#00E8A0`, violet `#9B8CFF`). Rating colours:
valid `#00E8A0`, expiring `#FFB830`, expired `#FF4D6A`. Night-fill platinum
`#C7CDDA`. Text white / `#A8BFD6` / `#7FA8C8` / `#5A7FA0` / `#3A5A7A`.
Fonts: Fraunces (display), JetBrains Mono (data), Inter/SF (body).

## Data — invent nothing new
All from existing flight data: per-flight date / dep / arr / reg / type / role /
block time / off-&-on-block UTC / IFR / night / dark-onset / photo / landings;
month & year aggregates; per-model totals, registrations + per-reg hours, type-
rating expiry, and the editable aircraft performance fields (VNE/cruise/
endurance/MTOW) already in the aircraft registry.

## Assets
`share-assets/example-photo.jpeg` — sample photo for the Photo gallery preview
only (production uses each flight's own photo). Icons are inline SVG (`LIcon`).
