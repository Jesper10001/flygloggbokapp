OFFICIAL PILOT LOGBOOK TEMPLATE TEST SET
===========================================

Included files each contain 10 fictional flights.

1. ForeFlight
   - Uses the exact structure and headers of ForeFlight's publicly downloadable official sample CSV.
   - Aircraft and flight data were replaced with fictional test data.

2. MyFlightbook
   - Uses exact core column names published in MyFlightbook's official import documentation.
   - This is an official supported import schema, not a claim that every MyFlightbook export always has only these columns.
   - A downloaded export may also include Flight ID and additional property columns.

3. CrewLounge PILOTLOG
   - Uses the exact header from CrewLounge's publicly downloadable official Conversion Template CSV.

See 00_research_status.csv for apps whose precise generated export format could not be verified publicly.
No unverified recreation is labelled as exact.
